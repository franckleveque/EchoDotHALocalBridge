---
name: modele-da
description: Write or update a software Architecture Document (Dossier d'Architecture, DA) in Markdown following Bertrand Florat's modele-da template (FR) or architecture-document-template (EN). README + 5 self-contained views (applicative, développement, dimensionnement, infrastructure, sécurité) + glossaire, each structured as Contraintes / Exigences / Solution. Use when asked for a DA, DAT, dossier d'architecture, architecture document, or an architecture review against modele-da.
license: CC-BY-SA-4.0 (template content by Bertrand Florat and contributors, https://github.com/bflorat/modele-da)
compatibility: Needs file read/write and python3 for the validator. Node optional (Mermaid C4 parse check). Network optional (only to resync templates).
metadata:
  upstream-fr: "bflorat/modele-da@ed58107"
  upstream-en: "bflorat/architecture-document-template@27d88bb"
  version: "1.0"
---

# modele-da: Architecture Document generator

All paths below are relative to this skill's directory (the folder containing this SKILL.md).

## What the deliverable is (non negotiable)

A folder (default `docs/architecture/`, or the path the user gives) containing **exactly the upstream files, in Markdown**:

| FR (default) | EN | Content |
|---|---|---|
| `README.md` | `README.md` | Summary table: status, last update, application, **security rating**, template commit hash. Links to the views. "Reste à faire identifié". |
| `vue-applicative.md` | `view-application.md` | General context, actors, data sensitivity, constraints, requirements, target application architecture, flow matrix |
| `vue-developpement.md` | `view-development.md` | Software architecture: stack, dependencies, factory, tests, robustness, config, logs, i18n... |
| `vue-dimensionnement.md` | `view-sizing.md` | Static/dynamic volumes, response times, resources per deployable unit, machines, storage |
| `vue-infrastructure.md` | `view-infrastructure.md` | Availability (MTTD/MTTR, RPO/RTO), hosting, deployment, infra components, technical flow matrix, environments, operations, backups, monitoring |
| `vue-securite.md` | `view-security.md` | Integrity, confidentiality, identification, authentication, federation, SSO, non-repudiation, privacy, authorisations, traceability; security measures; RACI and self-checks annex |
| `glossaire.md` | `glossary.md` | Ubiquitous language, alphabetical |
| `adr/NNNN-*.md` (optional) | same | Decisions and alternatives studied (studies do not belong in the views) |

Never invent other files (no `00-general-overview.md`, no numbered views, no "functional requirements" view). Language: French unless the user writes in English or asks for EN.

## Source material in this skill

- `assets/fr/*.md`, `assets/en/*.md`: blank skeletons converted from the upstream blank template. **Copy them, then fill them. Never retype the structure.**
- `references/guide-<lang>-<view>.md`: upstream writing guidance per section (examples stripped). Tags such as `` `[taille_projet::grand]` `` or `` `[migration]` `` mark sections that only matter for large projects or migrations. Files are large: read only the guide of the view you are writing, or `grep -n -A8 "### <section>"` for one section.
- `scripts/check_da.py`: structural validator. `scripts/build_assets.py`: resync from upstream.

## Workflow

### 1. Collect facts
Read what exists before asking anything: user brief, attached specs, and if run inside a code repo, the manifests (`package.json`, `pom.xml`, `go.mod`...), Dockerfiles, IaC (Terraform, Helm, k8s), CI files, existing ADRs or docs. Every fact found there is a fact, not a hypothesis.

### 2. Gap analysis (triptych, per view)
For each view, list what is known for **Contraintes** (imposed: law, budget, deadlines, mandatory stack, hosting, skills), **Exigences** (non functional and measurable: volumes, response times, availability per time slot, RPO/RTO, D-I-C-P levels, retention) and what **Solution** choices they drive.

Ask the user **only blocking questions**, in one message, max 10, grouped by view, each with a proposed default. Typical blockers: data classification and security grid, availability target and time slots, volumes at 5 years, hosting constraint (cloud/on-prem/sovereign), regulatory frame (RGPD, HDS, PCI...). If the user wants direct generation or does not answer, proceed with defaults recorded as hypotheses (step 3).

### 3. Write
1. `mkdir -p <out> && cp assets/<lang>/*.md <out>/`.
2. Fill views in this order: applicative, sécurité, dimensionnement, infrastructure, développement (each depends on the previous ones). Then README, then glossaire.
3. For each view, read its guide, then fill every section.

Writing rules (from upstream README):
- **Keep every heading, its level, its order and its exact title.** You may add sub-headings and table rows, never remove or rename.
- A section that does not apply gets `N/A` (optionally with a reason), one still unknown gets `TODO: <what is missing, who>`. Never leave a section empty, never delete it.
- **Each view is self-contained**: its Contraintes and Exigences belong to its own concern. Cross-reference with a relative link (`[Exigences de disponibilité](vue-infrastructure.md#exigences-de-disponibilité)`) rather than duplicate.
- Exigences are **non functional only**. Do not write user stories or functional specs.
- Solution sections answer the Exigences within the Contraintes: cite the requirement they satisfy (e.g. "répond à EXI-DIM-02").
- Uncertainty goes in each view's `Non statué` section: structuring assumptions as rows `| H-01 | ... |` in the `Hypothèses` table, open studies in `Points nécessitant une étude complémentaire` (with owner and due date, `TODO` if unknown). Cite them inline as `(H-01)`. Any number you did not receive (volumes, SLA, sizing) must cite an H-xx. Many hypotheses means the DA is premature: say so in the README "Reste à faire identifié".
- Fill the view header: `**Dernière modification** : <today>`, `**Date de la dernière revue globale** :`, `**Statut du document** : Brouillon` (or the status given).
- Be brief: every word must be useful. No boilerplate intros, no company history, no repetition of corporate standards (link them in `Documentation de Référence`).
- **Excluded from a DA**: detailed design (class/sequence diagrams except a notable pattern), studies and option comparisons (write ADRs), IS-wide urbanisation, reference rules common to all apps, IPs/logins/secrets, physical architecture (racks, SAN, datacenter network), details of non-production environments beyond the `Environnements` table.
- Architecture trajectories: describe future steps in the same sections, prefixed `[Étape 2]`, less detailed the further away.
- Glossary: alphabetical, terms used consistently across the views.
- Do not use the em dash character.

### 4. Security rating (README)
- Format `<grille> <niveaux>` with dashes: `DICP 4-3-3-3`. Grids: `DIC` (ISO 27001, CIA equivalent), `DICT` (+ Traçabilité), `DICP` (+ Preuve, ANSSI). State which grid.
- Per criterion take the **maximum** level across all modules and data classes of the DA.
- Availability (D) is justified in the infrastructure view Exigences (downtime per slot, RPO, RTO); I, C, T/P in the security view Exigences. The README only holds the rating, not the justification.
- EN README has no rating row upstream: add `**Security rating**: DICP x-x-x-x` under the status line.
- README `Version du modèle utilisé`: the upstream commit in `metadata` (`ed58107` for FR, `27d88bb` for EN).

### 5. Diagrams: C4 in Mermaid
Upstream draws C4 with PlantUML; this skill uses **Mermaid C4** in fenced ```mermaid blocks (Mermaid labels C4 experimental, accepted by choice). Before drawing, read `references/c4-mermaid.md` and start from its parse-checked snippets.

| Section | Diagram |
|---|---|
| Vue applicative > Architecture applicative générale | `C4Context` |
| Architecture applicative détaillée > Inventaire des modules | `C4Container` |
| Architecture applicative détaillée > Liens entre modules | `C4Dynamic` (one per notable scenario) |
| Vue infrastructure > Déploiement en production | `C4Deployment` |
| Vue développement > Patterns notables (optional) | `C4Component` |

Same aliases across all diagrams; relationship labels carry the flow number of the matching matrix; no PlantUML-only features (tags, legend, `Lay_*`). Flow matrices stay tables; diagrams illustrate them. Use another Mermaid type only for content C4 cannot express (e.g. a `sequenceDiagram` for a notable pattern).

### 6. Validate before delivering
```
python3 scripts/check_da.py <out> <fr|en>
```
If Node is available, also parse-check the diagrams (setup command in the script header):
```
NODE_PATH=~/.cache/modele-da/node_modules node scripts/check_mermaid.mjs <out>/*.md
```
Fix every ERROR (missing or renamed heading, empty section, placeholder date, bad rating format, undeclared H-xx, wrong C4 type, Mermaid parse error). Then do a consistency pass: modules in the applicative flow matrix match the deployable units in dimensionnement and the infra components; D-I-C levels in vue applicative match security and infra Exigences; rating = max.

### 7. Report
Reply with: output path, security rating, count of hypotheses and TODOs per view, and the blocking points the user must decide. Do not paste the documents in chat.

## Updating an existing DA
Read the existing files, keep their content, apply the change in the right view(s), update `Dernière modification`, re-run the validator. Never regenerate from scratch.

## Resync with upstream (optional)
```
git clone --depth 1 https://github.com/bflorat/modele-da.git /tmp/modele-da
git clone --depth 1 https://github.com/bflorat/architecture-document-template.git /tmp/adt
python3 scripts/build_assets.py /tmp/modele-da /tmp/adt
```
Then update the commit hashes in `metadata`.
