# Vue infrastructure
- Faire régulièrement des revues complètes de la vue (au moins une fois par an tant que le projet est actif) et mettre à jour la date plus haut.
- Indiquer le statut de la vue, par exemple 'DRAFT', 'FINALISÉ',...

## Introduction `[contexte]`
- Cette vue est aussi souvent appelé « vue  technique » et concerne l'infrastructure : serveurs, réseaux, systèmes d'exploitation, bases de données, intergiciels, … Bref, elle porte sur tout ce qui est externe à l'application et nécessaire à son exécution.

### Documentation de Référence `[references]`
- Mentionner ici les documents d'architecture de référence (mutualisés). Ce document ne doit pas reprendre leur contenu sous peine de devenir rapidement obsolète et non maintenable.

## Non statué `[contexte, incertitude]`

### Points nécessitant une étude complémentaire

### Hypothèses
- Donner ici les éventuelles hypothèses structurantes

## Contraintes `[niveau_detail::général, contrainte]`
- Les contraintes définissent les limites applicables aux exigences du projet. Il est intéressant de les expliciter pour obtenir des exigences réalistes. Par exemple, il ne serait pas valide d'exiger une disponibilité incompatible avec le niveau de sécurité Tier du datacenter qui l'hébergera.

### Contraintes sur la disponibilité `[disponibilité]`
- Les éléments ici fournis pourront servir de base au SLO (Service Level Objective). Idéalement, ce dossier devrait simplement pointer sur un tel SLO sans plus de précision. Ce chapitre a une vocation pédagogique car il rappelle la disponibilité plafond envisageable : la disponibilité finale de l’application ne pourra être qu’inférieure.

#### Contraintes de MTTD `[niveau_detail::détaillé, supervision]`
- Détailler les éléments permettant d'estimer le temps moyen de détection d'incident (Mean Time To Detect).

#### Contraintes sur les outils et normes de supervision `[niveau_detail::détaillé, supervision]`
- Fournir ici les outils et normes de supervisions imposés au niveau du SI et les éventuelles contraintes liées.

#### Contraintes de MTTR `[niveau_detail::détaillé]`
- Fournir les éléments permettant d'estimer le temps moyen de réparation (Mean Time To Repair). A noter qu'il est important de distinguer le MTTD du MTTR. En effet, ce n'est pas parce qu'une panne est détectée que les compétences ou ressources nécessaires à sa correction sont disponibles. Préciser les plages de présence des exploitants en journée et les possibilités d'astreintes. Si vous disposez de statistiques ou de post-mortems, mentionnez les durées effectives moyennes déjà observées. Lister ici les durées d’intervention des prestataires matériels, logiciels, électricité, télécom… Nous subdivisons de façon indicative cette section en sous-sections "Hardware", "Système et virtualisation", "Réseau", et "Restauration de données". D'autres catégories sont possibles.

##### Matériel `[niveau_detail::approfondi]`
- Décrire ici les éléments permettant de prévoir le MTTR des éléments hardware (serveurs / baies / équipements réseau / systèmes électriques, etc.). Lister par exemple ici les durées d’intervention des prestataires matériels, électricité….

##### Système et virtualisation `[niveau_detail::approfondi]`
- Lister ici les éléments permettant d'estimer le temps de correction d'un problème lié à l'OS ou à une éventuelle solution de virtualisation.

##### Réseau `[niveau_detail::approfondi]`
- Lister ici les éléments liés au réseau permettant d'estimer les durées d’intervention des prestataires ou fournisseurs Telecom…

##### Restauration de données `[niveau_detail::détaillé]`
- Lister ici les éléments permettant d'évaluer la durée de restauration de données (fichiers / objets / base de données). Les exigences de RTO listées plus bas devront prendre en compte ce MTTR.

#### Contraintes sur les interruptions programmées `[niveau_detail::approfondi]`
- Fournir ici la liste et la durée des interruptions programmées standards dans le SI.

#### Contraintes liées au niveau de service du datacenter `[niveau_detail::détaillé]`
- Fournir ici le niveau de sécurité du datacenter (DC) selon l’échelle Uptime Institute (Tier de 1 à 4). TIP: A noter que les architectures Cloud modernes privilégient la redondance des DC sur des sites distants plutôt qu'un niveau Tier plus élevé sur un seul site (à condition de pouvoir répliquer efficacement des données et d'accepter un délais sur la cohérence immédiate des données, voir le [théorème CAP](https://fr.wikipedia.org/wiki/Th%C3%A9or%C3%A8me_CAP)). De façon simpliste, on peut calculer que la disponibilité de deux DC actifs en parallèle est de sept neufs contre quatre neufs pour un DC Tier 4. Un compromis entre les deux modèles est le déploiement dans des zones redondantes d'un même site au prix d'une plus grande vulnérabilité aux catastrophes. .Niveaux Tier des datacenters (source : Wikipedia)

#### Plafond de disponibilité `[niveau_detail::général]`
- Expliquez clairement aux parties prenantes que, même avec de la HA au niveau applicatif, la **disponibilité de bout en bout maximale** est plafonnée par la disponibilité des dépendances sous-jacentes (datacenter, réseau, plateforme). Ce **plafond de disponibilité** est le produit de leurs SLA et est toujours < à la dépendance la moins disponible. `A_plafond = ∏(A_SLA de chaque dépendance en série)  ≤  min(A_SLA)` **Implication :** les cibles SLO **ne doivent pas dépasser** ce plafond. La HA aide à s’approcher du plafond, pas à le dépasser. **Notes de périmètre**
  - Si toutes les répliques se trouvent dans le **même domaine de défaillance** (même DC/énergie/accès), le SLA du DC **fixe effectivement le plafond**.
  - Pour **rehausser le plafond**, utilisez des **domaines de défaillance indépendants** (p. ex. multi-AZ/région) ; pour la redondance en parallèle : `A_parallel = 1 - ∏(1 - A_i)` (indépendance supposée).

#### Contraintes liées à la gestion des catastrophes `[niveau_detail::général]`
- Les catastrophes peuvent être classées en trois catégories :
  - Naturelles (tremblements de terre, inondations, ouragans, canicules, etc.) ;
  - Infrastructurelles (accidentelles comme les accidents industriels, incendies, pannes électriques majeures, pannes majeures du réseau / stockage / serveurs, erreurs critiques d’administrateurs ou intentionnelles : militaires, terroristes, sabotage, etc.) ;
  - Cyber (DDoS, virus, ransomware, etc.). Le **Disaster Recovery (DR)** est l’ensemble des stratégies et solutions mises en place pour **restaurer un système informatique après une catastrophe**, minimisant ainsi les pertes de données et le temps d’arrêt. Le DR peut inclure des solutions comme :
  - **Cold site** : centre de secours prêt à être activé mais sans infrastructure active ;
  - **Warm site** : infrastructure préinstallée mais nécessitant une mise en production manuelle ;
  - **Hot site** : réplication en temps réel avec bascule automatique possible ;
  - **Disaster Recovery as a Service (DRaaS)** : solutions cloud de restauration rapide (AWS Elastic Disaster Recovery, Azure Site Recovery, etc.). Le PRA (Plan de Reprise d’Activité) et le PCA (Plan de Continuité d’Activité) sont des stratégies spécifiques de **DR** répondant à un risque de catastrophe sur le SI :
  - **PRA (Plan de Reprise d’Activité)** ou _Comment revenir à la normale après le problème ?_ Permet de **reprendre l’activité après une catastrophe** dans un délai défini (RTO). Il repose sur des **synchronizations asynchrones entre sites, des sauvegardes, des restaurations et des infrastructures de secours** comme des **DC secondaires, du stockage répliqué** ou des **solutions DRaaS**. L’objectif est d’assurer la reprise, mais avec une **interruption temporaire** et l'acceptation d'un RPO non nul.
  - **PCA (Plan de Continuité d’Activité)** ou _Comment continuer à travailler malgré le problème ?_ Permet d’assurer la **continuité des activités critiques** sans interruption notable et avec un RPO quasi-nul. Il comprend des mesures organisationnelles (équipes de crise, mode dégradé comme utilisation du papier, sites de repli,...) et techniques comme des **clusters actifs-actifs multi-zonaux, une réplication synchrone des données et des infrastructures hautement redondantes**. Un architecte n’utilise pas les mêmes technologies selon que l’on vise un **PRA ou un PCA** :
  - **PRA** →  Se concentre sur la **sauvegarde et la restauration** dans un DC de secours, avec un **RTO défini**.

### Contraintes d'hébergement `[niveau_detail::général]`

### Contraintes réseau `[niveau_detail::détaillé]`
- Lister les contraintes liées au réseau, en particulier les découpages en zones de sécurité. Les aspects débit sont listées dans la vue dimensionnement.

### Contraintes de déploiement `[niveau_detail::détaillé]`
- Lister les contraintes liées au déploiement des applications et services d’infrastructure.

### Contraintes liées au cycle de vie des composants d'infrastructure `[niveau_detail::détaillé]`
- Lister les contraintes liées aux mises à jour et maintenance des composants d’infrastructure (systèmes d'exploitation, intergiciels, bases de données, etc.).

### Contraintes liées aux journaux `[niveau_detail::détaillé]`
- Lister les contraintes liées aux journaux

### Contraintes de sauvegardes et restaurations `[niveau_detail::détaillé]`
- Lister les contraintes liées aux sauvegardes. Une contrainte courante est le respect de la méthode 3-2-1 :
  - Au moins 3 exemplaires des données (la donnée vivante + 2 copies) ;
  - Au moins 2 technologies de stockage différentes pour ces 3 copies (exemple : disques SSD pour les données vivantes et deux sauvegardes sur bandes) ;
  - Au moins 1 exemplaire hors-ligne et hors site (exemple : 1 jeu de bandes conservé dans un coffre ignifugé à la banque).

### Contraintes budgétaires `[niveau_detail::détaillé]`
- Lister les limites budgétaires.

## Exigences `[niveau_detail::général, contrainte]`
- Contrairement aux contraintes qui fixaient le cadre auquel toute application devait se conformer, les exigences non fonctionnelles sont données par les porteurs du projet (Product Owner, MOA, client, etc.). Prévoir des interviews pour les recueillir. Si certaines exigences ne sont pas réalistes, le mentionner dans le document des points non statués. Les exigences liées à la disponibilité devraient être précisées via une étude de risque (type [EBIOS Risk Manager](https://cyber.gouv.fr/la-methode-ebios-risk-manager))

### Plages de fonctionnement
- On liste ici les plages de fonctionnement principales (ne pas trop détailler, ce n’est pas un plan de production). Penser aux utilisateurs situés dans d'autres fuseaux horaires. Les informations données ici serviront d'entrants au SLA de l’application.

### Exigences de disponibilité `[disponibilité]`
- Nous listons ici les **exigences** de disponibilité. Les mesures techniques permettant de les atteindre seront données dans l'architecture technique de la solution. Les informations données ici serviront d'entrants au SLA de l'application. **Attention à bien cadrer ces exigences** : un porteur de projet a souvent tendance à demander une disponibilité très élevée sans toujours se rendre compte des implications. Le coût et la complexité de la solution augmentent exponentiellement avec le niveau exigé. L'architecture physique, technique voire logicielle peut changer complètement en fonction du besoin : clusters d'intergiciels ou de bases de données, redondances matérielles coûteuses, architecture asynchrone, caches de session, failover. Ne pas oublier les coûts d'astreinte, souvent importants dès que les exigences sont élevées. De la pédagogie et un devis permettent en général de modérer les exigences. On estime généralement que la haute disponibilité commence à trois neufs (99,9 %), soit environ 8 h 45 d'indisponibilité par an. La disponibilité exigée ici devra être cohérente avec les contraintes de disponibilité du SI données plus haut.
- **La colonne « Justification » est la plus utile du tableau.** Devoir écrire pourquoi une plage exige tel niveau conduit souvent le porteur de projet à constater que la nuit et le week-end ne réclament pas ce qu'il avait demandé. C'est un outil de modération plus efficace que n'importe quel avertissement sur les coûts. Si toutes les plages portent le même niveau, c'est le signe qu'il n'y a en réalité qu'une seule plage : simplifier plutôt que de dupliquer des lignes identiques.
- **Choisir le niveau RPO en partant des scénarios de restauration**, et non du seul volume de données. Une restauration peut être nécessaire après :
  - une perte matérielle : peu probable avec des systèmes redondés ;
  - une fausse manipulation d'un utilisateur avancé ou d'un administrateur : assez courant ;
  - un bug applicatif ayant corrompu des données ;
  - une destruction volontaire (rançongiciel, sabotage interne). Les deux derniers cas sont dimensionnants : ils supposent de pouvoir remonter à un point **antérieur à la corruption**, ce qu'une simple réplication synchrone ne permet pas. Un RPO court ne dispense donc jamais d'un historique de sauvegardes.
- **RTO et RPO ne se déduisent pas l'un de l'autre.** Un service rétabli en trois heures mais ayant perdu vingt-quatre heures de données est souvent plus pénalisant qu'une interruption longue sans perte. C'est la raison pour laquelle les deux sont cotés séparément ci-dessus. Si les deux axes divergent fortement et durablement, préférer une cotation en deux valeurs (ex. : `RTO D4 / RPO D3`) plutôt qu'un chiffre unique qui masquerait l'écart.

### Exigences de robustesse `[niveau::intermédiaire, niveau_detail::détaillé]`
- La robustesse du système indique sa capacité à ne pas produire d'erreurs lors d’événements exceptionnels comme une surcharge ou la panne de l'un de ses composants d'infrastructure. Cette robustesse s'exprime en valeur absolue par unité de temps : nombre d'erreurs (techniques) par mois, nombre de messages perdus par an… Attention à ne pas être trop exigeant sur ce point car une grande robustesse peut impliquer la mise en place de systèmes à tolérance de panne complexes, coûteux et pouvant aller à l'encontre des capacités de montée en charge, voire même de la disponibilité.

### Exigences de déploiements et de mises à jour `[niveau::intermédiaire, niveau_detail::détaillé]`

#### Coté serveur
- Préciser ici comment l’application devra être déployée coté serveur. Par exemple :
  - L'installation est-elle manuelle ? scriptées avec des outils d'IT Automation comme Ansible ou Terraform ? via des images Docker/OCI ?
  - Comment sont déployées les unités déployables (modules ou composants d'infrastructure) ? Sous forme de paquets ? Utilise-t-on un dépôt de paquets (type yum ou apt) ? Utilise-t-on des conteneurs ?
  - Comment sont appliquées les mises à jour ?

#### Coté client `[ihm]`
- Préciser ici comment l’application devra être déployée coté client :
  - Si l’application est volumineuse (beaucoup de JS ou d’images par exemple), risque-t-on un impact sur le réseau ?
  - Une mise en cache de proxy locaux est-elle à prévoir ?
  - Des règles de firewall ou QoS sont-elles à prévoir ? Coté client, pour une application client lourd :
  - Quel version de l’OS est supportée ?
  - Si l’OS est Windows, l’installation passe-t-elle par un outil de déploiement (Novell ZENWorks par exemple) ? l’application vient-elle avec un installeur type Nullsoft ? Affecte-t-elle le système (variables d’environnements, base de registre…) ou est-elle en mode portable (simple zip) ?
  - Si l’OS est Linux, l’application doit-elle fournie en tant que paquet ?
  - Comment sont appliquées les mises à jour ?

#### Stratégie de déploiement spécifiques `[niveau::intermédiaire, niveau_detail::détaillé]`
- - Prévoit-on un déploiement de type blue/green ?
  - Prévoit-on un déploiement de type canary testing ? si oui, sur quel critère ?
  - Utilise-t-on des feature flags ? si oui, sur quelles fonctionnalités ?

### Exigences d'écoconception `[niveau::intermédiaire]`
- L'écoconception consiste à limiter l'impact environnemental des logiciels et matériels utilisés par l’application. Les exigences dans ce domaine s'expriment généralement en wattheures ou équivalent CO2. A noter que la loi française (voir loi [du n°2020-105 du 10 février 2020, ou loi AGEC](https://ecoresponsable.numerique.gouv.fr/publications/guide-pratique-achats-numeriques-responsables/demarche-numerique-responsable/que-prevoit-la-loi/)) exige de réduire le gaspillage lié au numérique, notamment concernant l'obsolescence matérielle (art. 19). Prendre également en compte les impressions et courriers. Selon l'ADEME (estimation 2014), les émissions équivalent CO2 d'un KWH en France continentale pour le tertiaire est de 50 g/KWH.

## Architecture cible `[niveau_detail::général, solution]`

### Principes `[niveau_detail::détaillé]`
- Quels sont les grands principes d'infrastructure de notre application ?

### Disponibilité `[niveau::intermédiaire, disponibilité]`
- La disponibilité mesure le pourcentage de temps pendant lequel un système est utilisable dans des conditions acceptables, c'est-à-dire accessible et opérationnel selon les critères définis (temps de réponse, capacité de traitement, etc.). Il est exprimé en % (exemple: 99.9% = ~8h45 d’indisponibilité/an). Fournir ici les dispositifs permettant d'atteindre les Exigences de disponibilité. Les mesures permettant d’atteindre la disponibilité exigée sont nombreuses et devront être choisies par l’architecte en fonction de leur apport et de leur coût (financier, en complexité, etc.). Les indisponibilités peuvent-être de deux natures :
  - Indisponibilités non planifiées (imprévues) : pannes matérielles (serveur, disque, réseau, etc.), bugs ou crashs logiciels, attaques (DDoS, ransomware, etc.), problèmes d’infrastructure (coupure électrique, incendie), ...
  - Indisponibilités programmées (maintenance planifiée) : mises à jour logicielles (OS, application, base de données), remplacements matériels, changements d’architecture (migration, refonte), tests de bascule (DRP/PRA, failover test), ... Les indisponibilité programmées sont en général prises en compte dans le calcul de la disponibilité globale (sauf si le SLA prévoit le contraire) puisque le service aux utilisateurs n'est alors pas rendu. Nous regroupons ici les dispositifs de disponibilité en cinq grandes catégories :
  - Dispositifs de **supervision** (technique et applicative) permettant de détecter au plus tôt les pannes et donc de limiter le MTTD (temps moyen de détection).
  - **Dispositifs organisationnels** :
    - la présence humaine (astreintes, heures de support étendues…) qui permet d'améliorer le MTTR (temps moyen de résolution) et sans laquelle la supervision est inefficiente ;
    - La qualité de la gestion des incidents (voir les bonnes pratiques ITIL), par exemple un workflow de résolution d'incident est-il prévu ? si oui, quel est sa complexité ? sa durée de mise en œuvre ? des validations hiérarchiques (affectant donc le MTTR) sont-elles prévues ?
  - Dispositifs de **haute disponibilité (HA)** (clusters, load balancers, failover automatique, etc.) qu'il ne faut pas surestimer si les dispositifs organisationnels sont insuffisants.
  - Dispositifs de **restauration de données** : La procédure de restauration est-elle bien définie et testée régulièrement ? L’isolement des sauvegardes est-il assuré pour éviter toute compromission (ex: ransomware, corruption) ? Le temps de restauration est-il compatible avec le RTO défini ? En cas de perte de données causée par une fausse manipulation ou bug dans le code, il faut alors arrêter l'application et dans cette situation, pouvoir restaurer rapidement la dernière sauvegarde améliore grandement le MTTR.
  - Architectures et modèles de déploiement limitant les indisponibilité programmées : mise à jour sans coupure (Rolling Update, Blue/Green Deployment), clusters HA avec failover automatique (voir plus bas), maintenance sans coupure via redondance active/active (voir plus bas).
- **Principes de disponibilité et de redondance**:
  - La **disponibilité d’un ensemble de composants d'infrastructure en série** : `D = D1 * D2 * … * Dn`. Exemple : la disponibilité d’une application utilisant un serveur Tomcat à 98 % et une base Oracle à 99 % sera de 97.02 %.
  - La **disponibilité d’un ensemble de composants d'infrastructure en parallèle** : `D = 1 – (1-D1) * (1- D2) * ..* (1-Dn)`. Exemple : la disponibilité de trois serveurs Nginx en cluster dont chacun possède une disponibilité de 98 % est de 99.999 %.
  - Il convient d'être cohérent sur la **disponibilité de chaque maillon de la chaîne de liaison** : rien ne sert d'avoir un cluster actif/actif de serveurs d'application JEE si tous ces serveurs attaquent une base de données localisée sur un unique serveur physique avec disques sans RAID.
  - On désigne par **«spare»** un dispositif (serveur, disque, carte électronique…) de rechange qui est dédié au besoin de disponibilité mais qui n'est pas activé en dehors des pannes. En fonction du niveau de disponibilité recherché, il peut être dédié à l’application ou mutualisé au niveau SI.
  - Les **niveaux de redondance** d'un système (modèle NMR = N-Modular Redundancy) les plus courants sont les suivants (avec N, le nombre de dispositifs assurant un fonctionnement correct en charge) :
    - **N** : aucune redondance (exemple : si l'alimentation unique d'un serveur tombe, le serveur s'arrête)
    - **N+1** : un composant d'infrastructure de rechange est disponible, on peut supporter la panne d'un matériel (exemple : on a une alimentation de spare disponible).
    - **N+M**: Un seul spare n'est pas suffisant pour tenir la charge, on prévoit au moins M spares.
    - **2N** : le système est entièrement redondé en parallèle et peut donc supporter la perte de la moitié des composants d'infrastructure (exemple : on dispose de deux alimentations actives en même temps dont chacune suffit à alimenter le serveur). Ce système est tolerant aux pannes (FT = fault-tolerant).
    - **2N+1**: En plus d'un système entièrement redondé, un système de secours est disponible (pour les opérations de maintenance par exemple). Elle est courante dans les DC critiques et les architectures cloud multi-zonales (AWS, Azure, GCP).
- Quelques mots sur les **répartiteurs de charge** :
  - Un répartiteur de charge (Load Balancer = LB) est un composant réseau ou logiciel qui distribue automatiquement le trafic entrant entre plusieurs serveurs afin d’optimiser la disponibilité, la performance et la tolérance aux pannes d’une application ; il peut fonctionner à différents niveaux du modèle OSI, du niveau 4 (TCP/UDP, ex: LVS, F5 LTM) au niveau 7 (HTTP, ex: HAProxy, Nginx, Traefik).
  - Un répartiteur de charge (Load Balancer = LB) est une **brique indispensable à un cluster actif/actif**.
  - Dans la plupart des clusters à vocation de haute disponibilité, il faut redonder le répartiteur de charge pour éviter un SPOF. Une approche classique est un LB actif/passif (ex: Keepalived avec VRRP), mais un mode actif/actif est possible avec des solutions comme ECMP (repartition interne à un DC) ou GSLB (repartition multi-DC). L’essentiel est d’éviter une centralisation excessive qui recréerait un SPOF.
  - Pour les clusters subissant une très forte charge (ex: LB cloud GCP), une approche consiste à déployer les LB en actif/actif avec un équilibrage côté client via Anycast DNS, Weighted DNS Routing ou GSLB.
  - Il est crucial de configurer correctement et à fréquence suffisante les tests de vie (**heathcheck**) des nœuds vers lesquels le répartiteur distribue la charge car sinon, le répartiteur va continuer à envoyer des requêtes vers des nœuds tombés ou en surcharge.
  - Certains LB avancés (ex: option redispatch de HAProxy) permettent de rejouer une requête sur un autre nœud en cas d’échec. Cela améliore la tolérance aux pannes, mais il faut veiller à ne pas rejouer des requêtes non idempotentes (ex: POST). Pour cela, l’utilisation d’identifiants d’idempotence (ex: header HTTP `Idempotency-Key`) peut être nécessaire.
  - Lisser la charge entre les nœuds et ne pas forcement se contenter de round robin. Un algorithme simple est le LC (Least Connection) permettant de privilégier les nœuds les moins chargés, mais il existe d'autres algorithmes, comme Least Response Time, qui prend aussi en compte la latence. Dans le cloud, il peut être pertinent de combiner plusieurs critères (charge, latence, géolocalisation, etc.). Attention néanmoins à bien les tester et en maîtriser les implications pour éviter les catastrophes.
  - Dans le monde Open Source, voir par exemple LVS + Keepalived ou HAProxy + Keepalived. Pour Kubernetes, Traefik et Envoy Proxy sont des alternatives populaires, tandis que NGINX reste une référence pour des architectures classiques.
  - Il existe aussi des "LB as-a-service" comme Cloudflare Load Balancing pour les services web.
- **Clustering**:
  - Un cluster est un **ensemble de nœuds (machines) hébergeant le même module applicatif**.
  - En fonction du niveau de disponibilité recherché, chaque nœud peut être :
    - **actif** : le nœud traite les requêtes (exemple : un serveur Apache parmi dix et derrière un répartiteur de charge). Temps de failover : nul ;
    - **passif en mode «hot standby»** : le nœud de secours est installé et démarré mais ne traite pas les requêtes (exemple: une base MySQL slave qui devient master en cas de panne de ce dernier via l'outil mysqlfailover). MTTR de l'ordre de quelques secondes à quelques dizaines de secondes selon la technologie de failover (ex: Patroni pour PostgreSQL, mysqlfailover pour MySQL, Pacemaker pour un cluster Linux).
    - **passif en mode «warm standby»** : le nœud est démarré et l'application est installée mais n'est pas démarrée (exemple : un serveur avec une instance Tomcat éteinte hébergeant notre application). En cas de panne, notre application est démarrée automatiquement. MTTR : de l'ordre de la minute (temps de la détection de la panne et d'activation de l'application) ;
    - **passif en mode «cold standby»** : le nœud est un simple spare. Pour l'utiliser, il faut installer l'application et la démarrer. MTTR : de plusieurs dizaines de minutes (si l'application et son environnement sont préconfigurés) à une journée si une installation complète est requise. La virtualisation et les conteneurs (Docker, Kubernetes) peuvent accélérer la remise en service si les images sont préchargées.
  - On peut classer les architectures de clusters actif/actif en deux catégories :
    - Les **clusters actifs/actifs à couplage faible** dans lesquels un nœud est totalement indépendant des autres, soit parce que l'applicatif est stateless (le meilleur cas), soit parce que les données transitoires de contexte (typiquement une session HTTP) sont gérées isolément par chaque nœud. Dans le dernier cas, si l’application stocke des données de session en mémoire locale, un répartiteur de charge devra assurer une affinité de session ('Sticky Sessions'). En cas de panne d’un nœud, les utilisateurs affectés perdront leur session. Pour éviter cela, des solutions de stockage des sessions dans un cache distribué (ex: Redis, Hazelcast) ou en base de données peuvent être mises en place (mais ajoutent de complexité et doivent être elles-mêmes redondées pour ne pas devenir un SPOF).
    - Les **clusters actifs/actifs à couplage fort** dans lesquels tous les nœuds partagent les mêmes données en mémoire. Dans cette architecture, toute donnée de contexte doit être répliquée dans tous les nœuds (ex : cache distribué de sessions HTTP répliqué avec Redis, JGroups, Infinispan, etc.).
- **Failover (basculement automatique)** : Le failover est la capacité d'un cluster de s'assurer qu'en cas de panne, les requêtes ne sont plus envoyées vers le nœud défectueux mais vers un nœud opérationnel. Ce **processus est automatique**. Sans failover, c'est au client de détecter la panne et de se reconfigurer pour rejouer sa requête vers un nœud actif. Dans les faits, ceci est rarement praticable et les **clusters disposent presque toujours de mécanismes de failover**. Une solution de failover peut être décrite par les attributs suivants :
  - Quelle **stratégie de failover** ? Exemples :
    - Fail Fast : un nœud est marqué comme défectueux dès le premier échec détecté.
    - Fail Soft : plusieurs échecs consécutifs sont nécessaires avant de déclarer un nœud en panne.
    - Retry on Next Node : la requête est renvoyée à un autre nœud après un échec.
    - Failover à escalade : le système tente d'abord un nœud de même niveau (ex: un autre serveur d'application) avant de remonter à un niveau supérieur (ex: un cluster dans une autre zone ou région).
  - Quelle **solution de détection des pannes** ?
    - les répartiteurs de charge utilisent des **sondes** (health check) très variées (requêtes fictives, analyse du CPU, des journaux, etc.…) vers les nœuds ;
    - les détections de panne des clusters actifs/passifs fonctionnent la plupart du temps par écoute des palpitations (**heartbeat**) du serveur actif par le serveur passif, par exemple via des requêtes multicast UDP dans le protocole VRRP utilisé par keepalived.
  - Quel **délai de détection** de la panne ? Paramétrer un délai trop court peut entraîner des bascules inutiles. Il est recommandé d’utiliser un seuil (ex: 3 échecs consécutifs) pour éviter les faux positifs. En actif/actif, les nœuds en erreur peuvent être retirés rapidement, tandis qu’en actif/passif, la promotion du standby peut nécessiter plusieurs secondes.
  - Quelle **pertinence de la détection** ? le serveur en panne est-il **vraiment** en panne ? un mauvais paramétrage ou une microcoupure réseau ne doit pas provoquer une indisponibilité totale d'un cluster alors que les nœuds sont sains.
  - Quelle stratégie de failback ?
    - dans un cluster "N-to-1", on rebasculera (failback) sur le serveur qui était tombé en panne une fois réparé et le serveur basculé redeviendra le serveur de secours ;
    - dans un cluster N-to-N (architecture en voie de démocratisation avec les solutions PaaS comme AWS Lambda ou CaaS comme Kubernetes) : la charge est automatiquement redistribuée entre les nœuds restants, et un autoscaler peut ajouter de nouvelles instances si nécessaire.
  - **Transparent via à vis de l’appelant** ou pas ? La transparence du failover dépend de l’architecture. En HTTP, un répartiteur de charge peut masquer la panne en redirigeant immédiatement les requêtes vers un autre nœud. Dans le cas de bases de données, le client doit souvent gérer un retry. Les systèmes événementiels comme Kafka peuvent assurer un failover largement transparent coté producteurs, tandis que les clients doivent souvent gérer des rééquilibrages de partitions.
- La **tolérance de panne** : La tolérance de panne (FT = Fault Tolerance) ne doit pas être confondue avec la Haute Disponibilité. Il s'agit d'une version plus stricte de HA visant une disponibilité quasi absolue (99.999% ou plus) et une absence de perte de données dans des conditions normales de fonctionnement (Wikipédia: "La tolérance aux pannes est la propriété qui permet à un système de continuer à fonctionner correctement en cas de défaillance d'un ou de certains de ses composants d'infrastructure"). Seuls les systèmes critiques (santé, militaires, transport, industrie…) ont en général besoin d'un tel niveau de disponibilité. Historiquement, cela signifiait une redondance matérielle complète. Dans un monde de micro-services, cela peut également être réalisé au niveau logiciel avec des clusters actifs-actifs. De plus, un véritable système de tolérance aux pannes devrait éviter une dégradation significative des performances vue par les utilisateurs finaux. Par exemple, un lecteur RAID 1 offre une tolérance aux pannes transparente : en cas de panne, le processus écrit ou lit sans erreur après le basculement automatique sur le disque sain. Ou encore, un cache distribué mémoire en cluster peut éviter de perdre une session HTTP. Certains systèmes critiques nécessitent un niveau élevé de tolérance de panne, par exemple :
  - L'aéronautique avec les architectures Triple Modular Redundancy (TMR) utilisées dans les avions de ligne.
  - Les bases de données distribuées comme CockroachDB ou Google Spanner, qui assurent une réplication multi-région synchrone.
  - Les systèmes de messagerie comme Kafka, qui utilisent un système de réplication ISR (In-Sync Replicas).
  - Les infrastructures financières ultra-basse latence pour les transactions boursières. Pour permettre la tolérance de panne d'un cluster, il faut obligatoirement **disposer d'un cluster actif/actif avec fort couplage** dans lequel les données de contexte sont répliquées à tout moment. Une autre approche intéressante est d'éviter autant que possible les données de contexte côté serveur en favorisant leur stockage côté client (ex: dans le navigateur via localStorage ou les jetons JWT). Cependant, cette solution peut être limitée par des contraintes de sécurité et de volumétrie. Alternativement, un stockage en base de données ou en cache distribué peut être envisagé, en tenant compte des compromis entre fiabilité, performance et latence. Un système tolérant aux pannes (FT) peut rendre une erreur totalement invisible pour le client si un mécanisme de rejeu automatique, de réplication synchrone ou de reprise transactionnelle est en place (ex: Oracle RAC, PostgreSQL avec réplication synchrone, Kafka avec rejeu des messages) ; sinon, une requête en cours peut échouer et nécessiter une nouvelle soumission (ex: failover manuel en PostgreSQL, crash d’un serveur Redis non répliqué, perte d’une transaction financière en cours), ce qui peut poser un **risque d’incohérence** si l’opération n’est pas **idempotente** (ex: double facturation d’un paiement, duplication d’un message non contrôlé en MQ, insertion partielle en base de données). Attention à **bien qualifier les exigences** avant de construire une architecture FT car en général ces solutions :
  - **Complexifient l'architecture** et la rendent donc moins robuste et plus coûteuse à construire, tester, exploiter.
  - **Peuvent dégrader les performances** : les solutions de disponibilité et de performance vont en général dans le même sens (par exemple, un cluster de machines stateless va diviser la charge par le nombre de nœuds et dans le même temps, la disponibilité augmente), mais quelque fois, disponibilité et performance peuvent être antagonistes : dans le cas d'une architecture stateful, typiquement gérant les sessions HTTP avec un cache distribué (type Infinispan répliqué en mode synchrone ou un Redis persistant sur le master), toute mise à jour transactionnelle de la session ajoute un surcoût lié à la mise à jour et la réplication synchrone des caches, ceci pour assurer le failover. En cas de plantage d'un des nœuds, l'utilisateur conserve sa session à la requête suivante et n'a pas à se reconnecter, mais à quel coût ?
  - **Peuvent même dégrader la disponibilité** si les nœuds sont fortement couplés. Une mise à jour logicielle peut alors nécessiter l’arrêt de l’ensemble du cluster. Cependant, des stratégies comme les rolling updates, le blue/green deployment ou l'event sourcing peuvent atténuer ces contraintes.
  - **Peuvent créer des problèmes d'intégrité de données** dans le cas de rejeux automatiques (pour rendre l'erreur invisible au client) de requêtes non-idempotentes.
- La **Haute Disponibilité (HA)** : Un système est généralement considéré comme hautement disponible (HA) à partir de 99.9% de disponibilité (~8h45 d’indisponibilité/an). Un système HA repose généralement sur :
  - Des **mécanismes de redondance** (ex: clustering, répartition de charge, réplication).
  - Des dispositifs de **failover** pour basculer automatiquement en cas de panne. La Tolérance de Panne (FT) inclut toujours la Haute Disponibilité (HA), mais la HA ne garantit pas nécessairement la FT. .Exemples de solutions de disponibilité

### Déploiement en production `[niveau_detail::détaillé]`
- Fournir ici le modèle de déploiement des modules et composants d'infrastructure en environnement cible sur les différents intergiciels et nœuds physiques (serveurs). Ne représenter les équipements réseau (pare-feu, switchs, routeurs, etc.) que s'ils aident à la compréhension. On le documentera de préférence avec un diagramme de déploiement UML2 ou (mieux) un diagramme de déploiement C4. Pour les clusters, donner le facteur d'instanciation de chaque nœud. Préciser au besoin les contraintes d'affinité (deux modules doivent s'exécuter sur le même nœud ou le même intergiciel) ou d'anti-affinité (deux modules ne doivent pas s'exécuter sur le même nœud ou dans le même intergiciel). Exemple : Les bases de données et les serveurs d'application doivent être sur des nœuds séparés pour éviter la contention CPU et garantir l'isolation des ressources. Identifier clairement le matériel dédié à l’application (et éventuellement à acheter).

### Composants d'infrastructure `[niveau_detail::détaillé]`
- Lister ici OS, bases de données, MOM, serveurs d'application, etc. Ne détailler la version précise (le `y` ou le `z` de la version que si cette information est pertinente) .Exemple de composants d'infrastructure

### Matrice des flux techniques `[niveau_detail::approfondi]`
- Lister ici l'intégralité des flux techniques utilisés par l'application. Les ports d’écoute sont précisés. On détaille aussi les flux d'exploitation (en protocoles JMX ou SNMP par exemple). Dans certaines organisations, cette matrice sera trop détaillée pour un dossier d'architecture et sera maintenue dans un document géré par les intégrateurs ou les exploitants. Il n'est pas nécessaire de faire référence aux flux applicatifs entre modules mais aux flux entre machines car les lecteurs ne recherchent pas les mêmes informations. Ici, les exploitants ou les intégrateurs recherchent l’exhaustivité des flux à fin d'installation et de configuration des pare-feu par exemple. Les types de réseaux incluent les informations utiles sur le réseau utilisé afin d'apprécier les performances (TR, latence) et la sécurité: LAN, VLAN, Internet, LS, WAN…)

### Environnements `[taille_projet::moyen, taille_projet::grand, niveau_detail::détaillé]`
- Fournir ici une vision générale des environnements utilisés par l'application. Les environnements les plus communs sont : développement, recette, pré-production/benchmarks, production, formation. Dans les grands systèmes d'information, il est souvent utile de segmenter les environnements en "plateformes" (ou "couloirs") constituées d'un ensemble de machines isolées les unes des autres (même s'ils peuvent partager des ressources communes, selon la politique de l'organisation). Par exemple, un environnement de recette peut être constitué des plateformes `UAT1` et `UAT2` permettant à deux testeurs de travailler en isolation.

### Écoconception `[niveau::intermédiaire]`
- Les enjeux d'écoconception sont souvent alignés avec les exigences de **performance** (temps de réponse, latence, optimisation des ressources) et de **coût** (réduction de la consommation énergétique, rationalisation des infrastructures). Lorsqu’une solution impacte plusieurs de ces dimensions, il est préférable d'y faire simplement référence. Cependant, certaines pratiques sont **spécifiquement liées à l’écoconception** et doivent être prises en compte dès la conception de l'architecture.

#### Optimisation énergétique et infrastructure

#### Impact énergétique global
- Pour évaluer et améliorer l'empreinte énergétique d'un SI, des solutions comme le **Green Software Foundation** proposent des modèles d'analyse.

### Régulation de la charge `[niveau::avancé, niveau_detail::détaillé]`

#### Coupe-circuits `[niveau::avancé, niveau_detail::approfondi]`
- Dans certains cas, des pics extrêmes et imprévisibles sont possibles (effet "Slashdot"). Si ce risque est identifié, prévoir un système de fusible avec déport de toute ou partie de la charge sur un site Web statique avec message d'erreur par exemple. Ce dispositif peut également servir en cas d’attaque de type DDOS et permet de gèrer le problème et non de le subir car on assure un bon fonctionnement acceptable aux utilisateurs déjà connectés.

#### Qualité de Service `[niveau::avancé, niveau_detail::approfondi]`
- Il est également utile de prévoir des systèmes de régulation dynamiques, par exemple :
  - **Throttling** : régulation du débit des requêtes (exemple : si un client dépasse **1000 appels par minute**, ses requêtes sont mises en attente ou ralenties artificiellement).
  - **Rate Limiting** : limitation stricte du nombre d'appels qu'un client peut effectuer sur un endpoint (exemple : chaque client est limité à **100 appels/minute sur le endpoint E**. Toute requête excédentaire retourne une **erreur 429 Too Many Requests**).
  - **Systèmes de jetons** (pour les intranets dont on maitrise les machines) : chaque client dispose d'un quota de jetons qui limite ses appels. Ce système permet d’accorder des **priorités différenciées** en attribuant plus de jetons à certains clients stratégiques.

### Gestion des timeouts `[niveau::intermédiaire, niveau_detail::détaillé]`
- Tous les appels distribués (ex : HTTP(S) vers des API, accès à un stockage objet, requêtes vers une base de données) doivent être **strictement limités en temps de connexion et en temps d'exécution**. Sans timeouts appropriés, des contentions peuvent émerger, entraînant des **blocages critiques et une saturation des ressources** en cas de ralentissement des systèmes. **Principes clés :**
  - **Définir des timeouts progressifs** le long de la chaîne de liaison.
  - Ex : **10 s sur le reverse proxy**, **8 s sur l’API REST**, **5 s sur la base de données**.
  - Objectif : éviter qu’un service d'infrastructure continue de traiter une requête alors que son module appelant a déjà abandonné.
  - **Éviter des valeurs de timeout identiques partout**, ce qui pourrait provoquer des pics d’expiration simultanés et des effets de cascade indésirables.
  - **Utiliser un retry intelligent avec un backoff exponentiel** (augmentation progressive du délai entre chaque nouvelle tentative).
  - **Ajouter un jitter** au backoff exponentiel pour éviter des pics de charge si plusieurs requêtes expirent en même temps. **Jitter :**
  - Si plusieurs clients échouent en même temps et appliquent un **retry avec un délai fixe**, ils risquent de saturer le système.
  - Le jitter consiste à **ajouter une variabilité aléatoire** au délai du backoff exponentiel pour éviter ces pics de charge.
  - Exemple :
  - **Sans jitter** : Tous les clients refont une requête après **1s, puis 2s, puis 4s…** → Risque d’embouteillage.
  - **Avec jitter** : Les retries sont espacés de **1.1s, 1.8s, 3.6s, 4.2s…** → La charge est mieux répartie.

### Exploitation
- Lister ici les grands principes d’exploitation de la solution. Les détails (contenu des sauvegardes, plan de production, planification des traitements, etc.) seront consignés dans un Dossier d’EXploitation (DEX) séparé ou -mieux encore- codés sous la forme d'IaC (Infrastructure As Code). Si cette application suit les standards de l'organisation, il suffit de se référer au dossier d'exploitation commun.

#### Ordre d’arrêt/démarrage `[niveau::intermédiaire, niveau_detail::détaillé]`
- Préciser ici l’ordre de démarrage des machines et modules entre eux ainsi que l’ordre d’arrêt. En fonction des situations, on peut faire figurer les modules externes ou non. En général, le démarrage suit l'ordre inverse de la chaîne de liaison, tandis que l'arrêt respecte l'ordre de dépendance des composants. Préciser d'éventuelles contraintes en cas de démarrage partiel (exemple : le pool de connexions du serveur d’application retente-t-il la connexion à la base de données si celle-ci n'est pas encore disponible ? Combien de fois ? À quelle fréquence ?).

#### Opérations programmées et suivi `[niveau::intermédiaire, niveau_detail::détaillé]`
- Décrire ici les principes portant sur les opérations programmées et leur suivi, y compris quand pertinent :
  - Les jobs et leurs éventuelles interdépendances (ordre d'exécution, contraintes, fréquence).
  - Les traitements internes (tâches de nettoyage, maintenance) qui remplissent uniquement des rôles techniques (purges, reconstruction d'index, suppression de données temporaires…).
  - L’ordonnanceur ou planificateur utilisé pour piloter les jobs et consolider le plan de production (exemple : VTOM, JobScheduler, Dollar Universe, Control-M, etc.).
  - Les éventuelles spécificités applicatives :
  - Degré de parallélisme des jobs ;
  - Plages de temps obligatoires ;
  - Rejeux en cas d'erreur ;
  - Production de rapports d’exécution (contenu et format). Il est également crucial de définir les mécanismes de supervision ou d'alerte pour détecter les échecs des jobs critiques.

#### Mise en maintenance `[niveau::intermédiaire, niveau_detail::approfondi]`
- Détailler les dispositifs et procédures permettant de mettre l'application offline de façon explicite pour les utilisateurs.

#### Sauvegardes et restaurations `[niveau_detail::détaillé]`

##### Périmètre
- Quel est le périmètre de la sauvegarde  ?
  - des images/snapshots systèmes pour restauration système de serveur ou de VM complets ?
  - des systèmes de fichiers ou des répertoires ?
  - des bases de données sous forme de dumps ?
  - les journaux ? les traces ?

##### Stratégie de sauvegarde
- Fournir la politique générale de sauvegarde. Elle doit répondre aux exigences de RPO. De même les dispositifs de restauration doivent être compatibles avec les Exigences de disponibilité.
  - Quels types de sauvegardes sont effectués ? À chaud ? En lecture seule ? À froid (nécessitant un arrêt de service) ?
  - Quelle est la périodicité de chaque type de sauvegarde ? (ne pas trop détailler ici, ceci sera dans le DEX)
  - Quelle est la stratégie de sauvegarde ?
    - complètes ? incrémentales ? différentielles ? (prendre en compte les exigences de RTO. La restauration d'une sauvegarde incrémentale sera plus longue qu'une restauration de sauvegarde différentielle, elle-même plus longue qu'une restauration de sauvegarde complète) ;
    - quel roulement ? (si les supports de sauvegarde sont écrasés périodiquement).
  - Comment se fait le bilan de la sauvegarde ? par courriel ? où sont les journaux ? Sont-ils facilement accessibles ? Contiennent-ils des informations sensibles ?

##### Outillage
- Lister ici les outils utilisés pour les différents types de sauvegardes. Quel outillage est mis en œuvre ?
  - Simple cron + rsync + tar ?
  - Outil Open Source orienté fichier comme « backup-manager » ?
  - Outil de sauvegarde dédupliquée type Restic, Borg, Kopia...)
  - Outil orienté imaging de VM comme Veeam ou FSArchiver ?
  - Outil orienté Cloud comme « Duplicity » ou « Restic » ?, etc.
  - Outil de sauvegarde spécifique de base de données (comme MySqlDump, Barman...) ?

##### Traitements sur les sauvegardes
- Lister ici les opérations réalisées sur les sauvegardes :
  - Les données sont-elles dédupliquées ? (un même fichier voire bloc de donnée identique sur la source n'est stocké qu'une fois dans tout le jeu de sauvegarde). La plupart des solutions modernes utilisent ce principe. Par exemple des outils Open Source comme Restic ou propriétaires comme Veeam utilisent massivement de type de fonctionnement (proche du fonctionnement d'un dépot Git) pour réduire drastiquement la taille des sauvegardes et éliminer le besoin de sauvegardes full.
  - Les sauvegardes sont-elles chiffrées ? si oui, chiffrement de la partition toute entière, fichier par fichier, les deux ? Faut-il chiffrer également le nom des répertoires et fichiers sauvegardés ? Préciser l'algorithme de chiffrement utilisé et comment seront gérées les clés (coffres-forts numériques, code de secours...).
  - Les sauvegardes sont-elles compressées ? si oui, avec quel algorithme ? (lzw, deflate, lzma?, …), avec quel niveau de compression ? attention à trouver le compromis entre durée de compression / décompression et gain de stockage.
  - Doit-on proposer des fonctionnalité de 'Point In Time Recovery' (PITR), pour permettre une restauration à la situation d'un instant précis paramétrable ?
  - Les sauvegardes sont-elles protégées de l'écriture et de l'effacement (anti-ransomware) ? Si oui, de façon temporaire ou définitive ?
  - Autres fonctionnalités ? (tests d'intégrité, nettoyage automatique dans l'archive, refactoring des fichiers dans l'archive, ...)

##### Modalités de stockage
- Préciser le(s) media de stockage des sauvegardes utilisé(s), son lieu de stockage...
  - Le média est-il offline, near-line (accessible via un robot de sauvegarde dans une librairie de cassettes) ou online (accessible en permanence) ? Attention, les sauvegardes online et même near-line sont vulnérables aux erreurs humaines et aux ransomwares.
  - Quelle technologie de stockage est utilisée pour les sauvegardes ? (bandes magnétiques type LTO ou DLT ? disques externes ? cartouches RDX ? cloud de stockage comme Amazon S3 ? support optique ? NAS ? etc.)
  - Où sont stockées physiquement les sauvegardes ? (idéalement offline et le plus loin possible du système sauvegardé tout en permettant une restauration dans un temps compatible avec le RTO).
  - Quelle est la législation du pays hébergeant nos sauvegardes ? Est-ce compatible avec les exigences juridiques comme le RGPD ? (voir le Cloud Act américain).
  - Qui accède physiquement aux sauvegardes et à ses journaux ? à la clé de chiffrement ? (penser aux exigences de confidentialité).
  - Avons nous connaissance de toutes les dépendances externes pouvant nous ralentir (coffre de banque accessible en journée uniquement par exemple) ?
  - Il est fortement préconisé :
    - d'utiliser un support distinct des données sources ;
    - de disposer d'au moins deux supports de stockage distincts si les données sont vitales à l'organisation ;
    - de faire en sorte que les sauvegardes ne soient pas modifiables par la machine qui a été sauvegardée (par exemple, une sauvegarde sur NAS peut être supprimée par erreur en même temps que les données sauvegardées).
  - Règle des "3-2-1" pour les données importantes : il faut au moins deux copies en plus des données de production, stockées sur deux supports de technologie différentes et au moins une copie offline sur un site externe sécurisé (exemple: coffre-fort en banque).

##### Restauration
- Toujours garder à l'esprit que ce que nous voulons _vraiment_, ce sont des restaurations, pas des sauvegardes. Il est crucial de s'assurer que la restauration sera fonctionnelle :
  - Les sauvegardes sont-elles correctes et complètes ?
  - Quels tests de restauration sont prévus ? à quelle fréquence [un test annuel est un minimum] ?
  - Combien de temps une restauration prendra-t-elle  ? Est-ce compatible avec le RTO ?
  - Comment sont gérées les erreurs ? (rejeux, timeouts, journaux, alertes, etc.)
  - Avons nous suffisamment de ressources hardware pour la restauration dans le temps imparti par le RTO (stockage intermédiaires, CPU et mémoire pour la décompression/déchiffrement , etc…) ?
  - Comment se font les tests de restauration ?
    - Quels jeux de tests ?
    - Quel formalisme de bilan / suivi ?
    - Où se trouvent les journaux ?
    - Risque-t-on d'écraser par erreur les données de production pendant les tests de restauration ? (si oui, tester sur une autre plateforme)
    - Les données restaurées lors du test sont-elles bien chiffrées (le test de restauration ne doit pas faire courir un risque de perte de confidentialité massive) ?
    - ...

#### Journaux `[niveau::intermédiaire, niveau_detail::détaillé]`
- Sans être exhaustif sur les fichiers de journaux (à prévoir dans le DEX), présenter la politique générale de production et de gestion des journaux (le contenu des journaux est abordé quant à lui dans la vue développement):
  - **Politiques de roulement et rétention** :
    - Comment sont gérés les fichiers de journaux ? Rotation applicative (`DailyRollingFileAppender` log4j, logback) ou système (`logrotate`) ?
    - Quelle politique de rétention est appliquée ? (ex : durée de conservation, taille maximale avant suppression)
    - Où sont stockés les anciens journaux ? (fichiers locaux, stockage objet, archive centralisée...)
  - **Centralisation et exploitation des journaux** :
    - Une solution de collecte et d’analyse des journaux est-elle mise en place ? (ELK, Loki, Splunk…)
    - Un monitoring des logs en temps réel est-il prévu ? (alertes sur erreurs critiques)
  - **Niveaux de journalisation** :
    - Quel niveau de journalisation est prévu par type de module (`WARN`, `INFO`, `DEBUG`…) ?
    - L'application doit-elle permettre de modifier dynamiquement le niveau de logs en production (ex: via JMX, API) ?
  - **Sécurité et conformité** :
    - Les logs sont-ils protégés contre les injections (`Log Injection`) ?
    - Une anonymisation ou pseudonymisation des données sensibles est-elle prévue ? (RGPD)
    - Vérifier la protection contre la modification ou suppression non autorisée des logs.
    - Si les journaux sont accessibles en consultation, quel est le mécanisme d'authentification et d'autorisation ?

### Supervision `[niveau::intermédiaire, niveau_detail::détaillé, supervision]`
- La supervision est un **pilier de la disponibilité** en permettant de réduire drastiquement le **MTTD (Mean Time to Detect, temps moyen de détection d’une panne)**. Une supervision efficace ne doit pas être **uniquement réactive** (alerte en cas de panne) mais aussi **proactive** en détectant les signaux faibles avant qu’une défaillance ne survienne.
  - **Métriques** : données brutes collectées (% CPU, taille FS, nombre de requêtes, etc.), issues de sondes système, middleware ou applicatives.
  - **Indicateurs** : combinaisons de plusieurs métriques avec des seuils d’alerte (ex : _"alerte critique si l'utilisation CPU du serveur `s1` dépasse 95% pendant plus de 5 minutes"_).

#### Supervision technique `[niveau::intermédiaire, niveau_detail::approfondi, supervision]`
- Lister ici les **métriques techniques (infrastructure & middleware)** à superviser :
  - **Système** :
  - Utilisation CPU (%), charge moyenne (`load average`), usage mémoire (%), swap in/out.
  - Occupation disque et file system (% d’utilisation, inodes libres).
  - Utilisation réseau (latence, débit, taux d’erreurs).
  - Nombre de processus actifs et threads.
  - IO wait (temps CPU bloqué en attente d’IO).
  - **Middleware & bases de données** :
  - % de **HEAP utilisée** sur une JVM.
  - Nombre de **threads actifs** sur une JVM.
  - Utilisation d’un **pool de threads** ou **pool de connexions JDBC**.
  - Temps de réponse moyen d’une base de données, nombre de requêtes en attente, taux de cache hit.
  - Statistiques de garbage collection (GC).

#### Supervision applicative et métier `[niveau::intermédiaire, niveau_detail::approfondi, supervision]`
- Lister ici les métriques **applicatives** ou **métier** :
  - **Métriques applicatives** :
  - Nombre de requêtes HTTP reçues par service.
  - Temps de réponse moyen par API REST.
  - Taux d’erreur (5xx) des services.
  - **Métriques métier** :
  - Nombre de contrats traités dans l’heure.
  - Volume de commandes validées / rejetées.
  - Nombre de colis à expédier en attente. **Business Activity Monitoring (BAM)** : Une couche BAM peut être mise en place pour générer des indicateurs orientés **processus métier** à partir de ces métriques.

#### Outils de supervision & monitoring `[niveau::intermédiaire, niveau_detail::approfondi, supervision]`
- Une plateforme de supervision collecte, stocke et analyse les métriques en temps réel. Les outils Open Source les plus courants sont :
  - **Collecte des métriques** :
  - **Prometheus** (scraping métriques en HTTP).
  - **Telegraf** (agent pour collecter CPU, mémoire, réseau, etc.).
  - Protocoles **SNMP, JMX** pour monitoring système et JVM.
  - **Stockage des métriques** (bases de données de séries temporelles) :
  - **InfluxDB, Prometheus TSDB, TimescaleDB**.
  - **ElasticSearch** (si besoin de logs en plus des métriques).
  - **Visualisation et alerte** :
  - **Grafana** (tableaux de bord interactifs), **Kibana**.
  - **Zabbix, Netdata, Nagios** (supervision système classique). Les indicateurs sont ensuite affichés via **tableaux de bord dynamiques** et des **seuils d’alerte** sont définis pour notifier les équipes.

#### Alerting & notifications `[niveau::intermédiaire, niveau_detail::détaillé, supervision]`
- Définir les **conditions de déclenchement des alertes** et les **canaux de notification** :
  - **Types d’alertes** :
  - **Critique** (urgence) → serveur hors ligne, saturation disque, crash applicatif.
  - **Avertissement** → tendance à la hausse, signaux faibles (ex : mémoire consommée > 80%).
  - **Canaux de notification** :
  - Alertes **par e-mail** (non-urgent).
  - **Slack, Mattermost, Microsoft Teams** (suivi opérationnel).
  - **SMS ou PagerDuty** (urgence, astreintes 24/7).
  - **Règles de déclenchement et d'arrêt** :
  - Répétition sur une période avant alerte (éviter le bruit).
  - Conditions de fin d'alerte...

#### Supervision boite noire `[niveau::intermédiaire, niveau_detail::détaillé, supervision]`
- Il est également fortement souhaitable et peu coûteux de prévoir un système de **tests de supervision boite-noire** (via des scénarios déroulés automatiquement). L'idée est ici de tester un système dans son ensemble et avec une vue end-user la plus externe possible (à l'inverse d'une supervision whitebox pour laquelle on supervise des modules bien précis avec un comportement attendu). En général, ces tests sont simples (requêtes HTTP depuis un curl croné par exemple). Ils doivent être lancés depuis un ou plusieurs sites distants pour détecter les coupures réseaux. Il est rarement nécessaire qu'ils effectuent des actions en mise à jour. Si tel est le cas, il faudra être en mesure d'identifier dans tous les modules les données issues de ce type de requêtes pour ne pas polluer les données métier et les systèmes décisionnels.

#### Mesure et suivi des performances `[niveau::avancé, niveau_detail::détaillé, supervision]`
- Le suivi des performances de l'application en production est essentiel pour :
  - Disposer d'un retour factuel sur les performances _in vivo_, permettant d'améliorer la qualité des décisions pour un éventuel redimensionnement de la plate-forme matérielle.
  - Aider à la correction de problèmes en production.
  - Réaliser des analyses statistiques sur l’utilisation des modules pour guider la prise de décision (exemple : décommissionnement d'une application peu utilisée). Trois grandes familles de solutions existent :
  - **APM (Application Performance Monitoring)** : Ces outils injectent des sondes avec un impact limité sur l'application, collectent les données et les restituent sous forme de tableaux de bord. Certains reconstruisent même les chaînes de liaison complètes grâce à des identifiants de corrélation injectés lors des appels distribués. **Exemples** : Oracle Enterprise Manager, Oracle Mission Control, Radware, BMC APM, Dynatrace, Glowroot (Open Source), etc. ⚠ Vérifier que l'overhead (impact sur les performances) de ces solutions est négligeable ou maîtrisé.
  - **Métrologie maison par journaux** : Une solution simple pour des besoins modestes, utilisant les logs applicatifs pour extraire des métriques de performance.
  - **Sites de requêtage externes** : Ces services effectuent des appels périodiques vers l'application et génèrent des tableaux de bord. Ils permettent de prendre en compte les temps de transit sur le WAN, ce qui n'est pas possible avec des outils internes. À utiliser en complément de la supervision en boîte noire.

### Décommissionnement `[niveau::intermédiaire]`
- Ce chapitre sera complété lorsque l’application arrivera en fin de vie et devra être supprimée ou remplacée. Il décrit notamment :
  - Les **données** à archiver ou, au contraire, à détruire avec un **haut niveau de confiance**.
  - Les **équipements physiques** à évacuer, recycler ou détruire de manière sécurisée.
  - Les **procédures de désinstallation** côté serveur et/ou client (il est courant que des modules obsolètes restent en exécution, entraînant des risques de **performance et de sécurité**).
  - Les **contraintes de sécurité** associées au décommissionnement (c'est une **étape critique** souvent négligée ; par exemple, des disques durs remplis de **données sensibles** peuvent être récupérés après un simple don de matériel).
