# Security view
- Regularly perform full reviews of this view (at least once a year while the project is active) update the date above.
- Indicate the status of the view, for example 'DRAFT', 'FINALIZED', ...

## Introduction `[context]`
- Availability is dealt with in the infrastructure section. Even if availability concept is often handled with Integrity and Confidentiality (the "CIA triad"), this model is role-oriented and we feel that availability is more often managed by infrastructure architects than by the security experts.

### Reference Documentation `[context, references]`
- Mention here the reference (defined at IS level) architecture documents. This file should never summarize their content under penalty of quickly becoming obsolete and unmaintainable.

## Not ruled `[context, uncertainty]`

### Points subject to further study

### Assumptions
- Give here the structuring assumptions taken for the design.

## Constraints `[detail_level::overview, constraint]`
- List here the **security constraints** applicable to the architecture, including in particular:
  - **Module isolation** within secured network zones (_DMZ, firewalls, reverse proxy, network segmentation, etc._).
  - **Applicable standards and policies** (_e.g., password policies, encryption requirements, MFA, compliance with security standards_).
  - **Legal and regulatory constraints** (_e.g., GDPR compliance, industry-specific requirements_).
  - **Access restrictions** between different zones and systems.

## Requirements `[detail_level::overview, requirement]`
- Present here the **requirements**, **not the measures or controls addressing them**. Those will be detailed in Chapter 3. For particularly sensitive projects, prepare a **risk analysis dossier**. Possible methodologies include:
  - The **NIST Risk Management Framework (RMF)** (NIST SP 800-37) or **ISO/IEC 27005** for information security risk management.
  - The [EBIOS Risk Manager](https://cyber.gouv.fr/en/publications/ebios-risk-manager-method) (_Expression of Needs and Identification of Security Objectives_) method.

### Integrity Requirements
- Integrity refers to the **accuracy, durability, and trustworthiness** of the application’s data. Guaranteeing data integrity means ensuring that data **cannot be altered or deleted** either unintentionally (_e.g., disk crash, software corruption, application bug_) or intentionally (_e.g., man-in-the-middle attack, privilege escalation, insider sabotage_). ⚠ **Do not multiply data classes unnecessarily**. A single classification for the entire application is often sufficient. .Required integrity level by data class (example)

### Confidentiality Requirements
- Confidentiality is the guarantee that information **is accessible only to authorized individuals** (ISO 27018 definition). **Best practices**:
  - Do not multiply data classes unnecessarily. A single classification may be sufficient for the entire application.
  - Ensure that confidentiality levels are **consistent with legal and contractual requirements**. .Required confidentiality level by data class (example)
- **Examples of applying confidentiality levels**:
  - **Public** → Web pages accessible without login.
  - **Limited** → Information restricted to authenticated users (e.g., SaaS dashboard).
  - **Restricted/confidential** → Sensitive internal data (e.g., system logs not accessible to customers).
  - **Private** → Personal data visible only to the concerned user (e.g., payslip).

### Identification Requirements
- Identification makes it possible to **assign a unique identifier** to each user in order to distinguish them from others. **Note:** Identification **does not guarantee** that the user is who they claim to be. That is the role of authentication (e.g., password, MFA, etc.).
- **Best practices**:
  - **Favor stable and unique identifiers** (email, customer number, UUID, etc.).
  - **Avoid re-assignable identifiers** (e.g., incremental numeric IDs that may be reused after account deletion).
  - **Ensure identifier consistency** across all systems where it is used.

### Authentication Requirements
- Authentication verifies that a user is truly who they claim to be by validating their identity using one or more proof factors. ⚠ **Do not confuse authentication with identification**, which only distinguishes one user from another without validating identity. **Special cases:**
  - **Technical accounts** (e.g., batch jobs, applications, APIs) also require authentication (e.g., service accounts with certificates or SSH keys).
  - **Privileged accounts** (e.g., `root` on servers, application administrator accounts...). These can be human or technical but have access to read/write/delete large amounts of data or perform irreversible actions (large blast radius).
  - **Initial authentication** (during registration) is often stricter than subsequent authentications.
  - **Federated authentication** allows delegation of authentication to an identity provider (SSO, OAuth2, SAML, etc.). See the following section. **Authentication Factor Categories**

### Identity Federation Requirements `[level::advanced, detail_level::detailed]`
- Identity federation allows a user to **reuse their credentials** managed by an **Identity Provider (IdP)** to authenticate across multiple independent systems. Unlike **Single Sign-On (SSO)**, which ensures automatic login without re-entering credentials, federation **does not bypass authentication** but centralizes identity management. **Common examples:**
  - **Login.gov (US)** → Based on OpenID Connect, it enables US citizens to access federal services (IRS, Social Security, etc.) using a single account.
  - **"Sign in with [Google | Facebook | GitHub]"** → Implemented via **OpenID Connect** or **OAuth2**, allowing the use of a third-party account for authentication on another platform. **Advantages of identity federation:**
  - **Simplifies account management** → Fewer credentials for the user to remember.
  - **Reduces maintenance costs** → Fewer password resets and less user management overhead.
  - **Improves security** → Centralizes authentication with a trusted IdP, enabling strong authentication and MFA integration.

### SSO and SLO Requirements `[level::advanced, level::advanced]`
- **Single Sign-On (SSO)** allows a user to authenticate once and gain access to multiple applications without re-entering credentials. **Single Log-Out (SLO)** ensures that logging out of one application automatically logs the user out of all other applications within the same trust domain. **Key considerations:**
  - **SSO can be complex** to implement, especially if an Identity Provider (IdP) infrastructure is not yet in place.
  - **Applications must be compatible** with the chosen protocol (SAML, OIDC, Kerberos, etc.).
  - **The business need must be justified** → An application used infrequently may not require SSO.
  - **Security risk** → A **weak authentication method** for one SSO-enabled application compromises the entire system (e.g., one weak password can expose all applications accessible via SSO). **Best practices:**
  - Define **limited trust boundaries** (e.g., SSO only for internal applications).
  - Use **strong authentication (MFA)** to reduce impersonation risks.
  - Properly manage **sessions and token expirations**.
  - Consider **simpler centralized authentication (LDAP, CAS)** if full SSO is not justified.

### Non-repudiation Requirements `[level::advanced]`
- Non-repudiation ensures that a user or an organization cannot deny having performed a specific action (signature, approval, transaction, etc.). In modern information systems, non-repudiation relies almost systematically on cryptographic mechanisms. **Typical use cases:**
  - Signing of **contracts and legal commitments**.
  - Validation of **sensitive financial transactions**.
  - Submission of **official documents** (e.g., tax returns, notarized acts). **Regulatory references:**
  - **United States** → The **ESIGN Act** (Electronic Signatures in Global and National Commerce Act) and **UETA** (Uniform Electronic Transactions Act) establish the legal validity of electronic signatures.
  - **European Union** → The **eIDAS Regulation (EU 910/2014)** defines the framework for electronic identification and trust services, including **qualified electronic signatures** with strong non-repudiation guarantees. **Non-repudiation requirements by use case (example)**

### Anonymity and Privacy Requirements
- List the constraints of anonymity and legal privacy.

### Authorization Requirements `[level::intermediate]`
- An authorization (also referred to as **access right**, **entitlement**, **privilege**, or **permission**) makes it possible to **control access** to a specific application function for a user or a group of users. **Examples of application functions:**
  - “Perform an interbank transfer”
  - “View account history”
  - “Delete a user” ⚠ It is recommended **not to excessively multiply** functions and roles in order to avoid a combinatorial explosion and high management costs. **Best practices to simplify authorization management:**
  - **Group** users into **groups** (e.g., `G_chef_service`).
  - **Associate** a list of **functions** with a **role** (e.g., `R_Administrator`, `R_banker_level1`, `R_chef_service`).
  - **Assign** roles to **users or groups** to improve factorization and maintainability. **Classic RBAC-style authorization management model:** image::diagrams/roles.svg[Classic role management] **Pseudo-users and predefined roles**: Remember to specify generic users such as:
  - **`@anonymous`**: unauthenticated users.
  - **`@authenticated`**: authenticated users. **Authorization delegation (OAuth2, etc.):** If the application **delegates or consumes** authorizations via an **external system (OAuth2, OpenID Connect, etc.)**, it is necessary to specify:
  - **Is the application an authorization provider or a consumer?**
  - **Which types of authorizations are involved?**
- 

### Traceability and auditability Requirements `[level::intermediate]`
- List here the trace requirements for detecting, for example:
  - Misuse of back-office applications by employees
  - Computer intrusions
  - Data alteration The traces are nominative and complete to allow auditing. They are therefore themselves sensitive and often require a good level of confidentiality. Differentiate:
  - Application traces, i.e., assessments of a complete use case such as 'Agent X consulted Ms. Y's file' and that are stored in databases;
  - ... and the application traces (logs) as in a log file: `[INFO] 2016/12/23 11:14[Agent X] Call of the consult service` which are of technical level and much more volatile. For the most sensitive data, traceability can be implemented at two levels (including traceability of access to audit logs) in order to prevent abusive or excessive hierarchical monitoring. Traceability for repository data (typically master data such as person records) requires full historization, which is considered a best practice in any case. This involves recording both the modification date and the effective date for each change. Audit logs must also be subject to defined retention and purging policies.

## Security measures `[solution]`

### Integrity
- List here the measures ensuring the required level of integrity. **Examples of mechanisms associated with the required integrity level:**
  - **Detectable** → Access logs, integrity checks using digital fingerprints (hashes), and a posteriori detection of data alteration.
  - **Controlled** → Version retention, auditability of changes, and automatic correction or recomputation mechanisms when an error is detected.
  - **Integrity ensured** → Encryption, digital signatures, synchronous replication, immutable storage (WORM), trusted timestamping, and strong integrity proofs.

### Confidentiality
- .Measures to ensure the required level of confidentiality (example)

### Identification
- Describe here the method of identification for users and systems (batch jobs, APIs, external services). Specify the identification attributes and the mechanisms that guarantee the **uniqueness** and **persistence** of identifiers.

### Authentication
- Describe here the authentication mechanisms in place, including:
  - The method of authentication secrets storage and verification.
  - Any additional authentication factors.
  - The lifecycle management of credentials (creation, update, deactivation).

### Identity Federation `[level::advanced, detail_level::detailed]`
- The most common solutions currently are:
  - **OpenID Connect (OIDC)**: a modern protocol built on OAuth 2.0, well-suited for web and mobile applications.
  - **SAML**: mainly used for enterprise SSO (e.g., ADFS, Shibboleth, Okta).
  - **OAuth 2.0**: only for **authorization**, not authentication (pseudo-authentication possible via an additional IdP). For web applications, specify **browser-related constraints** (cookie handling, SameSite policy, etc.).

### SSO and SLO `[level::advanced, level::advanced]`
- Describe here the chosen technology and its integration within the architecture. Some common solutions:
  - **CAS** (Central Authentication Service)
  - **Keycloak**
  - **ForgeRock OpenAM**
  - **LemonLDAP::NG** (open source)
  - **Okta, Azure AD, Ping Identity** (widely used in enterprises) Be sure to specify web-specific constraints, including **cookie management**, **session tokens**, and the implications of **SameSite / CORS** policies.

### Service Accounts `[detail_level::detailed]`
- **Service accounts** are used to authenticate an application or a batch job when accessing an infrastructure service (database, API, etc.). **Best practices:**
  - **Secure storage** of credentials (avoid storing secrets in plain text within configuration files).
  - **Automatic rotation** of secrets where possible (e.g., HashiCorp Vault, AWS Secrets Manager, Azure Key Vault).
  - **Minimal permissions** following the **Principle of Least Privilege**. .Service accounts (examples)

### Non-repudiation and Timestamping `[level::advanced]`
- **Cryptographic timestamping** is not a standalone requirement but is most often used **together with a digital signature** to ensure non-repudiation. Timestamping prevents any **alteration of dates** (**backdating or postdating**). It relies on **qualified timestamp tokens** (**RFC 3161, eIDAS in EU**) issued by a **trusted timestamping authority (TSA)**. In the US, this role may be provided by **trusted CAs** or services compliant with **NIST digital signature and timestamping standards**.

### Anonymity and Privacy

### Authorizations (Access Rights) `[level::intermediate]`

### Traceability and Auditability `[level::intermediate]`

### Cyberthreat Mitigation `[level::intermediate]`

#### Prevention Solutions

#### Detection Solutions

#### Response Solutions

#### Prediction Solutions `[level::advanced]`

## Annexes `[annexe]`

### RACI & Security Governance `[level::intermediate, detail_level::detailed]`
- In a good RACI, there should **never** be more than one A per line.

### Vulnerability Self-Assessment `[level::intermediate, detail_level::detailed]`
- Vulnerability management follows the **OWASP Top 10**, **MITRE ATT&CK**, and **NIST 800-53** standards. Objective: Verify that **protection, detection, and remediation measures** are correctly applied to reduce the risk of attacks (e.g., ransomware, supply chain attacks, injections…).
