# Development view
- Regularly perform full reviews of this view (at least once a year while the project is active) update the date above.
- Indicate the status of the view, for example 'DRAFT', 'FINALIZED', ...

## Introduction `[context]`

### Reference Documentation `[context, references]`
- Mention here the reference (defined at a IS level) architecture documents. This file should never summarize their content under penalty of quickly becoming obsolete and unmaintainable.

## Not ruled `[context, uncertainty]`

### Points subject to further study

### Assumptions
- Give here the structuring assumptions taken for the design.

## Constraints `[detail_level::overview, constraint]`
- List here the constraints related to the software architecture, this includes for example but not only:
  - The obligation to use a framework or a specific technology
  - Maximum licenses or development budgets
  - Tooling (IDE, ...)
  - Continuous integration
  - The applicable code quality standards and thresholds
  - Test methods and objectives (coverage rate, breakdown by type of test, etc.)

## Non-Functional Requirements `[detail_level::overview, requirement]`
- Contrary to the constraints which fixed the framework to which any application had to conform, the non-functional requirements were given by the project decision-makers. Schedule interviews to determine them. If some requirements are not realistic, mention this in the reference points to be decided. Avoid introducing new ergonomic “concepts” so as not to confuse users (principle of least astonishment).

### Accessibility Requirements `[gui]`
- Should this application be accessible to the blind/visually impaired? deaf person? If so, what level of accessibility? Preferably refer to the Web Content Accessibility Guidelines ([WCAG 2.0](https://www.w3.org/TR/WCAG20/)). There are other accessibility standards. Be careful to correctly assess the target level (neither over-quality nor under-quality):

### Ergonomics Requirements `[gui]`

#### Specificities on UX `[detail_level::detailed]`
- In general, we refer here to the body's ergonomic charter. List any specificities. Do not duplicate here the accessibility constraints listed above.

#### Specificities on widgets `[detail_level::in-depth]`
- Very precise ergonomic behavior can have a fairly strong impact on the architecture and impose a widgets library or another. It is strongly advised not to customize existing libraries (high maintenance cost, high complexity).

#### Fonts Requirements `[detail_level::in-depth]`
- Describe here the fonts to use for web pages, applications, or generated documents. The choice of fonts follows licensing constraints. In order to ensure legal security aspects of the project, pay attention to commercial policies subject to royalties (in particular policies of Microsoft such as Times New Roman, Courier, Verdana, Arial) and which do not allow to produce documents without going through their editors (Word, ...). Redhat, for instance, provides four families of TrueType fonts (Liberation) under an Open Source license that is legally secure and compatible with the Monotype, Courier-New, Arial and Times New Roman.

#### Responsive Website Requirements `[level::intermediate, detail_level::in-depth]`
- List the multi-media display constraints. When possible, use modern frameworks (such as AngularJS or React.js). There are several levels of adaptation of web pages:
  - Static (fixed page width).
  - Dynamic (automatic resizing, sizes are expressed in %).
  - Adaptive (distances are expressed in units, the size of which depends on the support).
  - Responsive (the content and its layout depend on the medium).
- A responsive design comes with its constraints (code duplication, increase in the volume of data to be downloaded by the client, complexity, more end-to-end tests to be expected…).

#### Progressive Web Apps (PWA) Requirements `[level::advanced, detail_level::in-depth]`
- Specify whether the application is progressive. PWA applications are HTML5 web applications having all the attributes of native applications (offline-first, fast, adaptive, accessible from the OS, ...)

#### Supported Browsers Requirements
- Specify which browsers are supported if your project comes with a Web GUI. When addressing an audience whose you do not manage browsers (such as a website on the Internet), the best option to make things intelligible and clarify the issues is to negotiate with the stakeholders of the project a minimum percentage audience supported based on [statistics](https://gs.statcounter.com/). For example: "Support 95% of browsers".
- Supporting old browsers (IE in particular) can generate prohibitive additional costs and security issues. In all cases, the additional costs of testing on multiple platforms should be assessed. There are good (paid) tools like Litmus or EmailOnAcid to render websites and HTML emails on a combination of OS / player type (PC / tablet / mobile) / browser very large. This type of site is essential when testing applications intended for the general public.

#### Offline Mode Requirements `[level::intermediate, project_size::large, detail_level::overview, constraint]`
- Specify whether the application must be able to continue to function without Internet or LAN access (very common for applications used by professionals on the move for example). These can be classic heavy clients (Java, C, ...) having their local database that can be synchronized back to the office. They can also be PWA applications (see above) using a service worker for static resources and browser storage (local storage, IndexedDB database, ...).

#### Internationalization (i18n) Requirements
- Specify the constraints of the application in terms of i18n: location of labels, direction of the text, adaptable layout, specific color code, date format, currencies, display of decimal separators, etc.

### SEO Requirements `[gui]`
- SEO (Search engine optimization) concerns the visibility of a website through search engines (like Google or Baidu).

### Ecodesign Requirements
- Ecodesign consists of limiting the environmental impact of the software and hardware used by the application. The requirements in this area are generally expressed in WH or CO2 equivalent. List the eco-design requirements relating to software here.

## Target architecture `[detail_level::overview, solution]`

### Software stack

#### Stack profile `[level::advanced]`
- Detail the technologies chosen from the organization's catalog. If there are any discrepancies with the catalog, specify and justify it.

#### Main dependencies
- List here for each dependency the main libraries and frameworks used as well as their major version. Do not list the libraries supplied to the runtime by the application servers or the frameworks. There is no need to list every minor library: focus on the structuring dependencies.

### Performance `[level::intermediate]`
- Even though performance campaigns are planned, a large proportion of performance problems could have been detected early during development. It is therefore important that developers profile their code on their own workstation. This has to be set in the Definition Of Done of the project. It will not be possible to detect all the problems (scalability, concurrency, robustness, cache tuning, ...) but most of the response time or concurrency issues. There are many ways to simulate concurrency and load. You'll find bellow some basic means accessible to any developer. Backend side:
  - Make sure that the server paging goes from the service call until the database (use `FETCH FIRST x ROWS ONLY` and [not `LIMIT` and `OFFSET`](https://www.postgresqltutorial.com/postgresql-fetch/)).
  - In cases of very large volumes (from hundreds of millions), use database table partitioning.
  - Don't forget to add all the necessary indexes, use the analysis of the execution plan to verify the absence of full scans.
  - Beware of SQL functions that 'break' indexes (like `UPPER()`) or use function indexes. Give priority to processing on the backend code side if possible.
  - Activate the query logs (Hibernate example: `org.hibernate.SQL = DEBUG`,`-Dhibernate.generate_statistics = true`) and check the SQL queries and their number (to detect in particular the very common [SELECT N + 1](https://stackoverflow.com/questions/97197/what-is-the-n1-selects-problem-in-orm-object-relational-mapping) issue).
  - Have a minimum data set (more than one hundred records) even on a workstation.
  - Check with a profiler (like VisualVM in Java) the memory consumption to detect leaks or over-consumption.
  - Detect threads leaks or deadlock by counting the number of active threads over a significant duration (one full night for instance).
  - Stress the API _a minima_ (with injectors like JMeter or K6) using a progressive ramp.
  - Track IOs (millions of times slower than memory accesses). Frontend side:
  - Limit the complexity of CSS (selectors or functions in particular)
  - Use a profiler (like the one in Chrome)
  - Favor asynchronous calls Frontend and backend:
  - Any resource (chain size, number of calls over a period, ...) must always be limited to a threshold (no "open bar" behaviors).
  - Check that the size of HTTP requests remains below a few tens of KiB (excluding GET on files). Use "Sorting and Pagination, client and server pagination".
  - Track network chatter: group requests when possible (you have to find a compromise with the previous rule). Use the SOLID (Interfaces Segregation) rule 'I'.
  - Provide endpoints that support batch requests to retrieve several elements at once (must result in a single `SELECT WHERE .. IN` in the final query, not a loop in the code!)
- Do not fall into the premature optimization trap : it is "the source of all the problems" according to Donald Knuth. Write the simplest code possible and follow a good design, only optimize it afterwards. Only optimize if it is worth it (Pareto law). Start with the most significant optimizations and do not waste time grabbing microseconds.

### Software factory specifics `[level::intermediate, detail_level::detailed]`
- Specify shortly whether this project requires a particular CI/CD configuration.

### Blueprints
- List applicable blueprints. Avoid own-in-house ones but give priority to wildly recognized ones from community, hence already proved and known to developers. Ideally, this should contain only links to external documentations.

### Code quality standards and automatic review `[detail_level::detailed]`
- Make explicit the rules and the level of required code quality

### Notable patterns `[level::intermediate, project_size::large]`
- Specify whether this project has implemented structuring patterns (GoF, JEE or other). No need to use patterns already supported by languages ​​or application servers (for example, IoC with CDI in a JEE 6 server).

### Specificities of the tests `[level::intermediate, project_size::large]`
- Is there a particular methodology or technology involved in this project? What is the testing strategy?
- For a large project, the test strategy is usually the subject of a separate document. A standard strategy can also be defined at the IS level.

### Ecodesign `[level::intermediate, detail_level::detailed]`
- List here the software measures to meet the ecodesign requirements previously listed. The answers to its problems are often the same as those to the performance requirements (response time in particular). In this case, just refer to it. However, ecodesign analyzes and solutions can be specific to this theme. Some proposals that can help to save energy:
  - Use profilers or development tools integrated in browsers (like Google Dev Tools) to analyze the consumption of resources (number, duration and size of requests).
  - For apps, use battery consumption monitoring tools like Battery Historian.
  - Use the specialized Greenspector analysis suite.
  - Measure the power consumption of systems with PowerAPI2 probes (developed by INRIA and Lille 1 University).
  - Measure the size of images and reduce them (lossless) with tools like pngcrush, OptiPNG, pngrewrite or ImageMagick.
  - Optimize memory and CPU consumption of applications, tuner GC for a Java application.
  - Use lazy loading for occasional resources.
  - Limit the results returned from the database (pagination). An interesting starting point for managing carbon impact can be the Software Carbon Intensity (SCI) formula: ---- SCI = ((E * I) + M) / R ---- Where:
  - E (kWh): The total energy consumed by the software;
  - I (gCO2/kWh): The amount of carbon emitted per kWh;
  - M (gCO2): The carbon footprint of the hardware;
  - R: The reference quantity (e.g., per user, per device, ...).
  - SCI: gCO₂e (grams of CO₂ equivalent) per functional unit Potential energy-efficiency improvement areas for the project (state of the art):
  - Use **modern browser profiling tools** (Chrome DevTools, Firefox Profiler, Safari Web Inspector), along with **Lighthouse** and **WebPageTest**, to analyze:
  - number of requests,
  - request size,
  - request duration,
  - CPU usage and network impact.
  - For mobile applications:
  - Android: **Battery Historian**, **Android Studio Energy Profiler**;
  - iOS: **Xcode Instruments – Energy Log**; to identify energy-intensive phases and inefficient background activity.
  - Use **specialized software sustainability tools**:
  - **Greenspector** (application-level energy analysis);
  - **Scaphandre**, **Kepler**, or **PowerAPI / Intel RAPL** for server and container energy estimation;
  - **Cloud Carbon Footprint** for cloud-based workloads (AWS, GCP, Azure).
  - Optimize media assets:
  - adopt modern formats (**AVIF**, **WebP**);
  - apply lossless compression where applicable;
  - dynamically adapt image sizes to device capabilities (responsive images).
  - Optimize CPU and memory usage:
  - eliminate unnecessary processing;
  - profile applications regularly;
  - for Java applications, optimize allocation patterns and configure **modern garbage collectors** (G1, ZGC, Shenandoah, depending on use case).
  - Implement **lazy loading strategies**:
  - defer non-critical resources;
  - progressively load data based on user interaction.
  - Reduce data volumes:
  - apply pagination or cursor-based APIs;
  - enforce strict server-side filtering;
  - avoid over-fetching (use batching where appropriate).
  - Group compute-intensive operations into **scheduled batch jobs** to improve energy efficiency through workload consolidation.

### Management of robustness `[level::intermediate, detail_level::detailed]`

#### Transaction management `[level::advanced]`
- List here the decisions taken regarding the management of transactions. This is especially useful for a distributed system. Some examples of issues:
  - Are updates allowed on multiple distinct modules during the same request?
  - If so, do we ensure the ACID character at all (via XA mode for example)?
  - What transactional engine do we use?
  - What level of transactional isolation (read commited, uncommited, repeatable read, serializable)?
  - If no transactional monitor is used (call of several REST services in update for example), are there any compensatory transactions in the event of failure of one of the updates?

#### Session management `[level::intermediate, detail_level::in-depth]`
- How are HTTP sessions managed to provide an execution context to a user (example: a shopping cart)? Note that this is primarily a problem for classic web applications whose presentation is generated on the server, not for Single Page Application (SPA) applications which manage all presentation and state locally in the browser. The choices made here will affect the [infrastructure decisions](view-infrastructure.md). For example, if a session is required and the infrastructure is clustered, it will either be necessary to set up session affinity on the servers to force each user to always reach the same server, or to set up a distributed cache allowing servers to share sessions for all users (more complex).

#### Error handling
- How do we deal with errors? Examples of points to be addressed:
  - Do we differentiate functional errors (expected functional errors) and technical? Provide a class diagram.
  - How do we log errors? what level of log?
  - Where are the exceptions caught? Near the faulty code or in a centralized point of code (like an Error handler)?
  - Are we using the language's standard exceptions (`IOException`, ...) or our own set of exceptions?
  - Is the list of errors consolidated? documented?
  - Are error codes assigned?
  - Do we display full stack-traces? if so, server side and client side?
  - Do we manage retries? if so, how long  do we wait between retries (exponential backoff, jitter)?
  - How do we manage timeouts?
  - How do we manage functional discards ? (i.e. what to do with partial or erroneous requests?)

#### Controls
- List here the patterns and technical solutions implemented to validate all data entering the service. It is essential never to trust the caller and to systematically validate all received data. In particular, anti-corruption layers should be implemented in exposed services as well as in jobs consuming data from third-party systems. Once data has been persisted in your system, it becomes your responsibility to manage it. This may require evolving the code to handle unexpected content or content originating from older versions of the data model. For an automated system, the best strategy is generally to apply the strictest possible controls when data enters the system. It is also important not to limit validation to frontend controls, which mainly constitute surface-level controls. These controls must be systematically duplicated on the backend, where they provide hardening and guarantee the integrity of the system. Rejection of invalid input: it is necessary to define precisely what “rejecting” means: returning a functional error in the response or merely logging it, placing the input in quarantine, producing metrics, raising alerts, providing replay capabilities, and preventing infinite retry loops that could eventually overload the system if invalid input were not rejected. For batch processing, specify whether the entire batch is rejected or only the invalid items.

#### Frontend robustness `[gui]`
- Like the backend, the frontend requires significant robustness, especially since it is in direct contact with the Chair-To-Keyboard interface. Among others:
  - Think about prohibiting double submissions (double call to the backend if you double-click on a button). This does not exclude carrying out hardening checks on the backend side.
  - In order to avoid subtle problems (especially when using browser storage such as local/session storage), remember to prevent the same web application from opening in several browser windows or tabs. If attempted, display an error message in the supernumerary windows.
  - Always check browser compatibility, even in a controlled environment. If an attempt is made to open a page by an unsupported browser, display an explicit error message on the screen.

### Configuration management `[detail_level::detailed]`
- How do you configure the application? Examples of points to be addressed:
  - What are the variables included in the final package statically?
  - What parameters can be changed at runtime?
  - Can my application be configured via feature flags (for canary testing reasons for example)? if so, how to handle them?
  - In what form are the parameters injected into the application (environment variable? .properties file, database, ...)?
  - Does the application accept a live modification?
  - Describe the configuration system.

### Branch management policy `[level::advanced, detail_level::in-depth]`
- What are the branch workflows to plan? git-flow? TBD (Trunked-Based Development)? other?

### Versioning `[detail_level::detailed]`
- What is versioned and what versioning scheme is used?

### Concurrency `[level::intermediate, detail_level::in-depth]`
- How do we manage concurrent access? Examples of points to be addressed:
  - What scope for the objects (if using an IoC engine)?
  - Should objects be thread-safe?
  - Which methods should be synchronized?
  - Risks of race condition? of starvation? dead locks?

### Encoding `[level::intermediate, detail_level::detailed]`
- What are the rules for encoding strings? This is a recurring problem. This problem is, however, relatively simple to solve and requires only rigor. See the examples below for examples of actual measures.

### Timezones `[level::intermediate, detail_level::detailed]`
- How do we manage the storage of dates and times? This, as the management of encoding is a recurring problem (one day shift, bugs during summer/winter time changes, etc.) and yet simple to solve: follow the [ISO 8601 standard](https://en.wikipedia.org/wiki/ISO_8601) ("Time zones in ISO 8601 are represented as local time (with the location unspecified), as UTC, or as an offset from UTC."[Wikipedia]).

### Log management `[detail_level::detailed]`
- The log infrastructure aspects are detailed in the [infrastructure view](view-infrastructure.md).
- Give here the general rules concerning the application traces (logs), the levels and quantity of logs. Think about the use of logs, especially on the server side. Ask yourself if it will be possible to benefit from it in the event of an error in production in the middle of MiB or even GiB of other logs and n threads logging in parallel.

#### General rules `[detail_level::in-depth]`

#### Levels and quantity of logs `[detail_level::in-depth]`
- Explain when and what to log in so as to produce logs that can be used in production.

### Administrative tools `[level::intermediate, project_size::large, detail_level::detailed]`
- Should the app provide administration services? It is strongly recommended (this is the factor 12 of the [Heroku Twelve factors](https://12factor.net/)) to integrate the administration code directly within the business code.

### Sorting and Pagination `[level::intermediate, detail_level::detailed]`
- It is necessary to keep a good fluidity of batch data recovery. The pagination allows to limit the chatter between the clients (GUI and batches) and the APIs. Describe here the paging measures implemented on the client side and on the server side.

### Provisioning and DDL updates `[level::intermediate, detail_level::detailed]`
- Describe how the DDL (Database tables definition) and the initial data (such as nomenclatures) will be managed and then updated.

### Internationalization Management `[level::intermediate, detail_level::detailed]`
- Describe how you meet the i18n requirements mentioned above.
