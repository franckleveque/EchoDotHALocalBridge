# Vue développement
- Faire régulièrement des revues complètes de la vue (au moins une fois par an tant que le projet est actif) et mettre à jour la date plus haut.
- Indiquer le statut de la vue, par exemple 'DRAFT', 'FINALISÉ',...

## Introduction `[contexte]`

### Documentation de Référence `[references]`
- Mentionner ici les documents d'architecture de référence (mutualisés). Ce document ne doit pas reprendre leur contenu sous peine de devenir rapidement obsolète et immaintenable.

## Non statué `[contexte, incertitude]`

### Points nécessitant une étude complémentaire

### Hypothèses
- Donner ici les éventuelles hypothèses structurantes

## Contraintes `[niveau_detail::général, contrainte]`
- Lister ici les contraintes relatives à l'architecture logicielle, ceci inclut de façon non-exhaustive :
  - L'obligation d'utiliser un framework ou une filière technologique précise ;
  - Les budgets disponibles pour les licences ou les frais de développement ;
  - L'outillage (IDE, etc.) ;
  - L'intégration continue ;
  - Les normes et niveaux de qualité de code applicables ;
  - Les tests (taux de couverture, répartition par type de test, etc.).

## Exigences non fonctionnelles `[niveau_detail::général, exigence]`
- Contrairement aux contraintes qui fixent le cadre auquel toute application devait se conformer, les exigences non fonctionnelles sont données par les porteurs du projet (Product Owner/MOA en général). Prévoir des interviews pour les déterminer. Si certaines exigences ne sont pas réalistes, le mentionner dans le référentiel des points à statuer.

### Exigences d'accessibilité `[ihm]`
- Cette application doit-elle être accessible aux non/mal voyants ? malentendants ? Si oui, quel niveau d’accessibilité ? Se référer de préférence au Référentiel Général d’Accessibilité ([RGAA](https://references.modernisation.gouv.fr/rgaa-accessibilite/#menu)) qui préconise un niveau WCAG 2.0 AA : Il existe d’autres normes d’accessibilité (WCAG, AccessiWeb, RGAA, etc.) . Attention à correctement évaluer le niveau visé (ni sur-qualité, ni sous-qualité) :
  - Atteindre un niveau d’accessibilité très élevé peut être coûteux et contraignant technologiquement. Il demande également de bonnes compétences (accessibilité, HTML5/CSS3 en particulier) et des profils rares.
  - La loi est de plus en plus stricte pour les administrations qui doivent respecter un niveau d’accessibilité suffisant (loi  n°2005-102 du 11 février 2005 pour l’égalité des droits et des chances, la participation et la citoyenneté des personnes handicapées). « Tous les sites publics européens doivent atteindre le double A (AA) du W3C/WAI ».

### Exigences d'ergonomie `[ihm]`

#### Spécificités d'UX `[niveau_detail::détaillé]`
- En général, on se réfère ici à la charte ergonomique de l’organisme. Lister néanmoins d’éventuelles spécificités. Ne pas reprendre les contraintes d’accessibilité listées plus haut.

#### Spécificités sur les widgets `[niveau_detail::approfondi]`
- Des comportements ergonomiques très précis peuvent impacter assez fortement l’architecture et imposer une librairie de composants graphiques ou une autre. Il est fortement déconseillé de personnaliser des librairies existantes (coût de maintenance très élevé, grande complexité). Bien choisir sa librairie ou restreindre ses besoins. Éviter d'introduite de nouveaux "concepts" ergonomiques pour ne pas perdre l'utilisateur (principe de moindre surprise).

#### Exigences sur les polices de caractère `[niveau_detail::approfondi]`
- Décrire ici les polices de caractère à utiliser pour les pages Web, les applications ou les documents composés. Le choix des polices suit des contraintes de licences. Afin d'assurer une sécurité juridique au projet, attention aux polices commerciales soumises à royalties (en particulier les polices appartenant à Microsoft comme Times New Roman, Courier, Verdana, Arial) et qui ne permettent pas de produire gratuitement des documents sans passer par leurs éditeurs (Word, etc.). Voir par exemple la police [Marianne](https://www.gouvernement.fr/charte/charte-graphique-les-fondamentaux/la-typographie) préconisée par le gouvernement en tant que police à chasse variable. Redhat propose quatre familles de polices [Liberation Mono](https://fr.wikipedia.org/wiki/Liberation_(police_d%27%C3%A9criture)) en licence Open Source sécurisante sur un plan juridique et compatible métriquement avec le Monotype, le Courrier New, l'Arial et le Times New Roman.

#### Exigences de site Web adaptatif `[niveau::intermédiaire, niveau_detail::approfondi]`
- Lister les contraintes d’affichage multi-support. Utiliser quand c'est possible les frameworks modernes (type Angular, Vue.js ou React.js). Il existe plusieurs niveaux d’adaptation des pages Web :
  - Statique (largeur de page fixe).
  - Dynamique (redimensionnement automatique, les tailles sont exprimées en %).
  - Adaptatif (les distances sont exprimées en unités dont la taille dépend du support).
  - Responsive (le contenu et son agencement dépend du support). WARNING: Un design responsive vient avec ses contraintes (duplication de code CSS, augmentation du volume du site à télécharger par le client, complexité, plus de tests end-to-end à prévoir, etc.).

#### Exigences de progressive Web Apps (PWA) `[niveau::avancé, niveau_detail::approfondi]`
- Spécifier si l'application est progressive. Les applications PWA sont des applications Web HTML5 possédant tous les attributs des applications natives (mode déconnecté, rapide, adaptatif, accessible depuis l'OS, etc.)

#### Exigences sur les navigateurs supportés
- Préciser quels sont les navigateurs supportés si votre projet contient une IHM Web. Lorsqu'on s'adresse à un public dont on ne gère pas le parc de navigateurs (comme un site Web sur Internet), la meilleure option pour rendre les choses intelligibles et expliciter les enjeux est de négocier avec les parties prenantes du projet un pourcentage de public supporté en se basant sur des [statistiques](https://gs.statcounter.com/). Par exemple : "Support de 95 % des navigateurs à date d'aujourd'hui".
- Supporter d’anciens navigateur (IE en particulier) peut engendrer des surcoûts rédhibitoires et des risques sur la sécurité. Dans tous les cas, il convient d’évaluer les surcoûts de tester sur plusieurs plate-formes. Il existe de bons outils (payants) comme Litmus ou EmailOnAcid permettant de générer un rendu des sites Web et des courriels HTML sur une combinatoire d’OS / type de lecteur (PC/tablette/mobile) /navigateur très vaste.  Ce type de site est incontournable pour tester une application grand public.

#### Exigences de mode déconnecté `[niveau::avancé, niveau_detail::approfondi]`
- Préciser si l'application doit pouvoir continuer à fonctionner sans accès à Internet ou au LAN (courant pour les applications utilisées par les professionnels en déplacement par exemple). Il peut s’agir de clients lourds classiques (Java, Kotlin, JS, C++, etc.) possédant leur base locale pouvant être synchronisée de retour au bureau. Il peut aussi s'agir d'applications PWA (voir plus haut) utilisant un service worker pour les resources statiques et du stockage navigateur (local storage, base de données IndexedDB, ...).

#### Exigences d'internationalisation (i18n)
- Préciser les contraintes de l’ application en terme d’i18n : localisation des libellés, direction du texte, mise en page adaptable, code couleur spécifique, format de dates, devises, affichage des séparateurs décimaux, etc.

### Exigences de SEO `[ihm]`
- Le SEO (Search engine optimization) concerne la visibilité d'un site Web au travers des moteurs de recherche (comme Google Search, Bing ou Quant).

### Exigences d'écoconception
- L'écoconception consiste à limiter l'impact environnemental des logiciels et matériels utilisés par l’application. Les exigences dans ce domaine s'expriment généralement en kilowattheures (KWH) ou équivalent CO2. A noter que la loi française (voir loi [du n°2020-105 du 10 février 2020, ou loi AGEC](https://ecoresponsable.numerique.gouv.fr/publications/guide-pratique-achats-numeriques-responsables/demarche-numerique-responsable/que-prevoit-la-loi/)) exige de réduire le gaspillage lié au numérique, notamment concernant l'obsolescence logicielle (art. 27). Lister ici les exigences d'écoconception portant sur les logiciels.

## Architecture cible `[niveau_detail::général, solution]`

### Pile logicielle

#### Filière technique retenue `[niveau::avancé]`
- Détailler les technologies choisies parmi les technologies au catalogue de l’organisation. S’il existe des écarts avec le catalogue, le préciser et le justifier.

#### Dépendances
- Lister ici pour chaque module les principales librairies et frameworks utilisés ainsi que leur version majeure. Ne pas lister les librairies fournies au runtime par les serveurs d'application ou les frameworks. Inutile de trop détailler, donner uniquement les dépendances structurantes.

### Performances `[niveau::intermédiaire]`
- Même si des campagnes de performance sont prévues, une grande partie des problèmes de performance peuvent être détectés dès le développement. Il est donc important que les développeurs profilent leur code, dès leur poste de travail (à prévoir dans le Definition Of Done du projet). Il ne sera pas possible de détecter tous les problèmes (scalabilité, concurrence, robustesse, tuning des caches, etc.) mais c'est le cas de la plupart des problèmes de temps de réponse. Il est également souvent possible de simuler de la concurrence et de la charge. Nous présentons ici quelques pistes très basiques et à la portée de tout développeur. Coté Backend :
  - S'assurer que la pagination serveur va bien jusqu'à la base de donnée (en PostgreSQL, utiliser `FETCH FIRST x ROWS ONLY`.
  - Limiter le nombre de jointures et les relations many-to-many.
  - Dans des cas de grosses volumétries, étudier les solutions de partitionnement de tables.
  - Ne pas oublier d'ajouter tous les index nécessaires, utiliser l'analyse du plan d'exécution pour vérifier qu'il n'y a pas de full scans.
  - Attention aux fonctions SQL qui 'cassent' les index (comme  `UPPER()`). Privilégier les traitements coté code backend si possible ou prévoir des index de fonctions correspondants.
  - Activer les journaux de requêtes (exemple Hibernate : `org.hibernate.SQL=DEBUG`,`-Dhibernate.generate_statistics=true`) et vérifier les requêtes SQL et leur nombre (pour détecter en particulier le problème du [SELECT N+1](https://stackoverflow.com/questions/97197/what-is-the-n1-selects-problem-in-orm-object-relational-mapping), très courant).
  - Disposer même sur poste de travail d'un jeu de donnée minimal (une centaine d'enregistrement).
  - Vérifier avec un profiler (comme JVisualVM en Java) la consommation mémoire pour détecter les fuites ou les surconsommations.
  - Vérifier qu'il n'y a pas de fuite de threads ou de deadlocks en comptant le nombre de threads actifs sur une période suffisamment longue (une nuit complète par exemple).
  - Stresser les API _a minima_ (avec des injecteurs comme JMeter ou K6) et via une rampe progressive.
  - Traquer les IO (des milliers de fois plus lents que des accès mémoire).
  - … Coté Frontend :
  - Limiter la complexité des CSS (sélecteurs ou fonctions en particulier) ;
  - Utiliser un profiler (comme celui de Chrome ou Firefox) ;
  - Privilégier les appels asynchrones.
  - … Frontend et backend :
  - Toute ressource (taille de chaîne, nombre d'appel sur une durée, etc.) doit systématiquement être bornée par une limite (pas d'« open bar »).
  - Vérifier que la taille des requêtes HTTP reste en dessous de quelques dizaines de Kio (hors GET sur fichiers). Utiliser la pagination cliente et serveur.
  - Traquer le bavardage réseau : grouper les requêtes quand possible (il faut trouver un compromis avec la règle précédente). S'aider de la règle ‘I’ de SOLID (Interface Segregation).
  - Prévoir des endpoints multivalués pour récupérer plusieurs éléments à la fois (doit se concrétiser par un seul `SELECT WHERE .. IN` dans la requête finale, pas une boucle dans le code !)
- Ne pas tomber à l'inverse dans l'optimisation prématurée "source de tous les problèmes" selon Donald Knuth. Écrire le code le plus simple possible et suivre un bon design, ne l'optimiser qu’ensuite.

### Spécificités d’usine logicielle `[niveau::intermédiaire, niveau_detail::détaillé]`
- Sans reprendre le fonctionnement de la plate-forme d’Intégration Continue de l'organisation (CI), préciser si ce projet nécessite une configuration particulière.

### Bonnes pratiques
- Lister les bonnes pratiques (blueprints) applicables. Éviter les bonnes pratiques 'maison' mais privilégier celles qui viennent de la communauté et sont donc éprouvées et déjà connus des développeuses et développeurs. Idéalement, il ne devrait y avoir ici que les liens vers des ressources externes.

### Normes de développement et qualimétrie `[niveau_detail::détaillé]`
- Rendre explicite les règles et le niveau de qualité requis pour le code

### Patterns notables `[niveau::intermédiaire, taille_projet::grand]`
- Préciser si ce projet a mis en œuvre des patterns structurants (GoF, JEE ou autres). Inutile de reprendre les patterns déjà supportés par les langages ou les serveurs d'application (par exemple, l'IoC dans un serveur JEE).

### Spécificités des tests `[niveau::intermédiaire, taille_projet::grand]`
- Une méthodologie ou une technologie particulière est-elle en jeu dans ce projet ? Quelle est la stratégie de tests ? Pour un projet d'envergure, la stratégie de test fait en général l'objet d'un document propre. Une stratégie standard peut également être définie au niveau du SI.

### Éco-conception `[niveau::intermédiaire, niveau_detail::détaillé]`
- Lister ici les mesures logicielles permettant de répondre aux exigences d'écoconception listées plus haut. Les réponses à ces problématiques sont souvent les mêmes que celles aux exigences de performance (temps de réponse en particulier). Dans ce cas, y faire simplement référence. Néanmoins, les analyses et solutions d'écoconception peuvent être spécifiques à ce thème. Un point de départ intéressant pour manipuler l'impact carbone peut être la formule SCI (Software Carbone Intensity): ``` SCI = ((E * I)) + M) par R ``` Avec:
  - E	Énergie consommée (kWh)
  - I	Intensité carbone de l’électricité (gCO₂e/kWh)
  - M	Empreinte carbone du matériel (gCO₂e), amortie sur sa durée de vie
  - R	Unité fonctionnelle (requêtes, utilisateurs, transactions, etc.)
  - SCI : gCO₂e (grammes équivalent CO₂) par unité fonctionnelle Quelques pistes d’amélioration énergétique du projet (état de l’art) :
  - Utiliser les **outils de profilage intégrés aux navigateurs modernes** (Chrome DevTools, Firefox Profiler, Safari Web Inspector) ainsi que **Lighthouse** et **WebPageTest** pour analyser :
  - le nombre de requêtes,
  - leur taille,
  - leur durée,
  - le temps CPU et l’impact réseau.
  - Pour les applications mobiles :
  - Android : **Battery Historian**, **Android Studio Energy Profiler** ;
  - iOS : **Xcode Instruments – Energy Log** ; afin d’identifier les phases de consommation excessive de batterie.
  - Utiliser des **outils spécialisés d’éco-conception logicielle** :
  - **Greenspector** (analyse énergétique applicative) ;
  - **Scaphandre**, **Kepler** ou **PowerAPI / RAPL** pour l’estimation de la consommation énergétique côté serveurs et conteneurs ;
  - **Cloud Carbon Footprint** pour les environnements cloud.
  - Optimiser les médias :
  - utiliser des formats modernes (**AVIF**, **WebP**) ;
  - compresser sans perte lorsque possible ;
  - adapter dynamiquement la taille des images au terminal (responsive images).
  - Optimiser l’usage CPU et mémoire :
  - réduire les traitements inutiles ;
  - profiler régulièrement ;
  - pour Java : optimiser l’allocation mémoire et configurer le **GC moderne** (G1, ZGC, Shenandoah selon les cas).
  - Mettre en œuvre des stratégies de **chargement différé** :
  - lazy loading des ressources non critiques ;
  - chargement progressif des données.
  - Réduire les volumes de données :
  - pagination ou curseurs côté API ;
  - filtrage serveur strict ;
  - éviter le sur-fetching (batching raisonné).
  - Grouper les traitements intensifs dans des **batchs planifiés** afin de mutualiser les coûts énergétiques.

### Gestion de la robustesse `[niveau::intermédiaire, niveau_detail::détaillé]`

#### Gestion des transactions `[niveau::avancé]`
- Lister ici les décisions prises concernant la gestion des transactions. Ceci est surtout utile pour un système distribué. Quelques exemples de problématiques :
  - Autorise-t-on les mises jours sur de multiples modules lors d'une même requête ?
  - Si oui, assurons nous le caractère ACID du tout (via le mode XA par exemple) ?
  - Quel moteur transactionnel utilisons nous ?
  - Quel niveau d'isolation transactionnelle (read commited, uncommited, repeatable read, serializable) ?
  - Si aucun moniteur transactionnel n'est utilisé (appel de plusieurs services REST en mise à jour par exemple), prévoit-t-on des transactions compensatoires en cas d'échec de l'une des mises à jours ? un pattern [SAGA](https://learn.microsoft.com/en-us/azure/architecture/patterns/saga) ? des jobs de resynchronisation ? ...

#### Gestion des sessions `[niveau::intermédiaire, niveau_detail::approfondi]`
- Comment gère-t-on les sessions HTTP permettant de fournir un contexte d'exécution à un utilisateur (exemple: son panier d'achat) ? Notez que ceci est une surtout un problème pour les applications Web classiques dont la présentation est générée sur le serveur, pas pour les applications SPA (Single Page Application) qui gèrent toute la présentation et leur état en local dans le navigateur. Les choix faits ici affecteront les [choix d'infrastructure](vue-infrastructure.md). Par exemple, si une session est requise et que l'infrastructure est en cluster, il faudra soit mettre en place de l'affinité de session sur les serveurs pour forcer chaque utilisateur à toujours arriver sur le même serveur disposant de ses données, soit de mettre en place un cache distribué permettant aux serveurs de partager les sessions de tous les utilisateurs (plus complexe et plus lourd).

#### Gestion des erreurs
- Comment gère-t-on les erreurs ? Exemples de points à traiter :
  - Différencions-nous erreurs fonctionnelles (erreurs fonctionnelles prévues) et techniques ? Prévoir un diagramme de classe.
  - Comment logue t-on les erreurs ? quel niveau de log ?
  - Où sont attrapées les exceptions ? au plus tôt ou en début d'appel de façon centralisée ?
  - Utilise-t-on les exceptions standards du langage (ex: `IOException`, etc.) ou notre propre jeu d'exceptions ?
  - La liste des erreurs est-elle consolidée ? documentée ?
  - Affecte-t-on des codes erreur ?
  - Affiche-on les stack-traces complètes ? si oui, coté serveur et coté client ?
  - Gère-t-on les rejeux ? si oui, espace-t-on les rejeux ? de façon aléatoire (jitter) ? exponentielle (exponential backoff) ?
  - Comment gère-t-on les timeouts ?
  - Comment gérons-nous les rejets fonctionnels? (c.-à-d. que faire des demandes partielles ou erronées?)

#### Contrôles
- Lister ici les patterns et les solutions techniques mis en œuvre pour contrôler toutes les données entrant dans le service. Il est fondamental de ne jamais faire confiance à l'appelant et de vérifier systématiquement les données reçues. Prévoir notamment des couches d'anti-corruption dans les services exposés ainsi que dans les jobs consommant des données provenant de systèmes tiers. Une fois la donnée persistée dans votre système, il vous appartient de la gérer. Cela peut notamment nécessiter de faire évoluer le code afin de prendre en charge des contenus inattendus ou issus d'anciennes versions du modèle. Pour un système automatisé, la meilleure stratégie consiste généralement à appliquer les contrôles les plus stricts possible au moment de l'entrée des données. Il est également important de ne pas se limiter aux contrôles réalisés côté frontend, qui constituent principalement des contrôles de surface. Les contrôles doivent être systématiquement reproduits côté backend, où ils jouent un rôle de durcissement et garantissent l'intégrité du système. Rejet des flux invalides : il faut prévoir ce que signifie « rejeter » : erreur fonctionnelle en réponse ou simplement journalisée, quarantaine, métriques, alertes, possibilités de rejeu et absence de boucle infinie qui finirait par engorger votre système si les flux invalides n'étaient pas rejetés. Pour les gestions par lot, préciser si le lot entier est rejeté ou seulement les éléments invalides.

#### Gestion de la robustesse coté frontend `[ihm]`
- Tout comme le backend, le frontend requiert une robustesse importante, d'autant plus qu'il est en prise directe avec des utilisateurs finaux. Entre autres :
  - Penser à interdire les doubles soumissions (double appel au backend si on double-clic sur un bouton). Ceci n'exclut pas de procéder à des contrôles de durcissement coté backend.
  - Afin d'éviter des problèmes subtils (surtout en cas d'utilisation de stockage navigateur comme les local/session storage), penser à empêcher l'ouverture d'une même application Web dans plusieurs fenêtres ou onglets du navigateur. En cas de tentative, afficher un message d'erreur dans les fenêtres surnuméraires.
  - Toujours vérifier la comptabilité du navigateur, même en environnement contrôlé. En cas de tentative d'ouverture d'une page par un navigateur non supporté, afficher un message d'erreur explicite à l'écran.

### Gestion de la configuration `[niveau_detail::détaillé]`
- Comment configure-t-on l'application ? Exemples de points à traiter :
  - Quelles sont les variables incluses dans le package final de façon statique ?
  - Quels sont les paramètres modifiables au runtime ?
  - Mon application est-elle paramétrable via feature flags pour des raisons de canary testing par exemple ? si oui, comment je le gère dans le code ?
  - Sous quelle forme les paramètres sont-ils injectés dans l'application (variable d'environnement ? fichier .properties, base de données, etc.) ?
  - L'application accepte-elle une modification du paramétrage à chaud ?
  - Décrire le système de configuration

### Politique de gestion des branches `[niveau::avancé, niveau_detail::approfondi]`
- Quels sont les workflows de branche à prévoir ? git-flow ? TBD (Trunked-Based Development) ? autre ?

### Versioning `[niveau_detail::détaillé]`
- Que versionne-t-on et quel système de version utilise-t-on ?

### Gestion de la concurrence `[niveau::intermédiaire, niveau_detail::approfondi]`
- Comment gère-t-on les accès concurrents ? Exemples de points à traiter :
  - Quel scope pour les objets (si utilisation d'un moteur IoC) ?
  - Les objets doivent-il être thread-safe ?
  - Quelles méthodes doivent être synchronisées ?
  - Risques de race condition ? de famine ? de dead locks ?

### Encodage `[niveau::intermédiaire, niveau_detail::détaillé]`
- Quelles sont les règles concernant l'encodage des chaînes de caractères ? Ceci est un problème récurrent dans les SI (qui n'a jamais observé d'accents corrompus sous forme de carrés ?). Ce problème est pourtant relativement simple à résoudre. Voir les exemples ci-dessous pour des exemples de dispositifs effectifs.
- Dans certains cas, nous n’avons pas la main sur la lecture des `.properties` (depuis un framework par exemple), il n’est alors pas possible de forcer un encodage en `UTF-8`. Il faut alors s'assurer qu'on spécifie l'encodage effectif dans l'outil ou le code qui le lit.

### Fuseaux horaires `[niveau::intermédiaire, niveau_detail::détaillé]`
- Comment gère-t-on le stockage des dates et des heures ? Ceci, comme la gestion de l'encodage est un problème récurrent (décalage d'un jour, bugs lors des changements d'heure d'été/hiver, etc.). Pour éviter les problèmes, suivre la norme [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) ("Time zones in ISO 8601 are represented as local time (with the location unspecified), as UTC, or as an offset from UTC." [Wikipedia]).

### Gestion des journaux `[niveau_detail::détaillé]`
- Les aspects d'infrastructure de journaux sont détaillés dans link:./vue-infrastructure.adoc#_journaux[la vue infrastructure].
- Fournir ici les règles générales concernant les journaux (logs) : leur niveau de prolixité et le volume qu'ils représentent. Penser à l'exploitation des journaux, surtout coté serveur. Se demander s'il sera possible d'en tirer profit en cas d'erreur en production au milieu de Mio voire Gio d'autres journaux et de nombreux threads écrivant en parallèle.

#### Règles générales `[niveau_detail::approfondi]`

#### Niveaux et quantité de journaux `[niveau_detail::approfondi]`
- Expliquer quand et quoi loguer de sorte à produire des journaux exploitables en production.

### Outils d'administration `[niveau::intermédiaire, taille_projet::grand, niveau_detail::détaillé]`
- L'application doit-elle fournir des services d’administration ? Il est fortement conseillé (c'est le facteur 12 des [Twelve factors d'Heroku](https://12factor.net/)) d'intégrer le code d'administration directement avec le code métier.

### Tri et Pagination `[niveau::intermédiaire, niveau_detail::détaillé]`
- Il est nécessaire de conserver une bonne fluidité de récupération des données en lot. La pagination permet de limiter le bavardage entre les clients (IHM et batchs) et les API. Décrire ici les dispositifs de pagination mis en oeuvre coté client et coté serveur.

### Provisioning et mises à jour des DDL `[niveau::intermédiaire, niveau_detail::détaillé]`
- Décrire comment les DDL (structures de tables en base de données) et les données initiales (comme des nomenclatures) seront gérées puis mis à jour.

### Gestion de l'internationalisation `[niveau::intermédiaire, niveau_detail::détaillé]`
- Décrire comment vous répondez aux exigences d'i18n exprimées plus haut.
