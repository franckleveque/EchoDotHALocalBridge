# Vue architecture applicative
- Faire régulièrement des revues complètes de la vue (au moins une fois par an tant que le projet est actif) et mettre à jour la date plus haut.
- Indiquer le statut de la vue, par exemple 'DRAFT', 'FINALISÉ',...

## Introduction `[contexte]`

### Documentation de Référence `[references]`

## Non statué `[contexte, incertitude]`
- En architecture, l'incertitude doit être affichée clairement pour aider à la comprehension des choix et de la situation courante.

### Points nécessitant une étude complémentaire

### Hypothèses
- Donner ici les éventuelles hypothèses structurantes

## Contexte général `[niveau_detail::général]`

### Objectifs
- Décrire succinctement le projet et en rappeler les objectifs. Mettre en évidence ceux qui sont structurants pour l’architecture.

### Existant `[migration]`
- Si ce document présente un projet de refonte ou de migration, décrire a minima l'application existante. Ne pas reprendre la documentation, y faire simplement référence et pointer vers son éventuel dossier d'architecture. Mentionner néanmoins toute information ayant un impact fort sur la migration ou la conception du nouveau projet.

### Positionnement dans le SI `[taille_projet::grand]`
- Si le SI est urbanisé, reprendre le plan d’occupation au sol et préciser le bloc concerné.

### Acteurs

#### Acteurs internes
- Par ‘internes’, on entend les acteurs appartenant à l’organisation, qu’il s’agisse d’humains ou de modules applicatifs.

#### Acteurs externes

#### Nature et sensibilité des données et traitements
- Donner une synthèse des traitements et processus métier et les natures de données qu'ils manipulent pour aider à la conception de la solution. WARNING: Ne pas reprendre l'AIPD mais y faire référence s'il existe.

## Contraintes `[niveau_detail::général, contrainte]`
- Limites / choix imposés sur la façon de concevoir ou de réaliser : technologies, processus, organisation, budget, réglementation.

### Contraintes budgetaires
- Donner un ordre de grandeur des contraintes budgétaires du projet (ou donner un lien vers un document pertinent).

### Contraintes planning
- Sans reprendre dans le détail les plannings du projet, donner les éléments pertinents pour l'architecture.

### Urbanisation `[taille_projet::grand]`
- Lister ici les contraintes relatives à l'urbanisation, ceci inclut par exemple mais pas seulement :
  - Les règles applicables dans les appels entre modules (SOA) ;
  - Les règles d'appels entre zones réseau ;
  - Les règles concernant la localisation des données (MDM) ;
  - Les règles concernant la propagation des mises à jours par événements (EDA).

### Contraintes juridiques

## Exigences `[exigence]`
- Fournir ici les exigences d'architecture applicative pouvant s'appliquer au projet. En fonction de votre contexte, ne pas hésiter à ajouter des sous-sections.

### Exigences stratégiques
- Décrire ici les exigences en rapport avec la stratégie générale du projet en termes de trajectoire, de budget et d'organisation.

### Exigences d'interopérabilité
- Décrire ici les exigences portant sur les protocoles, formats et sémantiques à respecter afin de favoriser les échanges avec des organismes ou tiers.

### Exigences sur la gestion de la concurrence `[niveau_detail::détaillé]`
- Préciser ici les modules internes ou externes pouvant interférer avec l’application.

### Exigences sur les modes dégradés `[niveau::avancé, niveau_detail::détaillé]`
- Préciser les modes dégradés applicatifs envisagés.

### Exigences d'archivage `[niveau_detail::détaillé, archivage]`
- L'archivage est la recopie de données importantes sur un support dédié offline en vue non pas d'une restauration comme la sauvegarde mais d'une _consultation_ occasionnelle. Les archives sont souvent exigées pour des raisons légales et conservées trente ans ou plus. Précisez si des données de l’application doivent être conservées à long terme. Précisez les raisons de cet archivage ([légales](https://www.service-public.fr/professionnels-entreprises/vosdroits/F10029) le plus souvent). Précisez si des dispositifs spécifiques de protection de l'intégrité (pour prévenir ou détecter toute modification) doivent être mis en place.

### Exigences sur les durées de rétention `[niveau_detail::détaillé]`
- Précisez ici combien de temps doivent être conservées les données et documents stockés par vos modules applicatifs. À noter que ces durées peuvent être contraintes par le droit (voir contraintes juridiques plus haut), par exemple dans le cadre du droit à l'oubli du RGPD.
- Ne pas oublier de mentionner les données techniques (comme les journaux ou les tables techniques) ainsi que les archives.

### Identifiants fonctionnels `[niveau_detail::détaillé]`
- Décrire ici les identifiants fonctionnels utilisés par le projet pour référencer les entités principales et exposées aux humains. Voir aussi [cet article](https://florat.net/designing-human-targeted-random-ids/).

## Architecture cible `[solution, niveau_detail::général]`

### Architecture applicative générale
- Présenter ici l'application dans son ensemble (sans détailler ses modules ou composants) en relation avec les autres applications du SI. Présenter également les principales données échangées ou stockées. Rappeler :
  - Le type d'architecture (client-serveur, Web monolithique, SOA, micro-service, event-driven…) ;
  - Les flux principaux entre les modules (micro-service/SOA) ou applications (monolithe) ;
  - D'éventuelles dérogations aux règles d'architecture du SI. Si l'application est prévue pour être implémentée en plusieurs étapes, décrire succinctement la trajectoire cible.
- Le choix de la représentation est libre mais un diagramme [C4 System Landscape](https://c4model.com/diagrams/system-landscape) semble le plus adapté. Nous fournissons des patterns et des détails à ce sujet dans [cet article](https://florat.net/architecture-as-code-with-c4-and-plantuml/). Ne pas faire figurer les systèmes d'infrastructure (serveur SMTP, dispositif de sécurité, reverse proxy, annuaires LDAP, …) qui sont du domaine de l’infrastructure. Mentionner en revanche les éventuels bus d'entreprise qui ont un rôle applicatif (orchestration de service par exemple).

### Architecture applicative détaillée `[niveau_detail::détaillé]`
- Détailler ici tous les modules de l’application, leurs interdépendances et leurs échanges avec d'autres applications du SI ou de partenaires. Les flux sont logiques et non techniques. Par exemple, on peut représenter un flux HTTP direct entre deux modules alors qu'en réalité, il passe par un répartiteur de charge intermédiaire : ce niveau de détail sera donné dans la vue infrastructure. Proposer un ou plusieurs schémas (de préférence des diagrammes C4 de type conteneurs ou diagramme UML2 de composant). Idéalement, le schéma tiendra sur une page A4, sera autoporteur et compréhensible par un non-technicien. Il devrait devenir l'un des artefacts documentaires les plus importants et figurer dans la war room d'un projet agile ou être imprimé par chaque développeur.

#### Principes ayant dicté les choix `[taille_projet::moyen, niveau_detail::détaillé]`
- Fournir ici l'intention dans la construction de l'architecture.

#### Inventaire des modules `[taille_projet::grand, niveau_detail::détaillé]`
- Exposer les modules applicatifs dans leurs différentes zones et/ou domaines.

#### Liens entre modules `[taille_projet::grand, niveau_detail::détaillé]`
- Exposer les dépendances entre l'ensemble des modules applicatifs dans leurs différentes zones ou domaines. Ne pas détailler les flux techniques (comme les flux liés à la supervision ou  au clustering). Si (et seulement si) la complexité de l'application le justifie, proposer en plus de ce schéma global un schéma détaillant chaque chaîne de liaison principale en numérotant les échanges (utiliser un diagramme de séquence ou (mieux) un Dynamic Diagram C4). Utiliser comme ID des flux une simple séquence non signifiante et hiérarchique  (`1`, `2.1`, `2.2.3`, …, `n`). Pour chaque flux, donner le protocole, un attribut lecture/écriture/exécution et une description. Si le flux est asynchrone, le spécifier (dans l'exemple plus bas, l'appel est en pointillés). Chaque chaîne de liaison décrit une fonctionnalité majeure. Dans les cas d'enchaînements complexes, il est préconisé de découper la fonctionnalité en plusieurs chaines de liaison comprenant uniquement des appels synchrones (voir [cet article](https://florat.net/architecture-as-code-with-c4-and-plantuml/)).

### Trajectoires de migrations `[niveau::intermédiaire, migration]`
- Ce chapitre décrit les éventuelles migrations requises depuis des systèmes plus anciens. Décrire de façon macroscopique la procédure envisagée ainsi que les mécanismes de retour arrière. Préciser si un fonctionnement en parallèle de l'ancien système est prévu avant activation (exemple : exécution en mode "à blanc" pour validation).

### Archivage `[niveau_detail::détaillé, archivage]`
- Décrire ici les dispositifs permettant de répondre aux exigences d'archivage. Cette section contiendra principalement :
  - La technologie générale utilisée : idéalement, on dupliquera par sécurité l'archive sur plusieurs supports de technologies différentes : bande magnétique type LTO, disque optique (Blu-ray Disc Recordable par exemple), stockage sur cloud (comme 'Glacier' d'AWS ou 'Coldline' de GCP), disques durs en mode SMR,...).
  - Un lieu de stockage spécifique et distinct des sauvegardes classiques (Cloud, coffre-fort en banque par exemple).

### Purges `[niveau_detail::détaillé]`
- Fournir ici les dispositifs techniques répondant aux exigences de purge.

### Matrice des flux applicatifs `[niveau_detail::approfondi]`
- Lister ici les flux principaux de l'application. Ne pas détailler les flux techniques, notamment ceux liés à la supervision ou au clustering.
