# Sizing view
- Regularly perform full reviews of this view (at least once a year while the project is active) update the date above.
- Indicate the status of the view, for example 'DRAFT', 'FINALIZED', ...

## Introduction `[context]`

### Reference Documentation `[context, references]`

## Not ruled

### Points subject to further study

### Assumptions
- Give here the structuring assumptions taken for the design.

## Constraints `[detail_level::overview, constraint]`
- Constraints are the limits applicable to the requirements on the project. It is interesting to explain them in order to obtain realistic requirements. For example, it would not be realistic to require response times from a web service incompatible with the bandwidth of the underlying network.

### Storage Constraints
- List here the possible constraints related to the disks.

### Compute Constraints `[level::intermediate, detail_level::detailed]`
- List here the possible constraints related to the computing power (CPU, GPU, TPU)

### Memory Constraints `[level::intermediate, detail_level::detailed]`
- List here the possible constraints related to memory

### Network Constraints
- List here the possible network volume constraints used

## Requirements `[detail_level::overview, requirement]`
- It is crucial to collect as much information as possible from production rather than making estimations which often turn out to be far from reality. However, this may not always be possible for new projects. The architects should size the application with a significant margin. The information given here can be used as input to the SLO (Service Level Objective set by the operators).
- The following sections dealing with static and dynamic sizing calculations give examples of calculations and elements to consider. Formally, it may be better to use a spreadsheet. For a complex project or one where assumptions may often change, this is essential.

### Static Sizing Requirements
- These are the metrics used to determine the **cumulative** storage volume of the project. Remember to clearly specify the assumptions made for the estimated metrics. It will thus be possible to review them if new business elements appear.

#### Metrics `[detail_level::detailed]`
- These are measured or estimated business data that will be used as inputs to the calculation of required storage.

#### Estimated storage needs `[detail_level::detailed]`
- List here the storage needs of each module or infrastructure component (especially databases) once the application has reached full load (volume at five years for example). Take into account:
  - The size of the databases.
  - The size of the files produced.
  - The size of the queues.
  - The size of the logs.
  - ... Does not take into account:
  - The volume linked to the backup: it is managed by the operators.
  - The volume of binaries (OS, middleware ...) managed by the operators.
  - Archived data which is therefore no longer online. Also provide an estimate of the annual % increase in volume to allow operators to order or reserve enough disk. For the sizing calculations, remember to take into account the specificities of the encoding (number of octets by character, by date, by numerical value ...). For a database, plan the space occupied by the indexes, which is very specific to each application. A (very poor) preliminary estimate is to double the disk space (to be refined later). Only estimate data whose size is not negligible (several GiB minimum).

### Dynamic Sizing Requirements
- These are metrics by duration (year, month, hour, ...) and allowing to determine the load applied to the architecture, which will help to size the systems in terms of CPU, bandwidth and performance of disks.

#### Metrics `[detail_level::detailed]`
- These are the measured or estimated business data that will be used as inputs for the calculation.

#### Estimated load `[detail_level::detailed]`
- This involves estimating the number of calls to modules and therefore the target throughput (in TPS = Transactions per second) that each of them will have to absorb. A well-sized system should have **average response times of the same order at nominal load and peak**. Always estimate the **"peak of the peak"**, i.e., the moment when the load will be maximum following the accumulation of all the factors (for example for an accounting system: between 02 pm and 03 pm on a weekday at the end of December). Do not consider that the load is constant but take into account:
  - Daily variations. For a management application with users working during office hours, we typically observe peaks of double the average load at 8-9 a.m., 11-12 a.m. and 2 p.m.-3 p.m. For a consumer Internet application, it will be more at the end of the evening. Again, rely on measurements of similar applications when possible, rather than estimates.
  - The elements of seasonality like Christmas for the chocolate industry, Saturday evening for emergency admissions, June for central booking stays etc. The load can then double or even more. This estimate should therefore not be neglected. If the calculation of the peak for a module at the end of the linking chain is complex (for example, a central IS service exposing referential data and called by many modules which each have their own peak), cut the day into time intervals sufficiently small (one hour for example) and the measured or estimated sum of the calls of each caller (batch or GUI) will be calculated over each interval to thus determine the highest cumulative demand. If the application runs on a serverless type cloud service, the load will be absorbed dynamically, but take care to **estimate the additional cost** and to set consistent consumption limits to respect the budget while ensuring a good level of service.
- For an infrastructure component (such as a database instance) at the end of the linking chain and requested by many services, it is necessary to estimate the number of requests at peak by cumulating the calls from all the clients and to **specify the read/write ratio** when this information is relevant (it is especially important for a database). The level of detail of the estimate depends on the progress of the application design and the reliability of the assumptions. In the example below, we already have an idea of ​​the number of requests for each operation. In other cases, we will have to be satisfied with a very broad estimate of the total number of requests to the database and a read/write ratio based on measures from similar applications. No need to go into more detail at this point. Finally, keep in mind that this is **simply an estimation** yet to be validated during campaigns performance and then in production. Plan a sizing adjustment shortly after the production.

### Response time requirements

#### Response Time of GUIs Requirements `[detail_level::detailed, gui]`
- If the clients access the system via WAN (Internet, VPN, LS, etc.), specify that the **response time requirements are given outside network transit** because it is impossible to commit to the latency and throughput of this type of client. In the case of LAN access, it is preferable to integrate the network time, as the load testing tools will already take this into account. The response time objectives are always given with a **statistical tolerance** (90th percentile for example) because reality shows that it is very fluctuating being affected by a large number of factors. No need to multiply the types of requests (depending on the complexity of the screen, for example) because this type of criterion no longer makes much sense today, particularly for a SPA application).

#### Duration of batch Requirements `[detail_level::detailed, batch]`
- Specify here in what time interval the batch processes should run.

## Target sizing `[solution]`
- We give a final sizing to support the static and dynamic sizing and meet the requirements.

### Estimate of resource requirements by deployable unit `[detail_level::detailed]`
- Give here RAM, disk and CPU per deployable unit (to be refined after performance campaign or MEP).

### Sizing of machines
- This section provides the final sizing of the machines required.
  - For Virtual Machines, be careful to check that a VCPU = 1 physical core (and not a thread if hyperthreading is enabled)
  - The internal disk concerns the disk necessary for the OS and the binaries. For a physical machine, this is local storage (local SDD, NMVe or HDD disks). For a VM, it can be a local disk on the physical machine running the VM or a SAN.
  - The external disk concerns storage on a disk bay (SAN). .Sizing of machines (example)

### Non-SAN external storage `[niveau_detail::détaillé]`
- Others external storage deals with distributed file system (NFS, CIFS, WebDav ...) or object storage (Ceph, Swift, Scality, S3, ...)
