# C4 diagrams in Mermaid for the DA

Upstream modele-da draws four C4 diagrams with C4-PlantUML. Use the Mermaid C4 equivalents below (Mermaid flags C4 as experimental: https://mermaid.js.org/syntax/c4.html). Every snippet here was parse-checked with mermaid 12.1.0.

| DA section | Upstream diagram | Mermaid type |
|---|---|---|
| Vue applicative > Architecture applicative générale | `archi-applicative-generale` | `C4Context` |
| Vue applicative > Architecture applicative détaillée > Inventaire des modules | `archi-applicative-detaillee-inventaire` | `C4Container` |
| Vue applicative > Architecture applicative détaillée > Liens entre modules | `archi-applicative-detaillee-dynamique` | `C4Dynamic` |
| Vue infrastructure > Déploiement en production | `infrastructure` | `C4Deployment` |
| Vue développement > Patterns notables (only if a pattern needs it) | none | `C4Component` |

## Conventions (same as upstream)

- Aliases: lowercase snake_case, reused identically in every diagram of the DA and in the flow matrices.
- Relationship label starts with the flow number of the matrix: `"[2.1] Récupère les infos comptables"`. Technology argument = `"<protocole>, <mode>"` with mode `L` (lecture), `E` (écriture), `LE`, `A` (appel stateless), as in the applicative flow matrix legend.
- External actors and systems use the `_Ext` variants. The application under study sits in a `System_Boundary`.
- Infrastructure: one `Deployment_Node` per zone or datacenter, nested `Node` for clusters/hosts, containers inside. No IPs, hostnames or logins (excluded from a DA).
- Keep a diagram under about 15 elements; split rather than crowd. Element order drives layout (Mermaid C4 has no auto-layout); tune with `UpdateLayoutConfig($c4ShapeInRow="3", $c4BoundaryInRow="1")`.
- Not supported by Mermaid C4: `AddElementTag`, `AddRelTag`, `$tags`, `SHOW_LEGEND()`, `Lay_*`, sprites. Do not copy them from PlantUML.
- The diagram illustrates the matrix; it never replaces the table.

## C4Context: architecture applicative générale

```mermaid
C4Context
  title Architecture applicative générale
  Person_Ext(entreprise, "Entreprise", "Usager professionnel")
  System_Boundary(si, "Système d'information") {
    System(app, "Application étudiée", "Rôle en une ligne")
    System(referentiel, "Référentiel Personnes", "Système interne")
  }
  System_Ext(administration_b, "Système administration B", "Fournit les données comptables")
  Rel(entreprise, app, "[1] Demande via formulaire")
  Rel(app, referentiel, "[2.1] Enrichissement données internes")
  Rel(app, administration_b, "[2.2] Récupération informations comptables")
  UpdateLayoutConfig($c4ShapeInRow="3", $c4BoundaryInRow="1")
```

## C4Container: inventaire des modules

```mermaid
C4Container
  title Architecture applicative détaillée (inventaire)
  Person_Ext(entreprise, "Entreprise")
  System_Boundary(si, "Système d'information") {
    Container(spa, "IHM web", "SPA", "Consultation des demandes")
    Container(api, "API demandes", "REST", "Expose les endpoints")
    ContainerQueue(file, "File demandes", "AMQP")
    Container(batch, "Batch traitement", "Job planifié", "Produit les PDF")
    ContainerDb(bdd, "Base demandes", "SGBD relationnel")
  }
  System_Ext(administration_b, "Système administration B")
  Rel(entreprise, spa, "Utilise", "HTTPS")
  Rel(spa, api, "Appelle", "HTTPS, L")
  Rel(api, bdd, "Historise", "SQL, E")
  Rel(api, file, "Publie", "AMQP, E")
  Rel(batch, file, "Consomme", "AMQP, L")
  Rel(batch, administration_b, "Interroge", "HTTPS, L")
```

## C4Dynamic: liens entre modules (scénario)

Mermaid numbers the steps from statement order; the `RelIndex` index argument is ignored, so write the statements in flow order and keep the flow number in the label.

```mermaid
C4Dynamic
  title Scénario [1] Demande d'information
  Person_Ext(entreprise, "Entreprise")
  Container(spa, "IHM web", "SPA")
  Container(api, "API demandes", "REST")
  ContainerDb(bdd, "Base demandes", "SGBD relationnel")
  ContainerQueue(file, "File demandes", "AMQP")
  Container(batch, "Batch traitement", "Job planifié")
  RelIndex(1, entreprise, spa, "[1] Saisit la demande")
  RelIndex(2, spa, api, "[1.1] Demande d'information", "HTTPS, L")
  RelIndex(3, api, bdd, "[1.2] Historise la demande", "SQL, E")
  RelIndex(4, api, file, "[1.3] Stocke la demande", "AMQP, E")
  RelIndex(5, batch, file, "[2.1] Dépile les demandes", "AMQP, L")
```

## C4Deployment: déploiement en production

```mermaid
C4Deployment
  title Déploiement en production
  Deployment_Node(client, "Poste client", "Navigateur / mobile") {
    Container(spa, "IHM web", "SPA")
  }
  Deployment_Node(dc, "Datacenter principal", "Zone FR") {
    Deployment_Node(dmz, "DMZ", "Zone exposée") {
      Container(lb, "Répartiteur de charge", "Actif/passif")
    }
    Deployment_Node(app_zone, "Zone applicative", "Cluster conteneurs") {
      Container(api, "API demandes", "3 instances")
      Container(batch, "Batch traitement", "1 instance")
      ContainerQueue(mq, "Broker", "AMQP, cluster 3 nœuds")
    }
    Deployment_Node(data_zone, "Zone données", "Réseau isolé") {
      ContainerDb(pg, "Base demandes", "Primaire + réplica synchrone")
    }
  }
  Rel(spa, lb, "[F1] Requêtes", "HTTPS 443")
  Rel(lb, api, "[F2] Requêtes", "HTTPS")
  Rel(api, mq, "[F3] Publie", "AMQPS")
  Rel(batch, mq, "[F4] Consomme", "AMQPS")
  Rel(api, pg, "[F5] Lit / écrit", "TLS")
  UpdateLayoutConfig($c4ShapeInRow="3", $c4BoundaryInRow="1")
```

Flow ids `[Fx]` must match the `ID` column of the infrastructure view `Matrice des flux techniques`.
