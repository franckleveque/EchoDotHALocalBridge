# Vue dimensionnement
- Faire régulièrement des revues complètes de la vue (au moins une fois par an tant que le projet est actif) et mettre à jour la date plus haut.
- Indiquer le statut de la vue, par exemple 'DRAFT', 'FINALISÉ',...

## Introduction `[contexte]`

### Documentation de Référence `[contexte, references]`

## Non statué `[contexte, incertitude]`

### Points nécessitant une étude complémentaire

### Hypothèses
- Fournir ici les hypothèses structurantes prises pour le dimensionnement

## Contraintes `[niveau_detail::général, contrainte]`
- Les contraintes définissent les limites applicables aux exigences du projet. Il est important de les expliciter pour obtenir des exigences réalistes. Par exemple, il ne serait pas réaliste d'exiger des temps de réponse d'un web service incompatibles avec le débit du réseau sous-jacent.

### Contraintes de stockage
- Lister ici les éventuelles contraintes liées au stockage persistant.

### Contraintes de puissance de calcul `[niveau::intermédiaire, niveau_detail::détaillé]`
- Lister ici les éventuelles contraintes liées à la puissance de calcul (CPU, GPU, TPU)

### Contraintes sur la mémoire `[niveau::intermédiaire, niveau_detail::détaillé]`
- Lister ici les éventuelles contraintes liées à la mémoire.

### Contraintes sur le réseau
- Lister ici les éventuelles contraintes de volume réseau utilisé

## Exigences `[niveau_detail::général, exigence]`
- Il est crucial de privilégier les données issues de la production plutôt que des estimations, car ces dernières sont souvent éloignées de la réalité. C'est d'autant plus difficile s'il s'agit d'un nouveau projet. Il est alors recommandé de prévoir une marge importante. Les informations données ici pourront servir d'entrants au SLO (Service Level Objective) fixé par les exploitants.
- Les sections suivantes portant sur les calculs de volumétrie statiques et dynamiques donnent des exemples de calculs et d'éléments à prendre en compte. Sur le plan de la forme, il peut être préférable de remplacer le texte par des feuilles de calculs dans un tableur. Pour un projet complexe ou aux hypothèses mouvantes, c'est indispensable.

### Exigences sur la volumétrie statique
- Il s'agit des métriques permettant de déterminer le volume de stockage **cumulé** du projet. Penser à bien préciser les hypothèses prises pour les métriques estimées. Il sera ainsi possible de les revoir si de nouveaux éléments métier apparaissent.

#### Métriques `[niveau_detail::détaillé]`
- Il s'agit des données métier mesurées ou estimées qui serviront d'entrants au calcul des besoins techniques de stockage.

#### Estimation besoins de stockage `[niveau_detail::détaillé]`
- Lister ici les besoins en stockage de chaque module une fois l’application arrivée à pleine charge (volumétrie à cinq ans par exemple). Prendre en compte :
  - La taille des bases de données.
  - La taille des fichiers produits.
  - La taille des files.
  - La taille des journaux.
  - L'espace nécessaire dans un éventuel stockage objet (S3, Swift, Ceph…)
  - … Ne pas prendre en compte :
  - Le volume lié à la sauvegarde : elle est gérée par les exploitants.
  - Le volume des binaires (OS, intergiciels…) qui est à considérer par les exploitants comme une volumétrie de base d'un serveur (le ticket d'entrée) et qui est de leur ressort.
  - Les données archivées qui ne sont donc plus en ligne. Fournir également une estimation de l'augmentation annuelle en pourcentage du volume pour permettre aux exploitants de commander ou réserver suffisamment de disque. Pour les calculs de volumétrie, penser à prendre en compte les spécificités de l'encodage (nombre d’octets par caractère, par date, par valeur numérique…). Pour une base de données, prévoir l'espace occupé par les index, qui varie selon l'application et le moteur de base de données. Une estimation préliminaire peut consister à ajouter environ 30 % d'espace disque supplémentaire, à affiner selon les tests. Ne prendre en compte que les données dont la taille est significative (au moins quelques Gio).

### Exigences sur la volumétrie dynamique
- Il s'agit des métriques par durée (année, mois, heure…) et permettant de déterminer la charge appliquée sur l'architecture, ce qui aidera à dimensionner les systèmes en terme de CPU, bande passante et performances des disques.

#### Métriques `[niveau_detail::détaillé]`
- Ce sont les données métier mesurées ou estimées qui serviront d'entrants au calcul de la charge.

#### Estimation de la charge `[niveau_detail::détaillé]`
- Il s'agit ici d'estimer le nombre d'appels aux modules et donc le débit cible (en TPS = Transactions par seconde) que chacun d'entre eux devra absorber. Un système bien dimensionné devra présenter des temps de réponse moyen du même ordre en charge nominale et en pic. Estimer le "pic du pic", c'est-à-dire le moment où la charge sera maximale suite au cumul de tous les facteurs (par exemple pour un système de comptabilité : entre 14 et 15h  un jour de semaine de fin décembre). Ne pas considérer la charge comme constante mais prendre en compte :
  - Les variations journalières. Pour une application de gestion avec des utilisateurs travaillant sur des heures de bureau, on observe en général des pics du double de la charge moyenne dans les périodes 8h-9h, 11h-12h et 14h-15h. Pour une application Internet grand public, ce sera plutôt en soirée. Encore une fois, se baser sur des mesures d'applications similaires quand c'est possible plutôt que sur des estimations.
  - Les éléments de saisonnalité. La plupart des métiers en possèdent : Noël pour l'industrie du chocolat, le samedi soir pour les admissions aux urgences, juin pour les centrales de réservation de séjours etc. La charge peut alors doubler, voire davantage. Il ne faut donc pas négliger cette estimation. Si le calcul du pic pour un module en bout de chaîne de liaison est complexe (par exemple, un service central du SI exposant des données référentiel et  appelé par de nombreux modules qui ont chacun leur pic), on tronçonnera la journée en intervalles de temps suffisamment fins (une heure par exemple) et on calculera sur chaque intervalle la somme mesurée ou estimée des appels de chaque appelant (batch ou transactionnel) pour ainsi déterminer la sollicitation cumulée la plus élevée. Si l'application est déployée sur un cloud de type serverless, la charge sera absorbée dynamiquement. Il convient néanmoins d'estimer le surcoût et de fixer des limites de consommation pour concilier budget et qualité de service.
- Pour un service d'infrastructure (comme une instance de base de données) en bout de chaîne et sollicité par de nombreux services, il convient d'estimer le nombre de requêtes en pic en cumulant les appels de tous les clients et de préciser le ratio lecture /écriture quand cette information est pertinente (elle est très importante pour une base de données). Le niveau de détail de l'estimation dépend de l'avancement de la conception de l’application et de la fiabilité des hypothèses. Dans l'exemple plus bas, nous avons déjà une idée du nombre de requêtes pour chaque opération. Dans d’autres cas, on devra se contenter d'une estimation très large sur le nombre de requêtes total à la base de données et un ratio lecture / écriture basée sur des abaques d'applications similaires. Inutile de détailler plus à ce stade. Enfin, garder en tête qu'il s'agit simplement d'estimation à valider lors de campagnes de performances puis en production. Prévoir un ajustement du dimensionnement peu après la MEP.

### Exigences de temps de réponse

#### Exigences de temps de Réponse des IHM `[niveau_detail::détaillé, ihm]`
- Si les clients accèdent au système en WAN (Internet, VPN, LS …), préciser que les exigences de TR sont données hors transit réseau car il est impossible de s’engager sur la latence et le débit de ce type de client. Dans le cas d’accès LAN, il est préférable d’intégrer le temps réseau, d’autant que les outils de test de charge vont déjà le prendre en compte. Les objectifs de TR sont toujours donnés avec une tolérance statistique (90e centile par exemple) car la réalité montre que le TR est très fluctuant car affecté par un grand nombre de facteurs. Inutile de multiplier les types de sollicitations (en fonction de la complexité de l’écran par exemple) car ce type de critère n’a plus grand sens aujourd'hui, particulièrement pour une application SPA).

#### Exigences sur la durée d’exécution des batchs `[niveau_detail::détaillé, batch]`
- Préciser ici dans quel intervalle de temps les traitements par lot doivent s’exécuter.

## Dimensionnement cible `[solution]`
- Nous donnons un dimensionnement final qui doit supporter la volumétrie statique et dynamique et respecter les exigences.

### Estimation des besoins en ressources par unité déployable
- Fournir ici RAM, disque et CPU par instance d'unité déployable (à affiner après campagne de performance ou MEP).

### Dimensionnement des machines
- Cette section fournit le dimensionnement final des machines nécessaires
  - Pour les VM, attention à vérifier qu'un vCPU (Virtual CPU) = 1 cœur physique (et non un thread si hyperthreading activé) ;
  - Le disque interne concerne le disque nécessaire à l'OS et aux binaires. Pour une machine physique, il s'agit de stockage local (disques locaux SDD, NVMe ou HDD). Pour une VM, il peut s'agir d'un disque local sur la machine physique exécutant la VM ou d'un SAN ;
  - Le disque distant concerne du stockage sur une baie de disque (SAN) ;

### Dimensionnement du stockage externe hors SAN `[niveau_detail::détaillé]`
- Le stockage externe hors SAN concerne du stockage fichier sur un système de fichier distribué (NFS, CIFS, WebDav, …) ou un stockage objet (Swift, S3, etc.).
