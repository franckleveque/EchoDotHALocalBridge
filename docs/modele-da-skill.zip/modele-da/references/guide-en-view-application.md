# Application view
- Regularly perform full reviews of this view (at least once a year while the project is active) update the date above.
- Indicate the status of the view, for example 'DRAFT', 'FINALIZED', ...

## Introduction `[context]`

### Reference Documentation `[references]`

## Not ruled `[uncertainty]`
- In architecture, uncertainty should be stated clearly to help understand design choices and the current situation.

### Points subject to further study `[uncertainty]`

### Assumptions `[uncertainty]`
- Give here the structuring assumptions taken for the design.

## General context `[detail_level::overview]`

### Objectives
- Briefly describe the project and recall its objectives. Highlight those which are structuring for the architecture.

### Existing `[rewrite]`
- If this document presents a redesign or migration project, describe briefly the existing application. Do not repeat the documentation, simply refer to it and point to its architecture document if available. Beware of mentioning any information with a strong impact on the new project.

### Positioning in the IS `[project_size::large]`
- If the IS is urbanized, identify the block concerned by the project.

### Actors

#### Internal actors
- By the term "internal", the IT team project refers to actors belonging to the organization. These actors can be humans or application modules.

#### External actors

#### Nature and Sensitivity of Data and Processing
- Do not reproduce the DPIA (Data Protection Impact Assessment) here, but reference it if it exists.

## Constraints `[detail_level::overview, constraint]`
- Limits and imposed choices on how you may design/implement the solution. They restrict the design space (technology, process, organization, time, budget, regulation).

### Budget Constraints
- Give the budget constraints of the project

### Planning Constraints
- Without detailing the project schedules, it is suggested to highlight interesting elements for the architecture.

### Urbanization `[project_size::large]`
- List here the constraints relating to urbanization, this includes for example but not only:
  - The rules applicable for calls between modules (SOA)
  - Call rules between network zones
  - The rules concerning the localization of data (MDM)
  - The rules concerning the propagation of updates by events (EDA)

### Legal Constraints

## Requirements `[detail_level::overview, requirement]`
- What the solution must achieve for stakeholders: capabilities, behaviors, and quality levels. They express needs/goals and are (ideally) testable. Depending on your context, feel free to add sub-sections.

### Strategic Requirements
- Describe here the requirements related to the overall strategy of the project in terms of trajectory, budget, and organization.

### Interoperability Requirements
- Describe here the requirements regarding protocols, formats, and semantics to be followed to facilitate exchanges with organizations or third parties.

### Concurrency management Requirements `[level::intermediate, detail_level::detailed]`
- Specify the internal or external modules that may interfere with the application.

### Degraded Modes Requirements `[level::advanced, detail_level::detailed]`
- Specify the degraded application modes.

### Archiving Requirements `[detail_level::detailed, archiving]`
- Archiving is the copying of important data to a dedicated offline medium for occasional consultation, unlike backup which is intended for restoration. Archives are often required for legal reasons and kept for thirty years or more. Specify if application data needs to be kept long-term. Specify the reasons for this archiving (usually legal). Specify if specific integrity protection mechanisms (mainly to prevent any modification) need to be put in place.

### Retention Periods Requirements `[detail_level::detailed]`
- Specify here how long data and documents persisted by your application modules should be kept. Note that these durations may be legally constrained (see legal constraints above), for example in the context of the GDPR right to be forgotten.
- Don't forget to mention technical data (such as logs or technical tables) as well as archives.

## Target architecture `[solution, detail_level::overview]`

### General application architecture
- Present here the application as a whole (without detailing its sub-components) in relation to the other applications of the IS. Also present the macro-data exchanged or stored. Summarize:
  - The kind of architecture (client-server, monolithic Web, SOA, micro-service, event-driven...).
  - Large network flows between modules or between applications in the case of monoliths.
  - Any derogation to applicable architectural rules. If the application is planned to be implemented in several stages, briefly describe the target trajectory.
- The choice of representation is free but a C4 diagram from System Landscape or a UML2 component diagram seems the most suitable. We provide patterns and details on this topic in [this article](https://florat.net/architecture-as-code-with-c4-and-plantuml/). Numbering the steps in chronological order ensures a better understanding of the diagram. Group the sub-steps by the notation x, x.y, x.y.z, ... Do not include specific infrastructure system (SMTP server, security device, reverse proxy, LDAP directories, etc.) which are in the domain of technical architecture. On the contrary, mention Enterprise Service Buses, API Gateway or similar infrastructure components if they play an application role (service orchestration for example).

### Detailed application architecture `[detail_level::detailed]`
- Detail here all the modules of the application, their interdependencies, and the interactions with other applications within the information system (IS) or with partners. The flows are logical rather than technical (for example, you can represent a direct HTTP flow between two modules even though, in reality, it passes through an intermediate load balancer: this level of detail will be provided in the infrastructure view). Propose one or more diagrams (preferably C4 container diagrams or UML2 component diagrams). You can find further patterns and details in [this article](https://florat.net/architecture-as-code-with-c4-and-plantuml/). Ideally, the diagram should fit on an A4 page, be self-explanatory, and understandable by a non-technical person. It should become one of the most important documentation artifacts and be displayed in the war room of an agile project or printed by each developer.

#### Principles that dictated the choices `[project_size::medium, detail_level::detailed]`
- Give here the intention in the architecture conception.

#### Inventory view `[project_size::large, detail_level::detailed]`
- Expose the application modules in their different zones or domains.

#### Links between modules `[project_size::large, detail_level::detailed]`
- Expose the dependencies between all application modules across their various zones or domains. Do not detail technical flows (such as those related to monitoring or clustering). If (and only if) the complexity of the application justifies it, propose, in addition to this global diagram, a detailed diagram for each main communication chain by numbering the exchanges (use a sequence diagram or, preferably, a Dynamic Diagram C4). Use a simple, non-significant, and hierarchical sequence as the ID for the flows (e.g., 1, 2.1, 2.2.3, ..., n). For each flow, specify the protocol, a read/write/execute attribute, and a description. If the flow is asynchronous, indicate this (in the example below, the call is shown in dashed lines). Each communication chain describes a major functionality. In cases of complex sequences, it is recommended to break down the functionality into several communication chains containing only synchronous calls (see [this article](https://florat.net/architecture-as-code-with-c4-and-plantuml/)).

### Transition paths `[level::intermediate, rewrite]`
- This chapter describes a required migrations from older systems. Describe on a macroscopic scale the planned procedure as well as the rollback strategy in case of problem. Describe, if necessary, a dry-run operation in parallel with the old system.

### Archiving `[detail_level::detailed, archiving]`
- Describe here the measures to meet archiving requirements. This section will mainly include:
  - Technology: Ideally, for security, the archive will be duplicated on multiple media of different technologies: magnetic tape type LTO, optical disk (Blu-ray Disc Recordable for example), cloud storage (such as AWS 'Glacier' or GCP 'Coldline'), SMR mode hard drives, etc.
  - A specific storage location distinct from traditional backups (e.g., Cloud, bank vault).

### Purges `[detail_level::detailed]`
- Describe here the technical measures to meet purge requirements.

### Matrix of application flows `[detail_level::in-depth]`
- List here the main network flows of the application. Do not detail the monitoring or clustering streams for example. Indicate the type of network (LAN, WAN).
