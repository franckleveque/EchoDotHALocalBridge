# Infrastructure view
- Regularly perform full reviews of this view (at least once a year while the project is active) update the date above.
- Indicate the status of the view, for example 'DRAFT', 'FINALIZED', ...

## Introduction `[context]`
- This point of view deals with the infrastructure: servers, networks, operating systems, databases, middlewares, etc. In short, it covers everything that is external to the application modules but necessary for their execution.

### Reference Documentation `[references]`
- Mention here the reference (defined at a IS level) architecture documents. This file should never summarize their content under penalty of quickly becoming obsolete and unmaintainable.

## Not ruled `[context, uncertainty]`

### Points subject to further study

### Assumptions
- Give here the structuring assumptions taken for the design.

## Constraints `[detail_level::overview, constraint]`
- Constraints are the limits applicable to the requirements on the project. It is interesting to explain them in order to obtain realistic requirements. For example, it would not be valid to require an availability incompatible with the Tier security level of the data center that will host it.

### Availability Constraints `[availability]`
- The elements provided here can serve as a basis for the SLO (Service Level Objective). Ideally, this file should simply point to such an SLO without further clarification. When available, it may be augmented with others metrics like MTTF (Mean Time Between Failures). This chapter has a pedagogical vocation because it highlights the maximum possible availability: the final availability of the application can only be lower.

#### MTTD Constraints `[detail_level::detailed, monitoring]`
- Provide here the elements which make possible to estimate the average incident detection time.

#### Monitoring Tooling Constraints `[detail_level::detailed, monitoring]`
- Give here the tools and monitoring rules imposed at the IS level and any related constraints.

#### MTTR Constraints `[detail_level::detailed]`
- Provide the elements to estimate the average repair time (Mean Time To Repair). Note that it is important to distinguish MTTD from MTTR. Indeed, it is not because a fault is detected that the skills or resources necessary for its correction are available. Specify the time slots for operators to be present during the day and the possibilities of on-call duty. If you have statistics or post-mortems, mention the average effective durations already observed. List here the intervention times of the hardware, software, electricity, telecom service providers, etc. We tentatively divide this section into "Hardware", "System and Virtualization", "Network", and "Data Recovery" subsections. Other categories are possible.

##### Hardware Constraints `[detail_level::in-depth]`
- Describe here the elements used to predict the MTTR of hardware elements (servers / racks / network equipment / electrical systems, etc.). List for example here the durations of intervention of the material service providers, electricity….

##### System and virtualization `[detail_level::in-depth]`
- List here the elements allowing to estimate the correction time of a problem related to the OS or to a possible virtualization solution.

##### Network `[detail_level::in-depth]`
- List here the elements related to the network allowing to estimate the durations of intervention of the service providers or Telecom suppliers...

##### Data Restore `[detail_level::detailed]`
- List here the elements allowing to evaluate the duration of data restoration (files / objects / database). The RTO requirements listed below should take this MTTR into account.

#### Scheduled Interruptions Constraints `[detail_level::in-depth]`
- Give here the list and the duration of the standard programmed interruptions (maintenance windows).

#### Level of service of the datacenter `[detail_level::detailed]`
- Give here the security level of the data center (DC) according to the Uptime Institute scale (Tier from 1 to 4). TIP: It should be noted that modern Cloud architectures favor the redundancy of DCs across distant sites rather than a higher Tier level at a single site (provided that data can be replicated effectively and a delay in immediate data consistency is acceptable, see the [CAP theorem](https://en.wikipedia.org/wiki/CAP_theorem)). Simplistically, it can be calculated that the availability of two active DCs in parallel is seven nines versus four nines for a Tier 4 DC. A compromise between the two models is deployment in redundant zones of the same site, at the cost of greater vulnerability to disasters. .Tier levels of data centers (source: Wikipedia)

#### Availability Ceiling `[detail_level::overview]`
- Make it clear to stakeholders that, even with application-level HA, the **maximum end-to-end availability** is capped by the availability of underlying dependencies (datacenter, network, platform). This **Availability Ceiling** is the product of their SLAs, and is always < the least available dependency. `A_upper_bound = ∏(A_SLA of each serial dependency)  ≤  min(A_SLA)` **Implication:** SLO targets **must not exceed** this ceiling. HA helps you approach the ceiling, not surpass it. **Scope notes**
  - If all replicas sit in the **same failure domain** (same DC/power/edge), the DC’s SLA effectively **sets the ceiling**.
  - To **raise the ceiling**, use **independent failure domains** (e.g., multi-AZ/region); then for parallel redundancy: `A_parallel = 1 - ∏(1 - A_i)` (independence assumed).

#### Disaster Management Constraints `[detail_level::overview]`
- Disasters can be classified into three categories:
  - Natural (earthquakes, floods, hurricanes, heatwaves, etc.);
  - Infrastructure-related (accidental such as industrial accidents, fires, major power outages, major network/storage/server failures, critical administrator errors or intentional: military, terrorist, sabotage, etc.);
  - Cyber (DDoS, viruses, ransomware, etc.). **Disaster Recovery (DR)** is the set of strategies and solutions implemented to **restore a computer system after a disaster**, thereby minimizing data loss and downtime. DR can include solutions such as:
  - **Cold site**: backup center ready to be activated but without active infrastructure;
  - **Warm site**: pre-installed infrastructure but requiring manual production deployment;
  - **Hot site**: real-time replication with possible automatic failover;
  - **Disaster Recovery as a Service (DRaaS)**: cloud-based rapid recovery solutions (AWS Elastic Disaster Recovery, Azure Site Recovery, etc.). The **Disaster Recovery Plan (DRP)** and **Business Continuity Plan (BCP)** are specific **DR** strategies responding to a risk of disaster on the IT system:
  - **Disaster Recovery Plan (DRP)** or **"How to return to normal after the problem?"** Allows **resuming activity after a disaster** within a defined timeframe (RTO). It relies on **asynchronous synchronizations between sites, backups, restorations, and backup infrastructures** such as **secondary DC, replicated storage**, or **DRaaS solutions**. The goal is to ensure recovery, but with a **temporary interruption** and acceptance of a non-zero RPO.
  - **Business Continuity Plan (BCP)** or **"How to continue working despite the problem?"** Ensures the **continuity of critical activities** without significant interruption and with an almost zero RPO. It includes organizational measures (crisis teams, degraded mode such as paper usage, fallback sites, etc.) and technical measures such as **multi-zone active-active clusters, synchronous data replication, and highly redundant infrastructures**. An architect does not use the same technologies depending on whether the goal is a **DRP or BCP**:
  - **DRP** → Focuses on **backup and restoration** in a backup DC, with a **defined RTO**. On-premises examples: **VM snapshots with Veeam, DRaaS solutions, databases replicated in asynchronous mode** (e.g., **MySQL/MariaDB asynchronous, PostgreSQL streaming replication, SQL Server log shipping, VMware vSphere Replication, Dell EMC SRDF in asynchronous mode, Zerto**). Cloud examples: **AWS Aurora Global Database (asynchronous inter-region replication), Amazon RDS cross-region read replicas, Azure SQL Geo-Replication, Google Cloud SQL cross-region replication**.
  - **BCP** → Relies on **multi-zone active-active clusters** distributed across several distant DCs, with **generally synchronous replication** to ensure a zero (or near-zero) RPO. On-premises examples: **Oracle RAC, VMware vSphere Metro Storage Cluster, NetApp MetroCluster, Dell EMC SRDF in synchronous mode, Ceph RADOS synchronous**. Cloud examples: **Google Cloud Spanner (synchronous multi-region replication), Azure SQL Managed Instance Business Critical with redundant zones, AWS Aurora Multi-AZ (synchronous replication)**. Notes:
  - For a BCP, synchronous replication is often used to ensure a zero RPO, but some architectures (e.g., vSphere Metro Storage Cluster with asynchronous SRDF) allow a BCP with asynchronous replication, provided that the RPO remains within acceptable limits (loss of only a few transactions). However, synchronous replication over long distances can introduce high latency, impacting performance. This is why this type of synchronous replication is not feasible for DCs more than approximately 50 km apart.
  - A DRP, on the other hand, can tolerate asynchronous replication or periodic backups depending on business requirements.
  - Traditional backup systems may suffice for a DRP with an appropriate RTO but are generally insufficient for a BCP, which requires real-time replication.
  - In the case of a DRP, a failover and significant preparation of the backup DC must be planned, whereas in the case of a BCP, all DCs operate in parallel in active/active mode under normal conditions.
  - Failover tests should be conducted at least once a year for a DRP, and quarterly for a BCP. They must include unit tests (failover of an application) and global tests (complete IT system failover). Note: Disaster management is a complex topic. One of the strengths of public clouds (OVH, GCP, Azure, AWS, etc.) is that they manage part of this complexity for you. Specific cloud solutions exist (Disaster Recovery as a Service – DRaaS). Describe, among other things:
  - The redundant hardware in the second DC, the number of spare servers, the capacity of the backup DC compared to the primary DC.
  - For a DRP, the planned restoration devices (OS, data, applications) and the RTO.
  - For a BCP, the latency and performance degradation induced by synchronous data replication between DCs or the acceptable amount of lost transactions in case of asynchronous replication.
  - Present the failback policy (reversibility): should we fail back to the first DC? How?
  - How are failover tests organized? With what frequency?

### Hosting Constraints `[detail_level::overview]`

### Network Constraints `[detail_level::detailed]`
- List the constraints dealing with the network, in particular the theoretical maximum bandwith and the divisions into security zones. Performance considerations are detailed in the sizing view.

### Deployment Constraints `[detail_level::detailed]`
- List the constraints related to the deployment of modules and infrastructure components.

### Constraints Related to the Lifecycle of Infrastructure Components `[detail_level::detailed]`
- List the constraints related to updates and maintenance of infrastructure components (operating systems, middleware, databases, etc.).

### Log Constraints `[detail_level::detailed]`
- List the constraints related to logs

### Backup And Restore Constraints `[detail_level::detailed]`
- List the constraints related to backups A common constraint is adherence to the 3-2-1 method:
  - At least 3 copies of the data (the active data + 2 backups);
  - At least 2 different storage technologies for these 3 copies (example: SSD for the active data and two backups on tape);
  - At least 1 offline and offsite copy (example: a set of tapes stored in a fireproof safe at the bank).

### Costs Constraints `[detail_level::detailed]`
- List the budget limits.

## Requirements `[detail_level::overview, constraint]`
- Contrary to the constraints which fixed the boundaries to which any application had to conform, the non-functional requirements are given by the project decision-makers. Schedule interviews to collect requirements. To result into something useful, interviews must be educational, recall the constraints and highlight realistic costs. If certain requirements are still not realistic, mention it in the "Points subject to further study" section.

### Operating Ranges
- The main operating ranges are listed here (do not go into too much detail, this is not a production plan). Think about users located in other time zones. The information given here will be used as input to the application SLA.

### Availability Requirements `[availability]`
- We list the availability requirements here. The technical measures to achieve them will be given in the technical architecture of the solution. The resulting maximum downtime listed here must follow nature and sensitivity of data defined in application view. These information can be used as input to the application **SLA**. Be careful to frame these requirements because decision-makers often tends to request very high availability without always realizing the implications. The cost and complexity of the solution increases exponentially with the level of availability required. The physical, technical or even software architecture can be completely different depending on the availability requirements (middleware or even database clusters, expensive hardware redundancies, asynchronous architecture, session caches, failover, etc.). It is generally estimated that high availability (HA) starts at three nines (99.9%), that is to say around 8h45 of downtime per year. Give the availability requested by range. The availability required here must be consistent with the “Constraints on availability” of the IS.

### Robustness Requirements `[level::intermediate, detail_level::detailed]`
- The robustness of the system indicates its ability not to produce errors during exceptional events such as overload or failure of one of its infrastructure components. This robustness is expressed in absolute value per unit of time: number of (technical) errors per month, number of messages lost per year, etc. Be careful not to be too demanding on this point because great robustness can imply the implementation of fault-tolerant systems that are complex, expensive and that can go against the capacity to scale up, or even availability.

### RPO Requirements `[level::intermediate]`
- Give here the Recovery Point Objective (RPO) of the application (i.e. how much data we agree to lose since last backup) in unit of times. Data restoration occurs mainly in following cases:
  - Hardware data loss (unlikely with redundant systems).
  - A power-user or operator error (quite common).
  - An application bug.
  - A deliberate destruction of data (ransomware-type attack) ...

### RTO Requirements `[level::intermediate, project_size::medium, project_size::large, detail_level::overview]`
- The Recovery Time Objective (in unit of times) is the maximum authorized time objective for reopening the service following an incident. This requirement must be compatible (less than or equal) to the MTTR given in constraint above. It is in fact useless to require an RTO of 1H if the operators have measured an effective MTTR of 2H. It must also be compatible with the availability requirement. Specify this value only to clarify a precise restoration objective, otherwise, do not complete this section and refer to the MTTR constraint above.

### Deployment and Upgrades Requirements `[level::intermediate, detail_level::detailed]`

#### Server side
- Specify here how the application should be deployed on the server side. For example :
  - Is the installation manual? scripted with IT Automation tools like Ansible or Terraform? via Docker/OCI images?
  - How are the modules deployed? As packages? Are we using a package repository (type yum or apt)? Do we use containers?
  - How are they upgraded?

#### Client side `[gui]`
- Specify here how the application should be deployed on the client side:
  - If the application is large (large .js files or images for example), is there a risk of an impact on the network?
  - Local proxy caching to be expected?
  - Are firewall rules to be expected?
  - (For a standalone application): which version of the OS is supported?
  - If the OS is Windows, does the installation go through a deployment tool (Novell ZENWorks for example)? Does the application come with a Nullsoft-style installer? Does it affect the system (environment variables, registry, etc.) or is it in portable mode (single zip)?
  - If the OS is Linux, should the application be provided as a package?
  - How are the updates applied?

#### Specific deployment strategy `[level::intermediate, detail_level::detailed]`
- - Are we planning a blue/green deployment?
  - Are we planning a canary testing type deployment? if so, on what criteria?
  - Are we using feature flags? if so, on which features?

### Ecodesign Requirements `[level::intermediate]`
- Ecodesign consists of limiting the environmental impact of the software and hardware used by the application. Requirements in this area are generally expressed in WH or CO2 equivalent. Also take into account impressions. Check out the EPA's Greenhouse Gas Equivalencies Calculator for CO2/KWH equivalency.

## Target Architecture `[detail_level::overview, solution]`

### Principles `[detail_level::detailed]`
- What are the main infrastructure principles of our application?

### Availability `[level::intermediate, availability]`
- Availability represents the minimum proportion of time a system over a year during which it works in acceptable conditions. It is expressed as a percentage (example: 99.9%). List here the measures taken to meet the availability requirements. The available measures are very varied and should be chosen by the architect according to their respective contribution and cost. We can group availability measures into four main categories:
  - **Monitoring measures** allowing to detect faults as early as possible, hence lowering the MTDT (average detection time).
  - **Organizational measures**:
    - Human presence (on-call, extended support hours, etc.) which improves the MTTR (average resolution time) and without which monitoring is inefficient;
    - Quality of incident management (see ITIL best practices), for example, is an Incident Management Procedure written? Direct enough (for instance several hierarchical validations decrease the MTTR)?
  - **High Availability (HA)** measures like clusters or RAID.
  - **Data Recovery measures**: is the recovery procedure well defined? Tested? Being able to quickly restore the last backup greatly improves the MTTR.
- **Availability and redundancy**:
  - The **availability of a set of serial infrastructure components** can be computed by this formula: `A = A1 * A2 * ... * An`. Example: the availability of an application using a Tomcat server available at 98% and an Oracle database available at 99% would be 97.02%.
  - The **availability of a set of infrastructure components in parallel** can be computed by this formula: `A = 1 - (1-A1) * (1-A2) * .. * (1-An)`. Example: the availability of three clustered Nginx servers each available at 98% is 99.999%.
  - It is important to be consistent on the **availability of each link** in the linking chain: there is no point in having an expensive active/active cluster of JEE application servers if all these servers call a database located on a single server physical with disks without RAID.
  - A system is estimated to be **highly available (HA) from 99%** availability.
  - The term **“spare”** designates a spare device (server, disk, electronic card, etc.) which is dedicated to the need for availability but which is not activated outside of failures. Depending on the level of availability requirement, it can be dedicated to the application or shared at the IS level.
  - The main **redundancy models** (NMR = N-Modular Redundancy) are listed below (with N, the number of devices ensuring correct operation under load and that we can replicate):
    - **N**: No redundancy (example: when a server single power supply fails, the server is down)
    - **N+1**: Single Spare. A spare infrastructure component is available (but not yet active), we can support the failure of a piece of equipment (example: we have a spare power supply available).
    - **N+M**: Multiple Spare. A single spare infrastructure component cannot handle the load, at least M spare devices are required.
    - **2N**: Fully Redundant and Active. The system is fully redundant and active and can withstand the loss of half of the infrastructure components (example: we have two power supplies, if one fails, the server keeps running). This system is considered Fault-Tolerant.
    - **2N+1**: Fully Redundant with Additional Spare. In addition to a fully mirrored system, a backup system is available (for maintenance operations for instance).
- **Clustering**:
  - A cluster is a **set of nodes (servers) hosting the same application module**.
  - Depending on the level of availability sought, each node can be:
    - **active**: the node processes the requests (example: one Apache web server among ten and behind a load balancer). Failover time: zero;
    - **passive in “hot standby” mode**: the node is installed and started but does not process requests (example: a MySQL slave database which becomes master). MTTR: a few seconds (failure detection time);
    - **passive in “warm standby” mode**: the node is started and the application is installed but not started (example: a server with a turned off Tomcat instance hosting our application). In case of failure, the application is started automatically. MTTR: of the order of a minute (time for detection of the failure and activation of the application);
    - **passive in "cold standby" mode**: the node is a simple spare. To use it, we have to install the application, configure and start it. MTTR: from tens of minutes with virtualization solutions (eg: KVM live migration) and/or containers (Docker) to several hours on systems where none automatic deployment features are available.
  - There are two active/active cluster architectures:
    - **Loosely coupled active/active clusters** in which one node is completely independent from the others, either because the application is stateless (the best case), or because the context data (typically an HTTP session) is managed in isolation by each node. In the latter case, the load balancer must ensure session affinity, i.e., always route requests from a client to the same node and in the event of failure of this node, the users routed there lose their session data and need to reconnect (Note: the nodes all share the same data persisted in the database, the context data on each node is only transient data in memory).
    - **Strongly coupled active/active clusters** in which all nodes share the same data. In this architecture, all context data must be replicated in every node (e.g. distributed cache of HTTP sessions replicated with JGroups).
- **Failover**: Failover is the ability of a cluster to ensure that in the event of a failure, requests are no longer sent to the failed node but to a running node. This process is **automatic**. Without failover, it is up to the client to detect the failure and reconfigure itself to only call the running nodes. In fact, this is rarely practicable and the **clusters almost always have failover capacities**. A failover solution can be described by the following attributes:
  - Which **Failover strategy** ? For instance: "Fail fast" (a node is considered as down as soon as a failure is detected), "On fail, try next one", "On fail, try all".
  - Which **fault detection solution**?
    - Load balancers can use a wide variety of health checks (mock requests, CPU analysis, logs, etc.) to check the nodes they control;
    - Active/passive clusters failure detections work most of the time by listening to the heartbeat of the active server by the passive server, for example via UDP multicast requests in the VRRP protocol used by keepalived.
  - How long does it take to detect the failure? failure detection solutions should be configured correctly (as short as possible without degradation of performance) to limit the duration of the failover.
  - What **relevance of the detection**? is the down server * really * down? a bad setting or a network micro-cut should not cause a total unavailability of a cluster while the nodes are still healthy.
  - What strategy for **failback**?
    - in an **N-to-1** cluster, we will failback on the server which had broken down once repaired and the failed server will become the backup server again;
    - in an **N-to-N** cluster (an architecture in the process of democratization with the PaaS type cloud like AWS Lambda or CaaS like Kubernetes): the services previously running on the failed node are distributed to the remaining nodes (the cluster having been sized in anticipation of this possible overload).
  - **Transparent for the caller or not**? In general, the requests pointing to a server whose failure has not yet been detected fall in error (in timeout most of the time). Some advanced Fault Tolerant systems or architectures can make it transparent for the client.
- A few words about **load balancers**:
  - A load balancer (*) is a **mandatory brick** for an active/active cluster.
  - In the case of clusters, a classic error is to make LB a **SPOF**. We would then reduce the total availability of the system instead of improving it. When dealing with the clusters with a availability vocation (i.e. not only performance-oriented), it is necessary to redundant the LB itself in active/passive mode (obviously not in active/active mode otherwise, we would only shift the problem). The passive LB must monitor the active LB at high frequency and replace it automatically as soon as it falls.
  - It is crucial to configure correctly and at a sufficient frequency the **heath checks** to the destination nodes because otherwise the LB will continue to send requests to failed or overloaded nodes.
  - Some advanced LBs (example: `redispatch` option of HAProxy) allow the failover process to be transparent seen from the client by retrying to other nodes in the event of a failure or timeout and therefore improve fault tolerance since we avoid to return an error to the caller during the fault pre-detection period.
  - **Round Robin load repartition algorithm is not always the best choice**. A simple algorithm is the LC (Least Connection) allowing the LB to favor the least loaded nodes. Other clever algorithms exist and can be taken into consideration (weight systems per node or combination load + weight for example). However, make sure to carefully test and understand the chosen algorithm implications to avoid any catastrophic outage.
  - In the Open-Source world, see for example LVS + keepalived or HAProxy + keepalived.
- **Fault tolerance**: Fault Tolerance (FT = Fault Tolerance) should not be confused with HA; It is **stricter version of HA where availability is 100% and no data can be lost** (Wikipedia: "Fault tolerance is the property that enables a system to continue operating properly in the event of the failure of (or one or more faults within) some of its infrastructure components"). Historically, it meant a full hardware redundancy. In a micro-services world, it can also be achieved at a software level with active-active clusters. Moreover, a true fault-tolerance system should avoid significant performance degradation seen by the end-users. For example, a RAID 1 drive provides transparent fault tolerance: in case of failure, the process writes or reads without error after the automatic failover to the healthy disk. A Kubernetes cluster can achieve fault tolerance as well by starting new PODs. Or a clustered in-memory distributed cache can avoid losing any HTTP session. To allow fault tolerance of a cluster, it is essential to have an active/active cluster with strong coupling in which the **context data is replicated at all times**. Another (much better) solution is to simply avoid context data (by keeping session data in the browser via a JavaScript client for example) or to store it in database (SQL/NoSQL) or in distributed ans synchronously replicated cache (at a cost on performances). To get fully transparent fault tolerance, it is also necessary to use a **load balancer able to make retries by itself**. Do not take lightly a FT requirement because in general these solutions:
  - Makes the **architecture not only more expensive but also more complex** and therefore can make it less robust and more expensive to build, test, operate. Only mission or life-critical softwares usually need it.
  - **Can degrade performance**: Availability and performance solutions are generally linked (for example, a cluster of stateless machines will divide the load by the number of nodes and at the same time, the availability increases), but sometimes, availability and performance can be antagonistic: in the case of a stateful architecture, typically managing HTTP sessions with a distributed cache (like Infinispan replicated in synchronous mode or REDIS with persistence on the master), any transactional update of the session adds an additional cost linked to updating and replicating caches. If one of the nodes crashes, the user keeps his session at the next request and does not have to reconnect, but the cost is high.
  - **Can even degrade the global availability** because all nodes are strongly coupled and synchronized. A software update for example can force the shutdown of the entire cluster.
- **High Availability (HA)**: A system is generally considered highly available (HA) starting at 99.9% availability (~8h45 of downtime/year). An HA system typically relies on:
  - **Redundancy mechanisms** (e.g., clustering, load balancing, replication).
  - **Failover** devices to automatically switch in case of failure. Fault Tolerance (FT) always includes High Availability (HA), but HA does not necessarily guarantee FT. .Some Availability Solutions

### Deployment in production `[detail_level::detailed]`
- Provide here the deployment model in the target environment on the various middleware and physical nodes (servers). Represent network equipment (firewalls, appliances, routers, etc.) only if they help understanding. Naturally, it will be preferably documented with a UML2 deployment diagram or a C4 deployment diagram. For clusters, give the instantiation factor of each node. Comment out if necessary the affinity constraints (two infrastructure components must run on the same node or the same middleware) or anti-affinity (if two infrastructure components must not run on the same node or in the same middleware). Example: Database and application tiers should be deployed on separate instances to avoid CPU contention and maintain resource isolation. Clearly identify the hardware dedicated to the application.

### Infrastructure components `[detail_level::detailed]`
- List operating systems, databases, message-oriented middleware (MOM), application servers, etc. here. Only specify the exact patch/minor version (`y` or `z` in `x.y.z`) when this level of detail is operationally relevant.

### Matrix of network flows `[detail_level::in-depth]`
- List all technical flows used by the application here, including listening ports. Also detail operational flows (such as JMX or SNMP protocols). In some organizations, this matrix may be too detailed for architecture documentation and is maintained separately by integrators or operations teams. Application flows between modules need not be referenced here, only flows between machines, as readers are typically looking for different information. Operations and integration teams require comprehensive flow details for firewall configuration and installation purposes. Network types should include useful network information to assess performance (throughput, latency) and security: LAN, VLAN, Internet, LS, WAN, etc.

### Environments `[project_size::medium, project_size::large, detail_level::detailed]`
- Give here an overall view of the environments used by the application. The most common environments are: development, testing, acceptance, pre-production/benchmarks, production, training. It is often useful to subdivide environments into "platforms" made up of a set of machines isolated from each other (although they may share common hardware resources). For example, a test environment can consist of lanes `UAT1` and `UAT2` allowing two testers to work in isolation.

### Ecodesign `[level::intermediate]`
- The objectives of eco-design are often aligned with **performance goals** (response times, latency, resource optimization) and **cost goals** (reducing energy consumption, streamlining infrastructure). When a solution impacts several of these dimensions, referencing it briefly may suffice. However, some practices are **specifically tied to eco-design** and should be considered right from the architecture phase.

#### Energy Optimization & Infrastructure

#### Overall energy impact
- To evaluate and improve the energy footprint of your software stack, organizations like the **Green Software Foundation** provide assessment models and frameworks.

### Load regulation `[level::advanced, detail_level::detailed]`

#### Circuit breakers `[level::advanced, detail_level::in-depth]`
- In some cases, extreme and unpredictable peaks are possible (flash crowd). If this risk is identified, provide a fuse system with offset of all or part of the load on a static website with an error message for example. This measure can also be used in the event of a DDOS-type attack because it allows already connected users to finish their transactions properly.

#### Quality of Service `[level::advanced, detail_level::in-depth]`
- It is also useful to plan for dynamic regulation mechanisms, for example:
  - **Throttling**: regulation of request throughput (e.g., if a client exceeds **1,000 calls per minute**, its requests are queued or artificially slowed down).
  - **Rate Limiting**: strict limitation of the number of calls a client can make to an endpoint (e.g., each client is limited to **100 calls per minute on endpoint E**. Any excess request returns a **429 Too Many Requests** error).
  - **Token-based systems** (for intranets where machines are under full control): each client is assigned a token quota that limits its calls. This system allows **differentiated priorities** by allocating more tokens to certain strategic clients.

### Timeout Management `[level::advanced, detail_level::in-depth]`
- All distributed calls (e.g., HTTP(S) calls to APIs, access to object storage, database queries) must be **strictly bounded in both connection time and execution time**. Without appropriate timeouts, resource contention may arise, leading to **critical blocking situations and resource saturation** when systems slow down. **Key principles:**
  - **Define progressive timeouts** along the call chain.
  - E.g., **10 s on the reverse proxy**, **8 s on the REST API**, **5 s on the database**.
  - Goal: prevent an infrastructure service from continuing to process a request after the calling module has already given up.
  - **Avoid identical timeout values everywhere**, which could cause synchronized expirations and unwanted cascading effects.
  - **Use intelligent retries with exponential backoff** (progressively increasing the delay between retries).
  - **Add jitter** to the exponential backoff to avoid load spikes when multiple requests expire simultaneously. **Jitter:**
  - If multiple clients fail at the same time and apply retries with a **fixed delay**, they may overload the system.
  - Jitter consists in **adding random variability** to the exponential backoff delay to smooth out traffic bursts.
  - Example:
  - **Without jitter**: All clients retry after **1s, then 2s, then 4s…** → Risk of congestion.
  - **With jitter**: Retries are spread over **1.1s, 1.8s, 3.6s, 4.2s…** → Load is better distributed.

### Operations `[operations]`
- List here the main operating principles of the solution. The details (saved filesystems, production plan, processing planning ...) will be recorded in separate documents (or better, coded as IaC resources). If this application remains in the organization's standard, simply refer to any common document.

#### Startup/Shutdown Order `[level::intermediate, detail_level::detailed]`
- Specify here the startup order of machines and modules, as well as the shutdown order. Depending on the context, you may also include external modules. In general, startup follows the **reverse order of the dependency chain**, while shutdown follows the **direct order of component dependencies**. Be sure to specify any constraints in case of partial startup (e.g., does the application server’s connection pool retry connecting to the database if it is not yet available? How many times? At what frequency?).

#### Scheduled Operations and Monitoring `[level::intermediate, detail_level::detailed, monitoring]`
- Describe scheduled operations principles and how they are monitored, including when relevant:
  - Jobs and their potential interdependencies (execution order, constraints, frequency).
  - Internal processes (cleanup tasks, maintenance) that serve only technical roles (purges, index rebuilds, deletion of temporary data, etc.).
  - The scheduler used to orchestrate jobs and consolidate the production plan (examples: VTOM, JobScheduler, Dollar Universe, Control-M, etc.).
  - Application-specific characteristics:
  - Degree of job parallelism;
  - Mandatory time windows;
  - Retries in case of errors;
  - Execution reports (content and format). It is also crucial to define monitoring and alerting mechanisms to detect failures in critical jobs.

#### Maintenance Mode `[level::intermediate, detail_level::in-depth]`
- Detail the mechanisms and procedures that allow the application to be explicitly taken offline for users.

#### Backups and Restores `[detail_level::detailed]`

##### Scope
- What is the scope of the backup?
  - System images/snapshots for full server or VM system restore?
  - File systems or directories?
  - Databases in dump format?
  - Logs? Traces?

##### Backup Strategy
- Provide the general backup policy. It must meet **RPO requirements**. Likewise, restore mechanisms must align with **availability requirements**.
  - What types of backups are performed? Hot? Read-only? Cold (requiring service downtime)?
  - What is the frequency of each type of backup? (do not over-detail here, this belongs in the operations handbook).
  - What is the backup strategy?
    - full? incremental? differential? (consider availability: restoring from an incremental backup is slower than differential, which is slower than full).
    - what rotation? (are backup media periodically overwritten)?
  - How is backup reporting handled? Email? Where are the logs stored? Are they easily accessible? Do they contain sensitive data?

##### Tooling
- List the tools used for different backup types. What tools are implemented?
  - Simple cron + rsync + tar?
  - Open Source file-oriented tool such as **backup-manager**?
  - Deduplicated backup tools such as Restic, Borg, Kopia?
  - VM imaging-oriented tool such as Veeam or FSArchiver?
  - Cloud-oriented backup tools such as **Duplicity** or **Restic**?
  - Database-specific backup tool (e.g., MySQLDump, Barman)?

##### Backup Processing
- List the operations performed on backups:
  - Are backups deduplicated? (identical files or data blocks are stored only once across the whole backup set). Most modern solutions use this. Examples: Open Source tools like Restic or proprietary ones like Veeam rely heavily on this principle (similar to Git repositories) to drastically reduce backup size and eliminate the need for full backups.
  - Are backups encrypted? If yes, is it whole-partition encryption, per-file encryption, or both? Should directory and file names also be encrypted? Specify the algorithm used and how keys will be managed (digital vaults, recovery codes, etc.).
  - Are backups compressed? If yes, with which algorithm (lzw, deflate, lzma, etc.)? At which compression level? Be careful to balance storage savings against compression/decompression overhead.
  - Should **Point In Time Recovery (PITR)** be supported, to allow restoration to an exact, configurable moment?
  - Are backups protected against write/delete operations (anti-ransomware)? If yes, is this temporary or permanent?
  - Other features? (integrity tests, automatic cleanup of archives, archive file refactoring, etc.).

##### Storage Modalities
- Specify the storage media used for backups and their location.
  - Is the medium offline, nearline (accessible via tape library), or online (always accessible)? Note: online and nearline backups are vulnerable to human error and ransomware.
  - Which storage technology is used? (magnetic tapes such as LTO or DLT? external disks? RDX cartridges? cloud storage such as Amazon S3? optical media? NAS?).
  - Where are backups physically stored? (ideally offline and as far away from the system as possible, while still allowing restoration within the RTO window).
  - What is the legislation of the country hosting backups? Is it compatible with legal requirements such as GDPR? (consider the US Cloud Act, etc.).
  - Who has physical access to backups and logs? To the encryption keys? (consider confidentiality requirements).
  - Are we aware of external dependencies that could slow us down (e.g., bank vault accessible only during business hours)?
  - Strongly recommended:
    - use a medium different from the source data;
    - maintain at least two separate backup media if the data is vital to the organization;
    - ensure backups cannot be modified by the machine being backed up (e.g., backups stored on a NAS can be deleted along with the original data).
  - Apply the "3-2-1 rule" for critical data: at least 2 copies in addition to production data, stored on 2 different types of media, with at least 1 offline copy in a secure offsite location (e.g., bank vault).

##### Restore
- Always remember that what we really want are **restores**, not backups. It is crucial to ensure that the restore process will work:
  - Are backups correct and complete?
  - What restore tests are planned? At what frequency [at least once per year is a minimum]?
  - How long will a restore take? Is this compatible with the RTO?
  - How are errors handled? (retries, timeouts, logs, alerts, etc.).
  - Do we have sufficient hardware resources for restore within the RTO window (intermediate storage, CPU/memory for decompression/decryption, etc.)?
  - How are restore tests performed?
    - Which test datasets?
    - What reporting/follow-up format?
    - Where are logs stored?
    - Is there a risk of accidentally overwriting production data during restore tests? (if yes, test on another environment).
    - Are restored data properly encrypted (restore tests must not risk massive confidentiality breaches)?
    - …

#### Logging `[level::intermediate, detail_level::detailed]`
- Without being exhaustive on log files (to be detailed in the operations handbook), present the general policy for log production and management (log content itself is addressed in the development view):
  - **Rotation and retention policies**:
    - How are log files managed? Application-level rotation (`DailyRollingFileAppender` in log4j, logback) or system-level (`logrotate`)?
    - What retention policy is applied? (e.g., retention period, maximum file size before deletion).
    - Where are old logs stored? (local files, object storage, centralized archive...).
  - **Centralization and analysis of logs**:
    - Is a log collection and analysis solution in place? (ELK, Loki, Splunk, etc.).
    - Is real-time log monitoring provided? (alerts on critical errors).
  - **Logging levels**:
    - What log level is configured per module (`WARN`, `INFO`, `DEBUG`, etc.)?
    - Should the application allow dynamic modification of log levels in production (e.g., via JMX, API)?
  - **Security and compliance**:
    - Are logs protected against injections (**Log Injection**)?
    - Is anonymization or pseudonymization of sensitive data planned? (GDPR / privacy requirements).
    - Ensure protection against unauthorized modification or deletion of logs.
    - If logs are available for consultation, what authentication and authorization mechanisms are enforced?

### Monitoring `[level::intermediate, detail_level::detailed, monitoring]`
- Monitoring is a **pillar of availability**, as it drastically reduces the **MTTD (Mean Time to Detect)** for failures. Effective monitoring should not be **purely reactive** (alerting only when a failure occurs), but also **proactive** by detecting weak signals before an outage happens.
  - **Metrics**: raw data collected (CPU %, filesystem size, number of requests, etc.), from system, middleware, or application probes.
  - **Indicators**: combinations of multiple metrics with defined alert thresholds (e.g., *"critical alert if server `s1` CPU usage exceeds 95% for more than 5 minutes"*).

#### Technical Monitoring `[level::intermediate, detail_level::in-depth, monitoring]`
- List the **technical metrics (infrastructure & middleware)** to be monitored:
  - **System**:
  - CPU usage (%), load average, memory usage (%), swap in/out.
  - Disk and filesystem usage (% used, free inodes).
  - Network usage (latency, throughput, error rate).
  - Number of active processes and threads.
  - IO wait (CPU time blocked waiting for IO).
  - **Middleware & databases**:
  - % of **HEAP used** in a JVM.
  - Number of **active threads** in a JVM.
  - Usage of a **thread pool** or **JDBC connection pool**.
  - Average database response time, number of pending queries, cache hit ratio.
  - Garbage collection (GC) statistics.

#### Application & Business Monitoring `[level::intermediate, detail_level::in-depth, monitoring]`
- List here the **application** or **business-level metrics**:
  - **Application metrics**:
  - Number of HTTP requests received per service.
  - Average response time per REST API.
  - Service error rate (5xx).
  - **Business metrics**:
  - Number of contracts processed per hour.
  - Volume of orders approved/rejected.
  - Number of packages pending shipment. **Business Activity Monitoring (BAM)**: A BAM layer can be implemented to generate **business process-oriented indicators** based on these metrics.

#### Monitoring & Observability Tools `[level::intermediate, detail_level::in-depth, monitoring]`
- A monitoring platform collects, stores, and analyzes metrics in real time. The most common Open Source tools are:
  - **Metric collection**:
  - **Prometheus** (HTTP scraping).
  - **Telegraf** (agent collecting CPU, memory, network, etc.).
  - **SNMP, JMX** protocols for system and JVM monitoring.
  - **Time-series metric storage**:
  - **InfluxDB, Prometheus TSDB, TimescaleDB**.
  - **Elasticsearch** (if log collection is also needed).
  - **Visualization & alerting**:
  - **Grafana** (interactive dashboards), **Kibana**.
  - **Zabbix, Netdata, Nagios** (classic system monitoring). Indicators are displayed in **dynamic dashboards**, and **alert thresholds** are defined to notify operations teams.

#### Alerting & Notifications `[level::intermediate, detail_level::detailed, monitoring]`
- Define **alert trigger conditions** and **notification channels**:
  - **Alert types**:
  - **Critical (urgent)** → server down, disk saturation, application crash.
  - **Warning** → upward trend, weak signals (e.g., memory usage > 80%).
  - **Notification channels**:
  - **Email alerts** (non-urgent).
  - **Slack, Mattermost, Microsoft Teams** (operational monitoring).
  - **SMS or PagerDuty** (urgent, 24/7 on-call).
  - **Triggering and ending rules**:
  - Require repetition over a period before alerting (to avoid noise).
  - Alert resolution conditions.

#### Black-box Monitoring `[level::intermediate, detail_level::detailed, monitoring]`
- It is highly recommended (and inexpensive) to implement black-box monitoring tests (automated end-to-end scenarios). The goal is to test the system as a whole, from the end-user perspective, as opposed to white-box monitoring that targets specific modules. In general, these tests are simple (e.g., scheduled HTTP requests using `curl`). They should be run from one or more remote sites to detect network outages. They rarely need to perform update operations. If they do, it must be possible to identify this test data across all modules so it does not pollute business data or analytics.

#### Performance Monitoring `[level::advanced, detail_level::detailed, monitoring]`
- Tracking application performance in production is essential to:
  - Provide factual feedback on **in vivo** performance, helping improve decision-making for hardware platform resizing.
  - Provides precious insights about production issues.
  - Perform statistical analysis on module usage to guide decision-making (e.g., decommissioning an underused application). Three main categories of solutions exist:
  - **APM (Application Performance Monitoring)**: These tools inject lightweight probes into the application, collect data, and present it via dashboards. Some even reconstruct full call chains using correlation IDs injected in distributed requests. **Examples**: Oracle Enterprise Manager, Oracle Mission Control, Radware, BMC APM, Dynatrace, Glowroot (Open Source), etc. ⚠ Ensure the overhead of these solutions is negligible or controlled.
  - **Custom log-based metrology**: A simple solution for modest needs, extracting performance metrics from application logs.
  - **External query sites**: These services perform periodic requests to the application and generate dashboards. They account for WAN transit times, which internal tools cannot. Best used as a complement to black-box monitoring.

### Decommissioning `[level::intermediate]`
- This section should be completed when the application reaches end-of-life and must be removed or replaced. It should cover:
  - **Data** to be archived or, conversely, destroyed with a **high level of assurance**.
  - **Physical equipment** to be removed, recycled, or securely destroyed.
  - **Uninstallation procedures** on both server and/or client side (it is common for obsolete modules to remain running, creating **performance and security risks**).
  - **Security constraints** associated with decommissioning (this is a **critical step** often overlooked; for example, hard drives containing **sensitive data** may be recovered after simple hardware donations).
