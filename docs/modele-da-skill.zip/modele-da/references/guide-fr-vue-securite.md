# Vue sécurité
- Faire régulièrement des revues complètes de la vue (au moins une fois par an tant que le projet est actif) et mettre à jour la date plus haut.
- Indiquer le statut de la vue, par exemple 'DRAFT', 'FINALISÉ',...

## Introduction `[contexte]`
- La disponibilité est traitée dans la vue infrastructure.

### Documentation de Référence `[contexte, references]`
- Mentionner ici les documents d'architecture de référence (mutualisés). Ce document ne doit pas reprendre leur contenu sous peine de devenir rapidement obsolète et non maintenable.

## Non statué `[contexte, incertitude]`

### Points nécessitant une étude complémentaire

### Hypothèses
- Donner ici les éventuelles hypothèses structurantes

## Contraintes `[niveau_detail::général, contrainte]`
- Lister ici les **contraintes de sécurité** applicables à l'architecture, incluant notamment :
  - **Isolation des modules** au sein de zones réseaux sécurisées (_DMZ, pare-feux, reverse proxy, segmentation réseau, etc._).
  - **Normes et politiques applicables** (_ex. : politiques de mots de passe, exigences de chiffrement, MFA, conformité aux standards de sécurité_).
  - **Contraintes légales et réglementaires** (_ex. : conformité RGPD, exigences sectorielles spécifiques_).
  - **Restrictions d'accès** entre les différentes zones et systèmes.

## Exigences `[niveau_detail::général, exigence]`
- Présenter ici les **exigences**, **pas les dispositifs y répondant**. Ceux-ci seront détaillés au chapitre 3. Pour les projets particulièrement sensibles, prévoir un **dossier d’analyse de risque**. Pour cela, utiliser par exemple la méthode [EBIOS Risk Manager](https://www.ssi.gouv.fr/guide/la-methode-ebios-risk-manager-le-guide/) (_Expression des Besoins et Identification des Objectifs de Sécurité_).

### Exigences d'intégrité
- L’intégrité concerne la **justesse, la durabilité et le niveau de confiance** des données de l’application. Garantir l’intégrité des données signifie s’assurer qu’elles **ne peuvent être altérées ou supprimées** de manière involontaire (_ex. : crash disque, corruption logicielle, bug applicatif_) ou volontaire (_ex. : attaque "man-in-the-middle", élévation de privilèges, sabotage interne_). ⚠ **Ne pas multiplier inutilement les classes de données**. Une unique classification pour toute l’application est souvent suffisante.

### Exigences de confidentialité
- La confidentialité est la garantie que l’information **n’est accessible qu’aux personnes autorisées** (définition ISO 27018). **Bonnes pratiques** :
  - Ne pas multiplier inutilement les classes de données. Une seule classification peut suffire pour l’ensemble de l’application.
  - S’assurer que les niveaux de confidentialité sont **cohérents avec les exigences légales et contractuelles**.

### Exigences d'identification
- L'identification permet d'**attribuer un identifiant unique** à chaque utilisateur, afin de le différencier des autres. **Attention :** l'identification **ne garantit pas** que l'utilisateur est bien celui qu'il prétend être. C'est le rôle de l'authentification, traitée dans la section suivante. **Bonnes pratiques :**
  - privilégier des identifiants stables et uniques (adresse électronique, numéro de client, UUID) ;
  - éviter les identifiants réattribuables, par exemple un entier incrémental risquant d'être réutilisé après suppression d'un compte ;
  - s'assurer que l'identifiant est cohérent dans tous les systèmes où il est utilisé.
- **Le niveau de garantie se subit plus qu'il ne se choisit.** Il dépend du fournisseur d'identité retenu, et une application ne peut pas l'élever elle-même : si la source d'identité délivre du faible, aucune mesure applicative ne produira du substantiel. Vérifier donc, dès la conception, que le niveau atteignable correspond au niveau exigé. En France, l'ANSSI établit le référentiel national des exigences de sécurité applicables à chaque niveau et certifie les moyens d'identification électronique aux niveaux substantiel et élevé. Le niveau faible ne fait pas l'objet d'une certification.

### Exigences d’authentification
- L’authentification vérifie qu’un utilisateur est bien celui qu’il prétend être, en validant son identité à l’aide d’un ou plusieurs facteurs de preuve. ⚠ **À ne pas confondre avec l’identification**, qui ne fait que distinguer un utilisateur d’un autre sans valider son identité. **Cas particuliers :**
  - Les **comptes techniques** (ex. : batchs, applications, API) nécessitent également une authentification. Les exigences les concernant sont traitées dans un tableau dédié ci-dessous ; les dispositifs correspondants relèvent de la section « Comptes de service » du chapitre Mesures de sécurité.
  - Les **comptes à privilèges** (ex. : `root` sur les serveurs, compte administrateur applicatif...). Ils peuvent être humains ou techniques, mais disposent de droits permettant de lire, modifier ou supprimer de nombreuses données, ou de réaliser des opérations irréversibles (_blast radius_ important).
  - L’**enrôlement initial** et, lorsqu’elle est nécessaire, la **vérification d’identité** permettant de rattacher un compte à une personne constituent une étape distincte de l’authentification ultérieure. Cette étape peut nécessiter des contrôles plus stricts que ceux utilisés lors des connexions suivantes ou selon des facteurs d'authentification différents (comme la demande d'information métier, voir plus bas).
  - Une **authentification fédérée** permet de déléguer l’authentification à un fournisseur d’identité. Les exigences correspondantes sont traitées dans les sections « Exigences de fédération d’identité » et « Exigences de SSO et SLO ». La présente section reste néanmoins à renseigner : elle définit le **niveau d’authentification exigé**, que celui-ci soit obtenu localement ou délégué à un fournisseur d’identité.
- La **biométrie** est rarement transmise au service distant comme preuve d’authentification. Dans les usages courants, elle sert à effectuer localement une _vérification utilisateur_ et à déverrouiller un authentificateur cryptographique protégé par le terminal. La résistance au phishing et une grande partie de la robustesse de l’authentification proviennent alors de l’authentificateur cryptographique déverrouillé, et non du caractère biométrique lui-même.
- Cette échelle reprend la distinction posée par le guide de l'ANSSI relatif à l'authentification multifacteur et aux mots de passe : *une MFA n'est pas nécessairement une authentification forte*.
- Il s'agit de fonctionnalités avancées et complexes à ne considérer que dans les situations les plus sensibles.
- .Exemple

### Exigences de fédération d’identité `[niveau::avancé, niveau::avancé, niveau_detail::détaillé]`
- La fédération d’identité permet à un utilisateur de **réutiliser son identité** (credentials) gérée par un **Identity Provider (IdP)** pour s’authentifier sur plusieurs systèmes indépendants. Contrairement au **SSO (Single Sign-On)**, qui assure une connexion automatique sans nouvelle saisie des identifiants, la fédération **ne dispense pas** de l’authentification mais centralise la gestion des identités. **Exemples courants :**
  - **France Connect** → Basé sur OpenID Connect, permet aux citoyens de se connecter aux services administratifs (DGFiP, CNAM…) avec un compte unique.
  - **"Se connecter avec [Google | Facebook | GitHub]”** → Implémenté via **OpenID Connect** ou **OAuth2**, permettant d’utiliser un compte tiers pour l’authentification sur une autre plateforme. **Avantages de la fédération d’identité :**
  - **Simplifie la gestion des comptes** → Moins d’identifiants à mémoriser pour l’utilisateur.
  - **Réduit les coûts de maintenance** → Moins de réinitialisations de mot de passe et de gestion des utilisateurs.
  - **Améliore la sécurité** → Centralisation de l’authentification auprès d’un IdP de confiance, possibilité d’intégrer une authentification multi-facteurs (MFA).

### Exigences de SSO et SLO `[niveau::avancé, niveau::avancé]`
- Le **Single Sign-On (SSO)** permet à un utilisateur de s’authentifier une seule fois et d’accéder à plusieurs applications sans ressaisir ses identifiants. Le **Single Log-Out (SLO)** assure qu’une déconnexion depuis une application entraîne automatiquement la déconnexion de toutes les autres applications du même domaine de confiance. **Points d’attention :**
  - **Le SSO peut être complexe** à mettre en œuvre, surtout si l’infrastructure IdP (Identity Provider) n’est pas encore en place.
  - **Les applications doivent être compatibles** avec le protocole choisi (SAML, OIDC, Kerberos…).
  - **Le besoin métier doit être justifié** → Une application rarement utilisée ne nécessite pas forcément de SSO.
  - **Risque sécurité** → Une **authentification faible** sur une application SSO met en péril tout le SI (ex. : un mot de passe faible compromet toutes les applications accessibles via SSO). **Bonnes pratiques :**
  - Définir des **périmètres de confiance** limités (ex. : SSO pour les applications internes uniquement).
  - Utiliser une **authentification forte** pour réduire les risques d’usurpation.
  - Gérer correctement les **sessions et expirations de jetons**.
  - Envisager **une authentification centralisée simple (LDAP, CAS)** si le SSO n’est pas justifié.

### Exigences de non-répudiation et de valeur probante `[niveau::avancé]`
- Le critère discriminant est **l'identité de l'adversaire de la trace**. Si l'adversaire est un attaquant externe ou un incident, des journaux suffisent : on cherche à comprendre et à investiguer, et le sujet relève des  de traçabilité. Si l'adversaire est *l'une des parties, y compris l'organisation qui exploite le système*, les journaux ne suffisent plus : ils sont produits par celui-là même à qui on voudrait les opposer. C'est la raison pour laquelle la non-répudiation repose sur de la cryptographie asymétrique et non sur de la journalisation : la signature déplace la production de la preuve chez le signataire. Poser la question « qui contestera, et à qui devrai-je le démontrer ? » suffit en général à trancher si un besoin relève de cette section ou de la traçabilité.
- La signature numérique est reconnue par la loi n° 2000-230 du 13 mars 2000 et par le règlement eIDAS (UE 910/2014), qui distingue trois niveaux : Simple:: Vérifie l'identité de l'émetteur. Avancée (AdES):: Liée de manière unique au signataire et protégée contre toute modification ultérieure. Qualifiée (QES):: Conforme aux exigences les plus strictes, avec certificat qualifié et dispositif de création de signature qualifié. Seule à bénéficier de la présomption de fiabilité et de l'équivalence avec la signature manuscrite.
- Le niveau exigé est **rarement déduit de l'analyse de risque**. Il est le plus souvent imposé de l'extérieur : délais de prescription applicables, obligations sectorielles, niveau eIDAS requis par un texte. Recueillir ces contraintes auprès du service juridique avant de coter ce critère. .Exemple
- .Exemple

#### Intégrité des éléments de preuve dans la durée

### Exigences d'anonymat et de respect de la vie privée
- Lister les contraintes d’anonymat et de vie privée légale (exigée par le RGPD). Voir [3].

### Exigences sur les autorisations `[niveau::intermédiaire]`
- Une autorisation ("droit d'accès" ou "habilitation") permet de **contrôler l’accès** à une fonction applicative spécifique (également appelée **droit**, **privilège** ou **permission**) pour un utilisateur ou un groupe d’utilisateurs. **Exemples de fonctions applicatives :**
  - "Effectuer un virement interbancaire"
  - "Consulter l’historique de son compte"
  - "Supprimer un utilisateur" ⚠ Il est recommandé de **ne pas multiplier excessivement** les fonctions et les rôles afin d’éviter une explosion combinatoire et des coûts de gestion élevés. **Bonnes pratiques pour simplifier la gestion des autorisations :**
  - **Regrouper** les utilisateurs dans des **groupes** (ex: `G_chef_service`).
  - **Associer** une liste de **fonctions** à un **rôle** (ex: `R_Administrateur`, `R_banquier_niv1`, `R_chef_service`).
  - **Attribuer** les rôles aux **utilisateurs ou groupes** pour une meilleure factorisation. **Modèle classique de gestion des autorisations de type RBAC :** image::diagrammes/roles.svg[Gestion classique des rôles] **Pseudo-utilisateurs et rôles prédéfinis** : Penser à spécifier les utilisateurs génériques tels que :
  - **`@anonyme`** : utilisateurs non connectés.
  - **`@connecte`** : utilisateurs authentifiés. **Délégation d’autorisation (OAuth2, etc.) :** Si l’application **délègue ou consomme** des autorisations via un **système externe (OAuth2, OpenID Connect, etc.)**, il est nécessaire de préciser :
  - **L’application est-elle fournisseur ou consommatrice d’autorisations ?**
  - **Quels types d’autorisations sont concernées ?**
- 
- 

### Exigences de traçabilité et d'auditabilité `[niveau::intermédiaire]`
- Lister ici les besoins en **traçabilité et auditabilité** pour détecter et analyser par exemple :
  - **Un usage abusif** des applications Back Office par des employés.
  - **Des intrusions informatiques** ou tentatives de compromission.
  - **Des modifications de données** nécessitant un suivi détaillé. ⚠ **Les traces sont des données nominatives et sensibles**. Elles doivent être protégées avec des **mécanismes de confidentialité** appropriés pour éviter tout abus. **Différenciation des types de traces :**
  - **Traces métier** : elles reflètent des actions de gestion complètes. **Exemple** : `L’agent X a consulté le dossier de Mme Y le 2024-02-23 à 10:30`.
  - **Journaux applicatifs** : ils fournissent un niveau technique d’information. **Exemple** : `[INFO] 2024-02-23 11:14 [Agent X] Appel du service "consulterDossier"`. **Bonnes pratiques :**
  - Pour les **données sensibles**, prévoir **une traçabilité à deux niveaux** (tracer aussi l’accès aux traces) pour limiter les abus hiérarchiques.
  - La **traçabilité des référentiels** (ex: base des personnes) doit inclure **une historisation complète**.
  - Conserver **chaque modification** avec sa date de modification et sa date d’effet.
  - Ne pas oublier les **purges** de ces traces.

## Mesures de sécurité `[solution]`

### Intégrité
- Lister ici les mesures assurant le niveau d'intégrité demandé **Exemples de dispositifs associés selon le niveau d’intégrité requis :**
  - **Détectable** → Logs d’accès, contrôles d’intégrité par empreintes numériques (hashes), détection a posteriori des altérations.
  - **Maîtrisé** → Rétention des versions, auditabilité des modifications, mécanismes de correction automatique ou de recalcul en cas d’erreur détectée.
  - **Intègre** → Chiffrement, signatures numériques, réplication synchrone, stockage immuable (WORM), horodatage et preuves d’intégrité fortes.

### Confidentialité
- Lister ici les mesures assurant le niveau de confidentialité demandé.

### Identification
- Décrire ici le mode d’identification des utilisateurs et des systèmes (batchs, API, services externes). Préciser les attributs d’identification et les mécanismes garantissant l’unicité et la persistance des identifiants.

### Authentification
- Décrire ici les mécanismes d’authentification mis en place, y compris :
  - Le mode de stockage et de vérification des secrets d'authentification.
  - Les éventuels facteurs d’authentification supplémentaires.
  - La gestion du cycle de vie des identifiants (création, mise à jour, suppression).

### Fédération d’identité `[niveau::avancé, niveau_detail::détaillé]`
- Les solutions les plus courantes sont actuellement :
  - **OpenID Connect (OIDC)** : protocole moderne basé sur OAuth2, adapté aux applications Web et mobiles.
  - **SAML** : utilisé principalement pour le SSO en entreprise (ADFS, Shibboleth, Okta…).
  - **OAuth 2.0** : uniquement pour **l’autorisation**, pas l’authentification (pseudo-authentification possible via un IdP complémentaire). Pour les applications Web, préciser les **contraintes navigateur** (gestion des cookies, SameSite policy…).

### SSO et SLO `[niveau::avancé, niveau::avancé]`
- Décrire ici la technologie choisie et son intégration dans l’architecture. Quelques solutions courantes :
  - **CAS** (Central Authentication Service)
  - **Keycloak**
  - **OpenAM**
  - **LemonLDAP::NG** Préciser les contraintes spécifiques aux applications Web, notamment la gestion des **cookies**, du **token session**, et les implications de **SameSite / CORS**.

### Comptes de service `[niveau_detail::détaillé]`
- Les **comptes de service** sont utilisés pour authentifier une application ou un job lorsqu’ils accèdent à un service d’infrastructure (base de données, API…). **Bonnes pratiques :**
  - **Stockage sécurisé** des credentials (éviter le stockage en clair dans la configuration).
  - **Rotation automatique** des secrets si possible (HashiCorp Vault, AWS Secrets Manager…).
  - **Permissions minimales** (Principe du Moindre Privilège).

### Non-répudiation et horodatage `[niveau::avancé]`
- L'**horodatage cryptographique** ne répond pas à un besoin isolé mais est souvent utilisé en **complément d'une signature électronique** pour garantir la non-répudiation. L’horodatage permet de prévenir toute **altération de date** (**antidatage ou postdatage**). Il repose sur des **jetons d’horodatage qualifiés** (**RFC 3161, eIDAS**), délivrés par un **Prestataire de Service de Confiance (TSA – Timestamping Authority)**.

### Anonymat et vie privée

### Autorisations `[niveau::intermédiaire]`

### Traçabilité et auditabilité `[niveau::intermédiaire]`

### Lutte contre les cybermenaces `[niveau::intermédiaire]`
- Les cybermenaces incluent : malwares, phishing, attaques DOS/DDOS, exploitation de vulnérabilités (connues ou zero-day), ingénierie sociale, escroqueries en ligne, fuites de données sensibles, etc. Le cadre de réponse aux menaces peut être aligné sur le **NIST Cybersecurity Framework**, qui définit six fonctions clés : 1. **Gouverner** : Définir la gouvernance de la cybersécurité, les rôles et responsabilités, la stratégie, la gestion des risques, la conformité et la prise de décision au niveau organisationnel. 2. **Identifier** : Comprendre et prioriser les risques. 3. **Protéger** : Mettre en place des mécanismes de défense. 4. **Détecter** : Identifier une attaque en cours. 5. **Réagir** : Contenir et neutraliser la menace. 6. **Récupérer** : Restaurer les services après une attaque.

#### Solutions de prévention
- Ces solutions permettent d’**anticiper** les menaces avant qu'elles ne surviennent.
  - **Formations et sensibilisations** des utilisateurs et des équipes IT.
  - S’assurer que les développeurs connaissent et appliquent les mesures de mitigation issues du **[OWASP Top 10](https://owasp.org/www-project-top-ten/)**, les bonnes pratiques de sécurité applicative (ex. : protection contre les injections, l’authentification défaillante, les conceptions non sécurisées et autres risques critiques).
  - **Systèmes de prévention d'intrusion (IPS)** pour bloquer les acteurs jugés malicieux.
  - **Revues d'autorisations régulières** pour minimiser l'exposition.
  - **Durcissement des règles de sécurité** :
  - Authentification à facteurs multiples (MFA).
  - Rotation obligatoire des mots de passe.
  - Utilisation de **coffres-forts numériques** pour stocker les secrets.
  - **Audits réguliers** (tests d'intrusion, audit de code) par des experts internes ou externes.
  - **Solutions DLP (Data Loss Prevention)** pour surveiller et empêcher les fuites de données sensibles.
  - **Blocage des vecteurs d'attaque** (ex. désactivation des ports USB).
  - **Mises à jour automatiques des patches de sécurité**.

#### Solutions de détection
- Ces solutions permettent d’**identifier** les attaques en cours.

#### Solutions de correction
- Ces solutions permettent de **réagir** et **corriger** après la détection d’une menace.
  - **Solutions anti-malware** pour supprimer les logiciels malveillants.
  - **Plans de restauration des sauvegardes** pour reprendre l’activité rapidement (**MTTR** optimisé).
  - **Isolation des zones compromises** (micro-segmentation réseau, cloisonnement des applications).
  - **Gestion de parc logiciel** pour **bloquer** les logiciels non autorisés.
  - **Analyse forensique** pour comprendre les chemins d'attaque et identifier la source d’une compromission.
  - **Procédures de réponse à incident**, en se basant sur le standard **NIST SP 800-61**.

#### Solutions de prédiction `[niveau::avancé]`
- Ces solutions récentes reposent sur **l’analyse comportementale** et le **Machine Learning**.
  - **UEBA (User and Entity Behavior Analytics)** : Détection des comportements anormaux d’utilisateurs ou de systèmes.
  - **Simulations d'attaques complexes** pour tester la résilience du SI.
  - **Threat Intelligence** : Intégration de flux de renseignement sur les menaces en temps réel.

## Annexes `[annexe]`

### RACI & Gouvernance de la Sécurité `[niveau::intermédiaire, niveau_detail::détaillé]`
- Ce RACI permet de définir clairement les rôles et responsabilités des équipes en matière de **gestion de la sécurité informatique**. :r: R :a: A :c: C :i: I :na: N/A :et: &amp;
  - R : **Responsible** (exécute l'action).
  - A : **Accountable** (valide l'action et en est responsable devant l'organisation).
  - C : **Consulted** (doit être consulté pour expertise).
  - I : **Informed** (doit être informé après réalisation). Dans un bon RACI, il ne doit **jamais** y avoir plus d'un A pour chaque ligne.

### Auto-contrôles de sécurité `[niveau::intermédiaire, niveau_detail::détaillé]`

#### Auto-contrôle des vulnérabilités
- La gestion des vulnérabilités suit les standards **OWASP Top 10**, **MITRE ATT&CK** et **NIST 800-53**. Objectif : Vérifier que les mesures de **protection, détection et correction** sont bien appliquées pour réduire les risques d'attaques (ex: ransomware, attaques supply-chain, injections...).

#### Auto-contrôle RGPD `[juridique]`
- Le RGPD impose des exigences fortes sur les données personnelles des individus. Ces points sont basés sur les recommandations de la **CNIL** et de l'**EDPB**. A noter que le RGPD **ne concerne que les personnes physiques**, pas les entreprises.
