# Notice

The files in `assets/` and `references/` are derived from:

- **Modèle de dossier d'architecture**, by Bertrand Florat and contributors: https://github.com/bflorat/modele-da (commit `ed58107`)
- **Architecture document template**, by Bertrand Florat and contributors: https://github.com/bflorat/architecture-document-template (commit `27d88bb`)

Licensed under **CC BY-SA 4.0**: https://creativecommons.org/licenses/by-sa/4.0/

Changes: converted from AsciiDoc to Markdown, examples removed from the guidance files, section anchors and AsciiDoc attributes dropped. Provided as is, without warranty; the original author is not responsible for this adaptation.

Architecture documents produced with this skill do not have to carry this license, but upstream recommends linking to https://github.com/bflorat/modele-da.
