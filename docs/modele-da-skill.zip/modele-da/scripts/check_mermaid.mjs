// Parse-check every ```mermaid block of the given Markdown files (syntax only, no rendering).
// Setup once:  npm i --prefix ~/.cache/modele-da mermaid jsdom
// Run:         NODE_PATH=~/.cache/modele-da/node_modules node scripts/check_mermaid.mjs docs/architecture/*.md
import { createRequire } from 'module';
import path from 'path';
import fs from 'fs';
import { pathToFileURL } from 'url';
const req = createRequire(path.join(process.env.NODE_PATH || process.cwd(), 'x.js'));
const { JSDOM } = req('jsdom');
const dom = new JSDOM('<!doctype html><body></body>');
globalThis.window = dom.window; globalThis.document = dom.window.document;
const { default: mermaid } = await import(pathToFileURL(req.resolve('mermaid')).href);
mermaid.initialize({ startOnLoad: false });
let bad = 0;
for (const f of process.argv.slice(2)) {
  const md = fs.readFileSync(f, 'utf8');
  const blocks = [...md.matchAll(/```mermaid\n([\s\S]*?)```/g)].map(m => m[1]);
  for (const [i, b] of blocks.entries()) {
    try { const r = await mermaid.parse(b); console.log('OK ', f, i, r.diagramType); }
    catch (e) { bad++; console.log('ERR', f, i, String(e.message || e).split('\n').slice(0,3).join(' | ')); }
  }
}
process.exit(bad ? 1 : 0);
