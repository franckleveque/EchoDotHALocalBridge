#!/usr/bin/env python3
"""Regenerate the skill's Markdown assets from the upstream AsciiDoc templates.

Usage:
    git clone --depth 1 https://github.com/bflorat/modele-da.git /tmp/modele-da
    git clone --depth 1 https://github.com/bflorat/architecture-document-template.git /tmp/adt
    python3 scripts/build_assets.py /tmp/modele-da /tmp/adt

Produces:
    assets/fr/*.md, assets/en/*.md      blank skeletons (headings + empty tables)
    references/guide-fr-*.md, guide-en-*.md   per-section writing guidance (TIPs only,
                                              examples stripped) + size labels
Upstream content: (c) Bertrand Florat and contributors, CC BY-SA 4.0.
"""
import json
import re
import subprocess
import sys
from pathlib import Path

SKILL = Path(__file__).resolve().parent.parent

LANGS = {
    "fr": {
        "blank": "modele-vierge",
        "files": {
            "README.adoc": "README.md",
            "vue-applicative.adoc": "vue-applicative.md",
            "vue-developpement.adoc": "vue-developpement.md",
            "vue-dimensionnement.adoc": "vue-dimensionnement.md",
            "vue-infrastructure.adoc": "vue-infrastructure.md",
            "vue-securite.adoc": "vue-securite.md",
            "glossaire.adoc": "glossaire.md",
        },
        "see": "Voir aussi",
        "tip": "Conseil",
        "date": "AAAA-MM-JJ",
    },
    "en": {
        "blank": "blank-template",
        "files": {
            "README.adoc": "README.md",
            "view-application.adoc": "view-application.md",
            "view-development.adoc": "view-development.md",
            "view-sizing.adoc": "view-sizing.md",
            "view-infrastructure.adoc": "view-infrastructure.md",
            "view-security.adoc": "view-security.md",
            "glossary.adoc": "glossary.md",
        },
        "see": "See also",
        "tip": "Tip",
        "date": "YYYY-MM-DD",
    },
}

UUID = r"[0-9a-f-]{36}"


def inline(text, lang):
    cfg = LANGS[lang]
    files = cfg["files"]
    # xref:file.adoc#id[Title] / link:file.adoc[Title]
    def _x(m):
        target = files.get(m.group(2), m.group(2).replace(".adoc", ".md"))
        return f"[{m.group(3)}]({target})"
    text = re.sub(r"(xref|link):([\w.-]+\.adoc)(?:#[^\[]*)?\[([^\]]*)\]", _x, text)
    text = re.sub(r"<<" + UUID + r",([^>]*)>>", r"*\1*", text)
    text = re.sub(r"<<[^,>]+,([^>]*)>>", r"*\1*", text)
    text = re.sub(r"https?://\S+?\[([^\]]+)\]", lambda m: m.group(0), text)
    text = re.sub(r"(https?://[^\s\[]+)\[([^\]]+)\]", r"[\2](\1)", text)
    text = re.sub(r"\[small\]#([^#]*)#", r"\1", text)
    text = re.sub(r"pass:quotes\[\[\.\w+\]#([^#]*)#\]", r"\1", text)
    parts = text.split("`")  # never touch code spans (formulas use *)
    for k in range(0, len(parts), 2):
        parts[k] = re.sub(r"(?<![\w*])\*([^*\s][^*\n]*?)\*(?![\w*])", r"**\1**", parts[k])
    text = "`".join(parts)
    text = re.sub(r"#<([^#]*)>#", r"<\1>", text)
    text = re.sub(r"\{docdate\}|\{localdate\} \{localtime\}|\{localdate\}", cfg["date"], text)
    text = text.replace("\\(", "(")
    text = re.sub(r"\{(r|a|c|i)\}", lambda m: m.group(1).upper(), text)
    text = text.replace(" — ", " : ").replace("—", ":")
    return text


def parse_table(lines):
    """lines: content between |=== markers. Returns markdown lines."""
    rows_raw = [l.rstrip() for l in lines]
    # header = first non-empty line
    while rows_raw and not rows_raw[0].strip():
        rows_raw.pop(0)
    if not rows_raw:
        return []
    header = [c.strip() for c in rows_raw[0].split("|")[1:]]
    n = len(header)
    cells, cur = [], None
    for l in rows_raw[1:]:
        if l.startswith("|"):
            for c in l.split("|")[1:]:
                if cur is not None:
                    cells.append(cur)
                cur = c.strip()
        elif l.strip() and cur is not None:
            cur = (cur + " " + l.strip()).strip()
    if cur is not None:
        cells.append(cur)
    rows = [cells[i:i + n] for i in range(0, len(cells), n)] if n else []
    rows = [r + [""] * (n - len(r)) for r in rows]
    rows = [r for r in rows if any(c and c != "✅" for c in r)] or [[""] * n]
    esc = lambda s: s.replace("|", "\\|")
    out = ["| " + " | ".join(esc(h) for h in header) + " |",
           "|" + "---|" * n]
    out += ["| " + " | ".join(esc(c) for c in r) + " |" for r in rows]
    return out


def to_markdown(src, lang):
    cfg = LANGS[lang]
    out, i = [], 0
    lines = src.read_text(encoding="utf-8").splitlines()
    while i < len(lines):
        l = lines[i]
        s = l.strip()
        if re.match(r"^\|=+\s*$", s):
            j = i + 1
            while j < len(lines) and not re.match(r"^\|=+\s*$", lines[j].strip()):
                j += 1
            out += [inline(x, lang) for x in parse_table(lines[i + 1:j])] + [""]
            i = j + 1
            continue
        if (s.startswith(":") and re.match(r"^:[\w-]+:", s)) or s.startswith("//") \
                or re.match(r"^\[(#|cols|%header|\.)", s) or s in ("[TIP]", "====", "[NOTE]"):
            i += 1
            continue
        m = re.match(r"^(=+)\s+(.*)$", s)
        if m:
            out.append("#" * len(m.group(1)) + " " + m.group(2).strip())
        elif re.match(r"^(TIP|NOTE|WARNING|IMPORTANT):", s):
            kind, body = s.split(":", 1)
            body = inline(body.strip(), lang)
            body = body.replace("Voir aussi ", "").replace("See also ", "")
            label = cfg["see"] if kind == "TIP" and re.match(r"^(Voir aussi|See also)", s[5:].strip()) else kind
            out.append(f"> **{label}** : {body}" if lang == "fr" else f"> **{label}**: {body}")
        elif s.startswith("image:"):
            out.append("> ![vues](https://github.com/bflorat/modele-da/raw/master/modele-vierge/ressources/vues.png)"
                       if lang == "fr" else
                       "> ![views](https://github.com/bflorat/architecture-document-template/raw/master/blank-template/resources/views.png)")
        else:
            out.append(inline(l.rstrip(), lang))
        i += 1
    text = "\n".join(out)
    text = re.sub(r"\n{3,}", "\n\n", text).strip() + "\n"
    return text


def extract_guide(src, lang):
    """Keep headings, size labels and TIP guidance; drop examples and pre-filled tables."""
    lines = src.read_text(encoding="utf-8").splitlines()
    out, labels, i = [], [], 0
    in_block = False
    while i < len(lines):
        s = lines[i].strip()
        m = re.match(r"^//🏷(\{.*\})", s)
        if m:
            try:
                labels = json.loads(m.group(1)).get("labels", [])
            except json.JSONDecodeError:
                labels = []
            i += 1
            continue
        h = re.match(r"^(#{1,5}|={1,5})\s+(.*)$", s)
        if h:
            lvl = len(h.group(1))
            tag = f" `[{', '.join(labels)}]`" if labels else ""
            out.append(f"\n{'#' * lvl} {h.group(2).strip()}{tag}")
            labels = []
            i += 1
            continue
        if s.startswith("[TIP]") or s.startswith("[NOTE]"):
            i += 1
            para = []
            if i < len(lines) and lines[i].strip() == "====":
                i += 1
                while i < len(lines) and lines[i].strip() != "====":
                    t = lines[i].strip()
                    if re.match(r"^(Exemple|Example|\[cols|\|)", t):
                        # skip example tables / samples until block end
                        while i < len(lines) and lines[i].strip() != "====":
                            i += 1
                        break
                    if t and not t.startswith("//") and not t.startswith("["):
                        para.append(inline(t, lang))
                    i += 1
                i += 1
            else:
                while i < len(lines) and lines[i].strip() and lines[i].strip() != "====":
                    t = lines[i].strip()
                    if not t.startswith("//"):
                        para.append(inline(t, lang))
                    i += 1
            if para:
                text = ""
                for p in para:
                    b = re.match(r"^(\*+|\.+|-)\s+(.*)$", p)
                    if b:
                        text += "\n" + "  " * len(b.group(1)) + "- " + b.group(2)
                    elif text and not text.endswith("\n"):
                        text += " " + p
                    else:
                        text += p
                out.append("- " + text.lstrip())
            continue
        if re.match(r"^(TIP|NOTE|WARNING|IMPORTANT):", s):
            out.append("- " + inline(s.split(":", 1)[1].strip(), lang))
        i += 1
    return re.sub(r"\n{3,}", "\n\n", "\n".join(out)).strip() + "\n"


def commit(repo):
    try:
        return subprocess.check_output(["git", "-C", str(repo), "rev-parse", "--short", "HEAD"],
                                       text=True).strip()
    except Exception:
        return "unknown"


def main(fr_repo, en_repo):
    repos = {"fr": Path(fr_repo), "en": Path(en_repo)}
    (SKILL / "references").mkdir(exist_ok=True)
    versions = {}
    for lang, cfg in LANGS.items():
        repo = repos[lang]
        versions[lang] = commit(repo)
        dst = SKILL / "assets" / lang
        dst.mkdir(parents=True, exist_ok=True)
        for adoc, md in cfg["files"].items():
            (dst / md).write_text(to_markdown(repo / cfg["blank"] / adoc, lang), encoding="utf-8")
            full = repo / adoc
            if md.startswith(("vue-", "view-")) and full.exists():
                (SKILL / "references" / f"guide-{lang}-{md}").write_text(
                    extract_guide(full, lang), encoding="utf-8")
    (SKILL / "assets" / "UPSTREAM_VERSION").write_text(
        f"fr bflorat/modele-da {versions['fr']}\n"
        f"en bflorat/architecture-document-template {versions['en']}\n", encoding="utf-8")
    print("done", versions)


if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    main(sys.argv[1], sys.argv[2])
