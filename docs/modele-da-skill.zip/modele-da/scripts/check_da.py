#!/usr/bin/env python3
"""Validate a generated Architecture Document (DA) against the modele-da skeletons.

Usage: python3 check_da.py <da_dir> [fr|en]

Checks, per file:
  1. every skeleton file exists;
  2. every skeleton heading is present, same level, same order (extra sub-headings allowed);
  3. no section is left empty: a leaf section needs content, `N/A` or `TODO`;
  4. no unfilled template placeholder (AAAA-MM-JJ / YYYY-MM-DD, empty header fields);
  5. README security rating follows `<grid> <levels>` e.g. `DICP 4-3-3-3`;
  6. every [H-xx] hypothesis cited in the text is declared in a Hypotheses table;
  7. C4 sections use the right Mermaid C4 type (Context, Container, Dynamic, Deployment).
Exit code 1 if any error. Warnings do not fail.
"""
import re
import sys
from pathlib import Path

SKILL = Path(__file__).resolve().parent.parent
HEAD = re.compile(r"^(#{1,6})\s+(.*?)\s*$")
GRIDS = {"DIC": 3, "DICT": 4, "DICP": 4, "CIA": 3}


# (file, section title) -> expected Mermaid C4 diagram type
C4_EXPECTED = {
    ("vue-applicative.md", "architecture applicative générale"): "C4Context",
    ("vue-applicative.md", "inventaire des modules"): "C4Container",
    ("vue-applicative.md", "liens entre modules"): "C4Dynamic",
    ("vue-infrastructure.md", "déploiement en production"): "C4Deployment",
    ("view-application.md", "general application architecture"): "C4Context",
    ("view-application.md", "inventory view"): "C4Container",
    ("view-application.md", "links between modules"): "C4Dynamic",
    ("view-infrastructure.md", "deployment in production"): "C4Deployment",
}


def check_c4(name, secs, errors, warns):
    for lvl, title, body in secs:
        want = C4_EXPECTED.get((name, norm(title)))
        if not want:
            continue
        kinds = re.findall(r"```mermaid\s*\n\s*(?:%%.*\n\s*)*(\w+)", body)
        if not kinds:
            if not re.match(r"^\s*(N/A|TODO)", body.strip()):
                warns.append(f"{name}: '{title}' has no {want} diagram")
        elif want not in kinds:
            errors.append(f"{name}: '{title}' must use a Mermaid {want} diagram (found {', '.join(kinds)})")


def headings(text):
    out, in_code = [], False
    for line in text.splitlines():
        if line.startswith("```"):
            in_code = not in_code
            continue
        m = HEAD.match(line)
        if m and not in_code:
            out.append((len(m.group(1)), norm(m.group(2))))
    return out


def norm(t):
    t = re.sub(r"`\[.*?\]`", "", t)
    return re.sub(r"\s+", " ", t.replace("’", "'")).strip().lower()


def sections(text):
    """Yield (level, title, body) for every heading."""
    lines, cur, buf, in_code = text.splitlines(), None, [], False
    res = []
    for line in lines:
        if line.startswith("```"):
            in_code = not in_code
        m = None if in_code else HEAD.match(line)
        if m:
            if cur:
                res.append((*cur, "\n".join(buf)))
            cur, buf = (len(m.group(1)), m.group(2)), []
        else:
            buf.append(line)
    if cur:
        res.append((*cur, "\n".join(buf)))
    return res


def body_is_empty(body):
    rows = [l for l in body.splitlines() if l.strip()]
    meaningful = []
    for l in rows:
        if re.match(r"^\|[\s|:-]*\|$", l.strip()):  # separator or empty row
            continue
        meaningful.append(l)
    # a table with only its header row counts as empty
    if len(meaningful) == 1 and meaningful[0].lstrip().startswith("|"):
        return True
    return not meaningful


def main(da, lang):
    da, errors, warns = Path(da), [], []
    tpl = SKILL / "assets" / lang
    for skel in sorted(tpl.glob("*.md")):
        target = da / skel.name
        if not target.exists():
            errors.append(f"{skel.name}: missing file")
            continue
        text = target.read_text(encoding="utf-8")
        got, want = headings(text), headings(skel.read_text(encoding="utf-8"))
        i = 0
        for lvl, title in want:
            while i < len(got) and got[i] != (lvl, title):
                i += 1
            if i == len(got):
                errors.append(f"{skel.name}: heading missing or out of order: {'#'*lvl} {title}")
                i = 0
                got_titles = [t for _, t in got]
                if title in got_titles:
                    i = got_titles.index(title)
            else:
                i += 1
        secs = sections(text)
        for k, (lvl, title, body) in enumerate(secs):
            is_leaf = k + 1 == len(secs) or secs[k + 1][0] <= lvl
            if is_leaf and body_is_empty(body):
                errors.append(f"{skel.name}: empty section '{title}' (write content, N/A or TODO)")
        check_c4(skel.name, secs, errors, warns)
        if re.search(r"AAAA-MM-JJ|YYYY-MM-DD", text):
            errors.append(f"{skel.name}: date placeholder not replaced")
        for field in ("Statut du document", "Document status"):
            m = re.search(rf"\*\*{field}\*\*\s*:\s*$", text, re.M)
            if m:
                errors.append(f"{skel.name}: '{field}' left empty")
        if "—" in text:
            warns.append(f"{skel.name}: contains em dash")

    readme = da / "README.md"
    if readme.exists():
        r = readme.read_text(encoding="utf-8")
        m = re.search(r"(Cotation de sécurité|Security rating)\**\s*[|:]\s*([^|\n]*)", r)
        val = m.group(2).strip() if m else ""
        mm = re.match(r"^(DICP|DICT|DIC|CIA)\s+(\d+(?:-\d+)+)$", val)
        if not mm:
            errors.append(f"README.md: security rating '{val}' must look like 'DICP 4-3-3-3'")
        elif len(mm.group(2).split("-")) != GRIDS[mm.group(1)]:
            errors.append(f"README.md: {mm.group(1)} needs {GRIDS[mm.group(1)]} levels")
        if re.search(r"^\|\s*Application\s*\|\s*\|", r, re.M):
            errors.append("README.md: 'Application' name left empty")
        if re.search(r"ex: `b523b6a`|id du commit|commit id", r):
            errors.append("README.md: template version (upstream commit hash) not filled")

    all_text = "\n".join(p.read_text(encoding="utf-8") for p in da.glob("*.md"))
    cited = set(re.findall(r"\bH-\d{2,3}\b", all_text))
    declared = set(re.findall(r"^\|\s*(H-\d{2,3})\s*\|", all_text, re.M))
    for h in sorted(cited - declared):
        errors.append(f"hypothesis {h} cited but not declared in a Hypothèses/Assumptions table")

    for w in warns:
        print("WARN ", w)
    for e in errors:
        print("ERROR", e)
    print(f"{len(errors)} error(s), {len(warns)} warning(s)")
    return 1 if errors else 0


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    sys.exit(main(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else "fr"))
