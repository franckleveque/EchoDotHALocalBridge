# Architecture document

Last modified: YYYY-MM-DD

Model version : <[commit id](https://github.com/bflorat/modele-da/commits/master), ex: `b523b6a`>

**Status**: ...

This document is made up of:

* an [application view](view-application.md) presenting the general context and the application architecture;
* a [development view](view-development.md) presenting the software architecture and its environment;
* a [sizing view](view-sizing.md) presenting aspects related to the performance and sizing of the infrastructure;
* an [infrastructure view](view-infrastructure.md) presenting the servers, middleware, operations, etc.;
* a [security view](view-security.md).

Each section sets out the constraints, requirements and then solutions implemented.

To be read first according to your role:

> ![views](https://github.com/bflorat/architecture-document-template/raw/master/blank-template/resources/views.png)

## Architectural subjects remaining

* ...
