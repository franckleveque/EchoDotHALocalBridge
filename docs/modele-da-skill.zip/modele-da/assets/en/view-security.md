# Security view

**Last modification** : _YYYY-MM-DD_

**Date of last full review** :

**Document status** :

## Introduction

### Reference Documentation
| N ° | Version | Document title / URL | Detail |
|---|---|---|---|
|  |  |  |  |

## Not ruled

### Points subject to further study
| ID | Detail | Status | Subject holder | Deadline |
|---|---|---|---|---|
|  |  |  |  |  |

### Assumptions
| ID | Detail |
|---|---|
|  |  |

## Constraints

## Requirements

### Integrity Requirements
.Required integrity level by data class
| Data Class | Non-Integral (Integrity errors are tolerated) | Detectable (Errors are quickly identified) | Controlled (Errors are corrected) | Integral (No alteration is tolerated) |
|---|---|---|---|---|
|  |  |  |  |  |

### Confidentiality Requirements
.Required confidentiality level by data class
| Data Class | Public (Accessible to anyone without restriction) | Limited (Accessible only to authorized individuals) | Restricted (Restricted to authorized internal staff) | Private (Strictly individual access) |
|---|---|---|---|---|
|  |  |  |  |  |

### Identification Requirements

### Authentication Requirements
| Use Case | Factor 1 | Factor 2 | ... |
|---|---|---|---|
|  |  |  |  |

### Identity Federation Requirements

### SSO and SLO Requirements

### Non-repudiation Requirements
| Signed action or document | Required signature level | Origin of client certificate | Origin of server certificate |
|---|---|---|---|
|  |  |  |  |

.Data to be kept for proof
| Data Nature | Objective | Retention period |
|---|---|---|
|  |  |  |

### Anonymity and Privacy Requirements

### Authorization Requirements

### Traceability and auditability Requirements

## Security measures

### Integrity
> **See also**: **Integrity Requirements**.

.Measures to ensure the required level of integrity
| Data class | Required level | Measures |
|---|---|---|
|  |  |  |

### Confidentiality
> **See also**: **Confidentiality Requirements**.

.Measures to ensure the required level of confidentiality
| Data class | Required level | Measures |
|---|---|---|
|  |  |  |

### Identification
> **See also**: **Identification Requirements**.

### Authentication
> **See also**: **Authentication Requirements**.

### Identity Federation
> **See also**: **Identity Federation Requirements**.

### SSO and SLO

### Service Accounts
.Service accounts
| Account | Resource requiring authentication | Credential storage method |
|---|---|---|
|  |  |  |

### Non-repudiation and Timestamping
> **See also**: **Non-repudiation Requirements**.

### Anonymity and Privacy
> **See also**: **Anonymity and Privacy Requirements**.

### Authorizations (Access Rights)
> **See also**: **Authorization Requirements**.

### Traceability and Auditability
> **See also**: **Traceability and auditability Requirements**.

### Cyberthreat Mitigation

#### Prevention Solutions

#### Detection Solutions

#### Response Solutions

#### Prediction Solutions

## Annexes

### RACI & Security Governance
This RACI clearly defines the roles and responsibilities of the teams with regard to **information security management**.

* R: **Responsible** (executes the action).
* A: **Accountable** (approves the action and is answerable to the organization).
* C: **Consulted** (provides expertise and must be consulted).
* I: **Informed** (must be notified after completion).

### Vulnerability Self-Assessment

| Vulnerability | Addressed? | Technical measures implemented |
|---|---|---|
|  |  |  |
