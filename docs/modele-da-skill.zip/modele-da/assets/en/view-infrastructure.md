# Infrastructure view

**Last modification** : _YYYY-MM-DD_

**Date of last full review** :

**Document status** :

## Introduction

### Reference Documentation
| N ° | Version | Document title / URL | Detail |
|---|---|---|---|
| 1 |  |  |  |

## Not ruled

### Points subject to further study
| ID | Detail | Status | Subject holder | Deadline |
|---|---|---|---|---|
|  |  |  |  |  |

### Assumptions
| ID | Detail |
|---|---|
|  |  |

## Constraints

### Availability Constraints

#### MTTD Constraints

#### Monitoring Tooling Constraints

#### MTTR Constraints

##### Hardware Constraints

##### System and virtualization

##### Network

##### Data Restore

#### Scheduled Interruptions Constraints

#### Level of service of the datacenter

#### Availability Ceiling

#### Disaster Management Constraints

### Hosting Constraints

### Network Constraints
> **See also**: [Network Constraints](view-sizing.md).

### Deployment Constraints

### Constraints Related to the Lifecycle of Infrastructure Components

### Log Constraints

### Backup And Restore Constraints

### Costs Constraints

## Requirements

### Operating Ranges
| No window | Hours | Detail |
|---|---|---|
|  |  |  |

### Availability Requirements
> **See also**: **Availability Constraints**.

.Maximum allowable downtime per range
| Operation range ID | Maximum downtime |
|---|---|
|  |  |

### Robustness Requirements

### RPO Requirements

### RTO Requirements
> **See also**: **MTTR Constraints**.

### Deployment and Upgrades Requirements

#### Server side

#### Client side

#### Specific deployment strategy

### Ecodesign Requirements

## Target Architecture

### Principles

### Availability
> **See also**: **Availability Requirements**.

### Deployment in production

### Infrastructure components
| Infrastructure Component | Role | Version | Technical Environment |
|---|---|---|---|
|  |  |  |  |

### Matrix of network flows
| ID | Source | Destination | Network Type | Protocol | Listening Port | Encryption? |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

### Environments

| Environment | Role | Content | Nb of platforms |
|---|---|---|---|
|  |  |  |  |

### Ecodesign
> **See also**: **Ecodesign Requirements**.

#### Energy Optimization & Infrastructure

#### Overall energy impact

### Load regulation

#### Circuit breakers

#### Quality of Service

### Timeout Management

### Operations

#### Startup/Shutdown Order

#### Scheduled Operations and Monitoring

#### Maintenance Mode

#### Backups and Restores

##### Scope

##### Backup Strategy
> **See also**: **RPO Requirements**, **RTO Requirements**.

##### Tooling

##### Backup Processing

##### Storage Modalities

##### Restore

#### Logging

### Monitoring
> **See also**: **MTTD Constraints**.

#### Technical Monitoring

#### Application & Business Monitoring

#### Monitoring & Observability Tools

#### Alerting & Notifications

#### Black-box Monitoring

#### Performance Monitoring

### Decommissioning
