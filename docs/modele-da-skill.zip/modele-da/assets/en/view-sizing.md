# Sizing view

**Last modification** : _YYYY-MM-DD_

**Date of last full review** :

**Document status** :

## Introduction

### Reference Documentation
| N ° | Version | Document title / URL | Detail |
|---|---|---|---|
|  |  |  |  |

## Not ruled

### Points subject to further study
| ID | Detail | Status | Subject holder | Deadline |
|---|---|---|---|---|
|  |  |  |  |  |

### Assumptions
| ID | Detail |
|---|---|
|  |  |

## Constraints

### Storage Constraints

### Compute Constraints

### Memory Constraints

### Network Constraints

## Requirements

### Static Sizing Requirements

#### Metrics
| Metric | Description | Measured or Estimated? | Value | Forecast annual increase (%) | Source | Detail/assumptions |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

#### Estimated storage needs

| Data | Description | Unit size | Number of items at 5 years | Total size | Annual increase |
|---|---|---|---|---|---|
|  |  |  |  |  |  |

### Dynamic Sizing Requirements

#### Metrics
| Metric | Description | Measured or Estimated? | Value | Forecast annual increase (%) | Seasonality | Source | Detail/assumptions |
|---|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |  |

#### Estimated load

### Response time requirements

#### Response Time of GUIs Requirements
| Type of request | Good level | Medium level | Insufficient level |
|---|---|---|---|
|  |  |  |  |

#### Duration of batch Requirements

## Target sizing

### Estimate of resource requirements by deployable unit
| Deployable unit | (V)CPU requirement per instance | Memory requirement per instance (MiB) | Periods of activity | Comments |
|---|---|---|---|---|
|  |  |  |  |  |

### Sizing of machines
| Zone | Machine type | Number of machines | Number of (V)CPU | Memory (GiB) | Internal disk (GiB) | External SAN disk (GiB) |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

### Non-SAN external storage
| Nature | Size (Gio) | Type(s) of machine using this share |
|---|---|---|
|  |  |  |
