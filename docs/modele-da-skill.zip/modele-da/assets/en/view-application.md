# Application view

**Last modification** : _YYYY-MM-DD_

**Date of last full review** :

**Document status** :

## Introduction

### Reference Documentation
| N ° | Version | Document title / URL | Detail |
|---|---|---|---|
|  |  |  |  |

## Not ruled

### Points subject to further study
| Subject | Detail | Status | Subject bearer | Deadline |
|---|---|---|---|---|
|  |  |  |  |  |

### Assumptions
| ID | Detail |
|---|---|
|  |  |

## General context

### Objectives

### Existing

### Positioning in the IS

### Actors

#### Internal actors
| Actor | Description | Population | Location |
|---|---|---|---|
|  |  |  |  |

#### External actors
| Actor | Description | Population | Location |
|---|---|---|---|
|  |  |  |  |

#### Nature and Sensitivity of Data and Processing
| Business Process | Purpose | Categories of Data Processed | Classification | C | I | A | T |
|---|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |  |

| Legend | (C)onfidentiality (I)ntegrity (A)vailability (T)raceability / proof. Provide requirement : Low, Medium or High |
|---|---|
| Classification | Public, Internal, Restricted distribution, Confidential |

## Constraints

### Budget Constraints

### Planning Constraints

### Urbanization

### Legal Constraints

## Requirements

### Strategic Requirements

### Interoperability Requirements

### Concurrency management Requirements

### Degraded Modes Requirements

### Archiving Requirements

### Retention Periods Requirements
| Data Class | Maximum Retention Period |
|---|---|
|  |  |

## Target architecture

### General application architecture

### Detailed application architecture

#### Principles that dictated the choices

#### Inventory view

#### Links between modules

### Transition paths

### Archiving
> **See also**: **Archiving Requirements**.

### Purges
> **See also**: **Retention Periods Requirements**.

### Matrix of application flows
| Source | Destination | Network type | Protocol | Mode |
|---|---|---|---|---|
|  |  |  |  |  |

_Mode: Read(R), Write (W) or Call(C) to a stateless system_
