# Development view

**Last modification** : _YYYY-MM-DD_

**Date of last full review** :

**Document status** :

## Introduction

### Reference Documentation
| N ° | Version | Document title / URL | Detail |
|---|---|---|---|
|  |  |  |  |

## Not ruled

### Points subject to further study
| ID | Detail | Status | Subject holder | Deadline |
|---|---|---|---|---|
|  |  |  |  |  |

### Assumptions
| ID | Detail |
|---|---|
|  |  |

## Constraints

## Non-Functional Requirements

### Accessibility Requirements

### Ergonomics Requirements

#### Specificities on UX

#### Specificities on widgets

#### Fonts Requirements

#### Responsive Website Requirements

#### Progressive Web Apps (PWA) Requirements

#### Supported Browsers Requirements

#### Offline Mode Requirements

#### Internationalization (i18n) Requirements

### SEO Requirements

### Ecodesign Requirements

## Target architecture

### Software stack

#### Stack profile

#### Main dependencies
| Library | Role | Version |
|---|---|---|
|  |  |  |

### Performance
> **See also**: [Requirements](view-sizing.md).

### Software factory specifics

### Blueprints

### Code quality standards and automatic review

### Notable patterns

### Specificities of the tests
| Type of test | Time to invest | Manual or automated? | Type of module targeted | Target Coverage Rate | Detail |
|---|---|---|---|---|---|
|  |  |  |  |  |  |

### Ecodesign
> **See also**: **Ecodesign Requirements**.

### Management of robustness

#### Transaction management

#### Session management

#### Error handling

#### Controls

#### Frontend robustness

### Configuration management

### Branch management policy

### Versioning

### Concurrency
> **See also**: [Concurrency management Requirements](view-application.md).

### Encoding

### Timezones

### Log management
> **See also**: [Log Constraints](view-infrastructure.md).

#### General rules

#### Levels and quantity of logs
| Severity level | Context of use | Indicative volume | By environment |
|---|---|---|---|
|  |  |  |  |

### Administrative tools

### Sorting and Pagination

### Provisioning and DDL updates

### Internationalization Management
> **See also**: **Internationalization (i18n) Requirements**.
