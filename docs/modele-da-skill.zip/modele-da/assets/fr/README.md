# Dossier d'architecture

| Statut | _En cours_ |
|---|---|
| Dernière modification | AAAA-MM-JJ |
| Application |  |
| Cotation de sécurité |  |
| Version du modèle utilisé | <[id du commit](https://github.com/bflorat/modele-da/commits/master) du projet modèle de dossier d'architecture>, ex: `b523b6a`> |

Ce dossier est constitué :

* d’une [vue applicative](vue-applicative.md) présentant le contexte général et l’architecture applicative ;
* d’une [vue développement](vue-developpement.md) présentant l’architecture logicielle ;
* d’une [vue infrastructure](vue-infrastructure.md) présentant les aspects d’architecture techniques ou physiques ;
* d’une [vue dimensionnement](vue-dimensionnement.md) présentant les aspects liés aux performances et aux sollicitations ;
* d’une [vue sécurité](vue-securite.md).

Chaque vue expose les contraintes, exigences puis solutions mises en oeuvre.

A lire en priorité en fonction de votre rôle :

> ![vues](https://github.com/bflorat/modele-da/raw/master/modele-vierge/ressources/vues.png)

## Reste à faire identifié
