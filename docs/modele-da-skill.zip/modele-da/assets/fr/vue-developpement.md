# Vue développement

**Dernière modification** : _AAAA-MM-JJ_

**Date de la dernière revue globale** :

**Statut du document** :

## Introduction

### Documentation de Référence
| N° | Version | Titre/URL du document | Détail |
|---|---|---|---|
|  |  |  |  |

## Non statué

### Points nécessitant une étude complémentaire
| ID | Détail | Statut | Porteur du sujet | Échéance |
|---|---|---|---|---|
|  |  |  |  |  |

### Hypothèses
| ID | Détail |
|---|---|
|  |  |

## Contraintes

## Exigences non fonctionnelles

### Exigences d'accessibilité

### Exigences d'ergonomie

#### Spécificités d'UX

#### Spécificités sur les widgets

#### Exigences sur les polices de caractère

#### Exigences de site Web adaptatif

#### Exigences de progressive Web Apps (PWA)

#### Exigences sur les navigateurs supportés

#### Exigences de mode déconnecté

#### Exigences d'internationalisation (i18n)

### Exigences de SEO

### Exigences d'écoconception

## Architecture cible

### Pile logicielle

#### Filière technique retenue

#### Dépendances
| Dépendance | Rôle | Version |
|---|---|---|
|  |  |  |

### Performances
> **Voir aussi** : [Exigences](vue-dimensionnement.md).

### Spécificités d’usine logicielle

### Bonnes pratiques

### Normes de développement et qualimétrie

### Patterns notables

### Spécificités des tests
| Type de test | Temps à investir | Manuel ou automatisé ? | Type de module ciblé | Taux de Couverture visée | Détail |
|---|---|---|---|---|---|
|  |  |  |  |  |  |

### Éco-conception
> **Voir aussi** : **Exigences d'écoconception**.

### Gestion de la robustesse

#### Gestion des transactions

#### Gestion des sessions

#### Gestion des erreurs

#### Contrôles

#### Gestion de la robustesse coté frontend

### Gestion de la configuration

### Politique de gestion des branches

### Versioning

### Gestion de la concurrence
> **Voir aussi** : [Exigences sur la gestion de la concurrence](vue-applicative.md).

### Encodage

### Fuseaux horaires

### Gestion des journaux
> **Voir aussi** : [Contraintes liées aux journaux](vue-infrastructure.md).

#### Règles générales

#### Niveaux et quantité de journaux
| Niveau de gravité | Contexte d'utilisation | Volume indicatif | Par environnement |
|---|---|---|---|
|  |  |  |  |

### Outils d'administration

### Tri et Pagination

### Provisioning et mises à jour des DDL

### Gestion de l'internationalisation
> **Voir aussi** : **Exigences d'internationalisation (i18n)**.
