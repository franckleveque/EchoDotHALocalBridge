# Vue architecture applicative

**Dernière modification** : _AAAA-MM-JJ_

**Date de la dernière revue globale** :

**Statut du document** :

## Introduction

### Documentation de Référence
| N° | Version | Titre/URL du document | Détail |
|---|---|---|---|
| 1 |  |  |  |

## Non statué

### Points nécessitant une étude complémentaire
| Sujet | Détail | Statut | Porteur du sujet | Échéance |
|---|---|---|---|---|
|  |  |  |  |  |

### Hypothèses
| ID | Détail |
|---|---|
|  |  |

## Contexte général

### Objectifs

### Existant

### Positionnement dans le SI

### Acteurs

#### Acteurs internes
| Acteur | Description | Population | Localisation |
|---|---|---|---|
|  |  |  |  |

#### Acteurs externes
| Acteur | Description | Population | Localisation |
|---|---|---|---|
|  |  |  |  |

#### Nature et sensibilité des données et traitements

| Processus métier | Finalité | Catégories de données manipulées | Classification | D | I | C | T |
|---|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |  |

| Légende | (D)isponibilité (I)ntégrité (C)onfidentialité (T)race ou preuve. Donner le niveau requis : faible, moyen ou élevé |
|---|---|
| Classification | Public, Interne, Diffusion restreinte, Confidentiel |

## Contraintes

### Contraintes budgetaires

### Contraintes planning

### Urbanisation

### Contraintes juridiques

## Exigences

### Exigences stratégiques

### Exigences d'interopérabilité

### Exigences sur la gestion de la concurrence

### Exigences sur les modes dégradés

### Exigences d'archivage

### Exigences sur les durées de rétention
| Nature de la Donnée | Durée maximale de rétention |
|---|---|
|  |  |

## Architecture cible

### Architecture applicative générale

### Architecture applicative détaillée

#### Principes ayant dicté les choix

#### Inventaire des modules

#### Liens entre modules

### Trajectoires de migrations

### Archivage
> **Voir aussi** : **Exigences d'archivage**.

### Purges
> **Voir aussi** : **Exigences sur les durées de rétention**.

### Matrice des flux applicatifs
| Source | Destination | Type de réseau | Protocole | Mode |
|---|---|---|---|---|
|  |  |  |  |  |

_Mode: (L)ecture, (E)criture ou Lecture/Ecriture (LE), (A)ppel (vers un système stateless)_
