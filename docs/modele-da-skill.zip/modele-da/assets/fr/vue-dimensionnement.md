# Vue dimensionnement

**Dernière modification** : _AAAA-MM-JJ_

**Date de la dernière revue globale** :

**Statut du document** :

## Introduction

### Documentation de Référence
| N° | Version | Titre/URL du document | Détail |
|---|---|---|---|
| 1 |  |  |  |

## Non statué

### Points nécessitant une étude complémentaire
| ID | Détail | Statut | Porteur du sujet | Échéance |
|---|---|---|---|---|
|  |  |  |  |  |

### Hypothèses

| ID | Détail |
|---|---|
|  |  |

## Contraintes

### Contraintes de stockage

### Contraintes de puissance de calcul

### Contraintes sur la mémoire

### Contraintes sur le réseau

## Exigences

### Exigences sur la volumétrie statique

#### Métriques
| Métrique | Description | Mesurée ou Estimée ? | Valeur | Augmentation annuelle prévisionnelle (%) | Source | Détail/hypothèses |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

#### Estimation besoins de stockage
| Donnée | Description | Taille unitaire | Nombre d'éléments à 5 ans | Taille totale | Augmentation annuelle |
|---|---|---|---|---|---|
|  |  |  |  |  |  |

### Exigences sur la volumétrie dynamique

#### Métriques
| Métrique | Description | Mesurée ou Estimée ? | Valeur | Augmentation annuelle prévisionnelle (%) | Saisonnalité | Source | Détail/hypothèses |
|---|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |  |

#### Estimation de la charge

### Exigences de temps de réponse

#### Exigences de temps de Réponse des IHM
| Profil de sollicitation | Bon niveau | Niveau moyen | Niveau insuffisant |
|---|---|---|---|
|  |  |  |  |

#### Exigences sur la durée d’exécution des batchs

## Dimensionnement cible

### Estimation des besoins en ressources par unité déployable
| Unité déployable | Besoin en (V)CPU par instance | Besoin mémoire par instance (Mio) | Périodes d'activité | Commentaires |
|---|---|---|---|---|
|  |  |  |  |  |

### Dimensionnement des machines
| Zone | Type de machine | Nb de machines | Nb (V)CPU | Mémoire (Gio) | Disque interne (Gio) | Disque distant SAN (Gio) |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

### Dimensionnement du stockage externe hors SAN
| Nature | Taille (Gio) | Type(s) de machine utilisant ce partage |
|---|---|---|
|  |  |  |
