# Vue infrastructure

**Dernière modification** : _AAAA-MM-JJ_

**Date de la dernière revue globale** :

**Statut du document** :

## Introduction

### Documentation de Référence
| N° | Version | Titre/URL du document | Détail |
|---|---|---|---|
| 1 |  |  |  |

## Non statué

### Points nécessitant une étude complémentaire
| ID | Détail | Statut | Porteur du sujet | Échéance |
|---|---|---|---|---|
|  |  |  |  |  |

### Hypothèses
| ID | Détail |
|---|---|
|  |  |

## Contraintes

### Contraintes sur la disponibilité

#### Contraintes de MTTD

#### Contraintes sur les outils et normes de supervision

#### Contraintes de MTTR

##### Matériel

##### Système et virtualisation

##### Réseau

##### Restauration de données

#### Contraintes sur les interruptions programmées

#### Contraintes liées au niveau de service du datacenter

#### Plafond de disponibilité

#### Contraintes liées à la gestion des catastrophes

### Contraintes d'hébergement

### Contraintes réseau
> **Voir aussi** : [Contraintes sur le réseau](vue-dimensionnement.md).

### Contraintes de déploiement

### Contraintes liées au cycle de vie des composants d'infrastructure

### Contraintes liées aux journaux

### Contraintes de sauvegardes et restaurations

### Contraintes budgétaires

## Exigences

### Plages de fonctionnement
| No plage | Heures | Détail |
|---|---|---|
|  |  |  |

### Exigences de disponibilité
> **Voir aussi** : **Contraintes sur la disponibilité**.

.Durée d’indisponibilité maximale admissible par plage
| No Plage | Indisponibilité maximale |
|---|---|
|  |  |

### Exigences de robustesse

### Exigences de déploiements et de mises à jour

#### Coté serveur

#### Coté client

#### Stratégie de déploiement spécifiques

### Exigences d'écoconception

## Architecture cible

### Principes

### Disponibilité
> **Voir aussi** : **Exigences de disponibilité**.

### Déploiement en production

### Composants d'infrastructure
| Composant d'infrastructure | Rôle | Version | Environnement technique |
|---|---|---|---|
|  |  |  |  |

### Matrice des flux techniques
| ID | Source | Destination | Type de réseau | Protocole | Port d'écoute | Chiffrement ? |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

### Environnements
| Environnement | Rôle | Contenu | Plateforme |
|---|---|---|---|
|  |  |  |  |

### Écoconception
> **Voir aussi** : **Exigences d'écoconception**.

#### Optimisation énergétique et infrastructure

#### Impact énergétique global

### Régulation de la charge

#### Coupe-circuits

#### Qualité de Service

### Gestion des timeouts

### Exploitation

#### Ordre d’arrêt/démarrage

#### Opérations programmées et suivi

#### Mise en maintenance

#### Sauvegardes et restaurations

##### Périmètre

##### Stratégie de sauvegarde
> **Voir aussi** : **Exigences de disponibilité**.

##### Outillage

##### Traitements sur les sauvegardes

##### Modalités de stockage

##### Restauration

#### Journaux

### Supervision
> **Voir aussi** : **Contraintes de MTTD**.

#### Supervision technique

#### Supervision applicative et métier

#### Outils de supervision & monitoring

#### Alerting & notifications

#### Supervision boite noire

#### Mesure et suivi des performances

### Décommissionnement
