# Vue sécurité

**Dernière modification** : _AAAA-MM-JJ_

**Date de la dernière revue globale** :

**Statut du document** :

## Introduction

### Documentation de Référence
| N° | Version | Titre/URL du document | Détail |
|---|---|---|---|
| 1 |  |  |  |

## Non statué

### Points nécessitant une étude complémentaire
| ID | Détail | Statut | Porteur du sujet | Échéance |
|---|---|---|---|---|
|  |  |  |  |  |

### Hypothèses
| ID | Détail |
|---|---|
|  |  |

## Contraintes

## Exigences

### Exigences d'intégrité
| Classe de données | Non intègre (Les erreurs d'intégrité sont tolérées) | Détectable (Les erreurs sont identifiées rapidement) | Maîtrisé (Les erreurs sont corrigées) | Intègre (Aucune altération n’est tolérée) |
|---|---|---|---|---|
|  |  |  |  |  |

### Exigences de confidentialité
| Classe de données | Public (Donnée accessible à tous sans restriction) | Limité (Accessible uniquement aux personnes habilitées) | Réservé (Restreint au personnel interne autorisé) | Privé (Accès strictement individuel) |
|---|---|---|---|---|
|  |  |  |  |  |

### Exigences d'identification
| Exigence | Description |
|---|---|
|  |  |

### Exigences d'authentification
| Cas d'utilisation | Facteur 1 | Facteur 2 | ... |
|---|---|---|---|
|  |  |  |  |

### Exigences de fédération d’identité

### Exigences de SSO et SLO

### Exigences de non-répudiation
| Donnée | Objectif | Durée de rétention |
|---|---|---|
|  |  |  |

### Exigences d'anonymat et de respect de la vie privée

### Exigences sur les autorisations

### Exigences de traçabilité et d'auditabilité

## Mesures de sécurité

### Intégrité
> **Voir aussi** : **Exigences d'intégrité**.

| Classe de données | Niveau exigé | Mesures |
|---|---|---|
|  |  |  |

### Confidentialité
> **Voir aussi** : **Exigences de confidentialité**.

| Classe de données | Niveau exigé | Mesures |
|---|---|---|
|  |  |  |

### Identification
> **Voir aussi** : **Exigences d'identification**.

### Authentification
> **Voir aussi** : **Exigences d'authentification**.

### Fédération d’identité
> **Voir aussi** : **Exigences de fédération d’identité**.

### SSO et SLO

### Comptes de service

### Non-répudiation et horodatage
> **Voir aussi** : **Exigences de non-répudiation**.

### Anonymat et vie privée
> **Voir aussi** : **Exigences d'anonymat et de respect de la vie privée**.

### Autorisations
> **Voir aussi** : **Exigences sur les autorisations**.

### Traçabilité et auditabilité
> **Voir aussi** : **Exigences de traçabilité et d'auditabilité**.

### Lutte contre les cybermenaces

#### Solutions de prévention

#### Solutions de détection

#### Solutions de correction

#### Solutions de prédiction

## Annexes

### RACI & Gouvernance de la Sécurité

Ce RACI permet de définir clairement les rôles et responsabilités des équipes en matière de **gestion de la sécurité informatique**.

* R : **Responsible** (exécute l'action).
* A : **Accountable** (valide l'action et en est responsable devant l'organisation).
* C : **Consulted** (doit être consulté pour expertise).
* I : **Informed** (doit être informé après réalisation).

### Auto-contrôles de sécurité

#### Auto-contrôle des vulnérabilités

| Vulnérabilité | Prise en compte ? | Mesures techniques entreprises |
|---|---|---|
|  |  |  |

#### Auto-contrôle RGPD
| Exigence RGPD | Prise en compte ? | Mesures techniques entreprises |
|---|---|---|
|  |  |  |
